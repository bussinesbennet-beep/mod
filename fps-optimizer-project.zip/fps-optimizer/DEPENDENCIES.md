# Dependencies and Licenses

## Required Dependencies

| Component | Version | License | Source |
|-----------|---------|---------|--------|
| Minecraft Java Edition | 26.2 | Proprietary (Mojang) | https://minecraft.net/ |
| Fabric Loader | 0.19.5 | MIT | https://github.com/FabricMC/fabric-loader |
| Fabric API | 0.161.0+26.2 | Apache-2.0 | https://github.com/FabricMC/fabric-api |
| Fabric Loom | 1.17 | LGPL-2.1 | https://github.com/FabricMC/fabric-loom |
| Gradle | 9.5.1 | Apache-2.0 | https://gradle.org/ |
| Java JDK | 25+ | GPL-2.0 with Classpath Exception | https://openjdk.org/ |

## Optional Dependencies

| Component | Version | License | Purpose |
|-----------|---------|---------|---------|
| Baritone | 1.19.0 | LGPLv3 | Pathfinding for Navigation module |

## Compatibility Notes

- **Minecraft 26.2** is unobfuscated (Mojang mappings). No Yarn mappings available.
- **Fabric Loom 1.17** uses the non-obfuscated plugin `net.fabricmc.fabric-loom`.
- **Java 25** is required for Minecraft 26.2.
- Baritone integration is optional - the mod works without it with degraded navigation.

## Version Verification

All versions were verified against official sources on 2026-10-24:
- Fabric Blog: https://fabricmc.net/2026/06/15/262.html
- Fabric API on CurseForge: https://www.curseforge.com/minecraft/mc-mods/fabric-api/files/all
- Baritone releases: https://github.com/cabaletta/baritone/releases
- Minecraft version history: https://mcreference.com/