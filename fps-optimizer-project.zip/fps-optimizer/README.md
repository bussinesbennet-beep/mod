# FPS Optimizer

A comprehensive Minecraft Java Edition 26.2 Fabric client mod with HUD, Visuals, Utility, Navigation, Performance, and World Analysis features.

**Language:** German/English (bilingual translation files)

## Verified Versions (as of 2026-10-24)

| Component | Version |
|-----------|---------|
| Minecraft | 26.2 |
| Java | 25+ |
| Fabric Loader | 0.19.5 |
| Fabric API | 0.161.0+26.2 |
| Fabric Loom | 1.17 |
| Gradle | 9.5.1 |
| Baritone (optional) | 1.19.0 (for 26.2) |

## Features

### HUD Elements
- **FPS** - Current frames per second with optional smoothing
- **Coordinates** - X, Y, Z position with optional rotation and dimension
- **Armor** - Armor durability with low durability warnings
- **Keystrokes** - Visual feedback for movement keys (WASD, sprint, sneak, jump)
- **CPS** - Clicks per second for left and right mouse buttons
- **Target Info** - Information about the targeted entity
- **Status** - Status of active modules
- **Radar** - Nearby players and entities on a radar display

### Modules
- **Fullbright** - Client-side brightness adjustment (reversible)
- **Freecam** - Free camera movement (does NOT change server position)
- **Free Look** - Independent camera rotation
- **AutoTool** - Automatic tool selection for mining
- **AutoEat** - Automatic eating when hunger is low
- **Storage ESP** - Highlights storage blocks
- **Block ESP** - Highlights specific blocks
- **Entity ESP** - Highlights entities with boxes and names
- **Chunk Analyzer** - Analyzes loaded chunks
- **Navigation** - Pathfinding via Baritone integration (optional)
- **Macros** - Record and playback input sequences
- **Performance** - Render and memory optimizations
- **Particle Reduction** - Reduces particle count
- **Fog Control** - Adjusts fog distance

### GUI
- **ClickGUI** - Vanilla-styled mod menu with categories and search
- **HUD Editor** - Drag-and-drop HUD element positioning
- **Global Toggle** - RIGHT_SHIFT to enable/disable the mod
- **Panic Key** - Configurable emergency stop
- **Notifications** - Toast-style notifications

## Installation

### For Players

1. Install [Fabric Loader 0.19.5](https://fabricmc.net/) for Minecraft 26.2
2. Install [Fabric API 0.161.0+26.2](https://modrinth.com/mod/fabric-api/version/ewUK83HI)
3. Download the FPS Optimizer JAR from the releases page
4. Place the JAR in your `.minecraft/mods/` folder
5. Launch Minecraft with the Fabric profile

### For Developers

1. Ensure you have **Java 25** installed
2. Clone this repository
3. Run `./gradlew build` to compile and create the JAR
4. The JAR will be in `build/libs/`

### Build Commands

```bash
# Compile the mod
./gradlew build

# Compile and run tests
./gradlew test

# Clean build
./gradlew clean build

# Generate run configuration for IDE
./gradlew idea  # or eclipse
```

## Usage

### Keybinds (Default)

| Key | Action |
|-----|--------|
| `RIGHT_SHIFT` | Global toggle (enable/disable FPS Optimizer) |
| `O` | Open ClickGUI |
| `P` | Open HUD Editor |
| `F12` | Toggle Freecam |
| `F11` | Toggle Free Look |
| `M` | Toggle Macro |

### ClickGUI

Open with `O` or via the keybind. Navigate categories:
- HUD, Visuals, Utility, Navigation, Performance, World Analysis, Settings

Each module has:
- Enable/Disable toggle
- Keybind configuration
- Per-module settings (booleans, numbers, colors)

### Panic Key

The panic key stops all automation (AutoTool, AutoEat, Navigation, Macros), resets Freecam and Free Look, and shows a notification. Configure it in Settings > Panic Keybind.

### HUD Editor

Open with `P`. Drag HUD elements to reposition them. Enable grid snapping for alignment. Changes are saved automatically.

## Module Documentation

### Fullbright
- Reversible client-side brightness adjustment
- No permanent changes to world files or game settings
- Restores original gamma on disable

### Freecam
- Camera movement only affects rendering, not server position
- Safe exit via keybind or panic
- Resets on world change, disconnect, and death
- Does not trigger attacks or interactions

### Navigation
- Uses Baritone v1.19.0 for Minecraft 26.2 if installed
- Gracefully degrades to basic movement if Baritone is absent
- Does not claim server-side position changes

### Macros
- Stored in versioned JSON in `config/fps-optimizer-macros/`
- Cannot read credentials or bypass protections
- Safe abort on focus loss and world change

## Configuration

Configuration is stored in `config/fps-optimizer.json` with versioning (current version: 3).

Features:
- Safe defaults
- Validation of loaded data
- Error handling for corrupted files
- Controlled migration of older configurations
- No credentials stored
- Only saves when data changes

## Performance Optimizations

All optimizations are measurable and safe:

1. **HUD Value Caching** - Reduces per-frame calculations (1-2 tick delay)
2. **Limited Update Rates** - ESP/Radar update at most every 5-15 ticks
3. **Config Save on Change** - No unnecessary disk I/O
4. **No JVM Interference** - No forced GC or unsafe memory operations
5. **Safe Rendering** - All rendering through Minecraft's VertexConsumer API

## Known Limitations

- **Baritone Integration**: Optional. If Baritone v1.19.0 for 26.2 is not installed, navigation uses basic movement without pathfinding.
- **Java 25 Required**: Minecraft 26.2 requires Java 25 or newer.
- **Singleplayer Focus**: Most modules are designed for singleplayer and allowed test environments.
- **No Multiplayer Automation**: AutoTool, AutoEat, and macros are intended for local testing only.

## License

MIT License. See LICENSE file for details.

## Dependencies

- [Fabric API](https://github.com/FabricMC/fabric-api) - Apache License 2.0
- [Baritone](https://github.com/cabaletta/baritone) - LGPLv3 (optional, for navigation)
- [Fabric Loader](https://github.com/FabricMC/fabric-loader) - MIT License

## Disclaimer

This mod is for singleplayer and allowed test environments. Automation features (AutoTool, AutoEat, macros) should not be used on multiplayer servers where they may violate server rules. The authors are not responsible for any bans or penalties resulting from misuse.