package dev.fpsoptimizer;

import dev.fpsoptimizer.config.ConfigManager;
import dev.fpsoptimizer.gui.ClickGuiScreen;
import dev.fpsoptimizer.gui.HudEditorScreen;
import dev.fpsoptimizer.hud.HudManager;
import dev.fpsoptimizer.keybind.KeybindManager;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.notification.NotificationManager;
import dev.fpsoptimizer.performance.PerformanceManager;
import dev.fpsoptimizer.render.RenderHelper;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main entry point for the FPS Optimizer Fabric client mod.
 * Initializes all managers, registers keybinds, and sets up the client tick handler.
 */
public class FPSOptimizerClient implements ClientModInitializer {

    public static final String MOD_ID = "fpsoptimizer";
    public static final String MOD_NAME = "FPS Optimizer";
    public static final String MOD_VERSION = "1.0.0+fabric";

    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Managers
    private static ModuleManager moduleManager;
    private static KeybindManager keybindManager;
    private static HudManager hudManager;
    private static NotificationManager notificationManager;
    private static ConfigManager configManager;
    private static PerformanceManager performanceManager;
    private static RenderHelper renderHelper;

    // Client state
    private static boolean globalEnabled = true;
    private static MinecraftClient client;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing FPS Optimizer {}...", MOD_VERSION);

        client = MinecraftClient.getInstance();

        // Initialize managers in dependency order
        configManager = new ConfigManager();
        renderHelper = new RenderHelper();
        notificationManager = new NotificationManager();
        moduleManager = new ModuleManager();
        keybindManager = new KeybindManager();
        hudManager = new HudManager();
        performanceManager = new PerformanceManager();

        // Load configuration
        configManager.load();

        // Register keybinds
        keybindManager.registerKeybinds();

        // Register client tick events
        ClientTickEvents.END_CLIENT_TICK.register(this::onEndClientTick);

        LOGGER.info("FPS Optimizer initialized successfully.");
    }

    /**
     * Called at the end of each client tick.
     * Updates global state, keybinds, and modules.
     */
    private void onEndClientTick(MinecraftClient client) {
        if (client == null) {
            return;
        }

        // Update global enabled state
        updateGlobalState();

        // Update keybinds
        keybindManager.update();

        // Update modules
        moduleManager.update();

        // Update HUD manager
        hudManager.update();

        // Update notification manager
        notificationManager.update();

        // Update performance manager
        performanceManager.update();
    }

    /**
     * Handles the global toggle keybind (RIGHT_SHIFT by default).
     * When pressed, toggles the global enabled state of the mod.
     */
    private void updateGlobalState() {
        if (keybindManager == null) {
            return;
        }

        // Check global toggle keybind
        if (keybindManager.isGlobalTogglePressed()) {
            globalEnabled = !globalEnabled;
            if (globalEnabled) {
                notificationManager.add("notification.fpsoptimizer.enabled", "FPS Optimizer", "Modul ist wieder aktiviert");
                moduleManager.enableAllModules();
            } else {
                notificationManager.add("notification.fpsoptimizer.disabled", "FPS Optimizer", "Modul ist deaktiviert");
                moduleManager.disableAllModules();
                clickGuiScreen = null;
                hudEditorScreen = null;
            }
        }

        // Check panic keybind
        if (keybindManager.isPanicKeyPressed()) {
            triggerPanic();
        }
    }

    private static Screen clickGuiScreen;
    private static Screen hudEditorScreen;

    /**
     * Triggers the panic sequence - stops all automation, resets state, shows notification.
     */
    public static void triggerPanic() {
        LOGGER.warn("Panic key pressed - stopping all automation and resetting state");

        // Stop all automation modules
        moduleManager.stopAllAutomation();

        // Reset freecam
        moduleManager.resetFreecam();

        // Reset freelook
        moduleManager.resetFreeLook();

        // Clear any pending actions
        keybindManager.clearPendingInputs();

        // Show panic notification
        notificationManager.add("notification.fpsoptimizer.panic", "Panik-Modus", "Alle Automatisierungen wurden gestoppt");
    }

    /**
     * Opens the ClickGUI screen.
     */
    public static void openClickGui() {
        if (client != null && client.player != null) {
            client.setScreen(new ClickGuiScreen());
        }
    }

    /**
     * Opens the HUD Editor screen.
     */
    public static void openHudEditor() {
        if (client != null && client.player != null) {
            client.setScreen(new HudEditorScreen());
        }
    }

    // Getters
    public static ModuleManager getModuleManager() { return moduleManager; }
    public static KeybindManager getKeybindManager() { return keybindManager; }
    public static HudManager getHudManager() { return hudManager; }
    public static NotificationManager getNotificationManager() { return notificationManager; }
    public static ConfigManager getConfigManager() { return configManager; }
    public static PerformanceManager getPerformanceManager() { return performanceManager; }
    public static RenderHelper getRenderHelper() { return renderHelper; }
    public static MinecraftClient getClient() { return client; }
    public static boolean isGlobalEnabled() { return globalEnabled; }
    public static void setGlobalEnabled(boolean enabled) { globalEnabled = enabled; }
    public static Logger getLogger() { return LOGGER; }
    public static String getModId() { return MOD_ID; }
}