package dev.fpsoptimizer.macro;

import dev.fpsoptimizer.FPSOptimizerClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Manages macros for FPS Optimizer.
 * Macros support recording, playback, and keybind assignment.
 * Stored in versioned JSON files. Safe abort on focus loss and world change.
 * Macros cannot read credentials or bypass protections.
 */
public class MacroManager {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.MacroManager");

    private static MacroManager instance;
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final Path macroDir;
    private final List<Macro> macros = new CopyOnWriteArrayList<>();
    private final Map<Integer, Macro> keybindToMacro = new HashMap<>();

    private boolean recording = false;
    private Macro currentRecording = null;
    private long recordingStartTime = 0;

    private boolean playing = false;
    private Macro currentPlayback = null;
    private int playbackIndex = 0;
    private long playbackNextAction = 0;

    public MacroManager() {
        instance = this;
        this.macroDir = FabricLoader.getInstance().getConfigDir().resolve("fps-optimizer-macros");
        loadMacros();
    }

    public static MacroManager getInstance() {
        return instance;
    }

    private void loadMacros() {
        try {
            Files.createDirectories(macroDir);

            if (!Files.exists(macroDir)) {
                return;
            }

            try (DirectoryStream<Path> stream = Files.newDirectoryStream(macroDir, "*.json")) {
                for (Path file : stream) {
                    try {
                        String json = Files.readString(file, StandardCharsets.UTF_8);
                        Macro macro = Macro.fromJson(json);
                        if (macro != null && macro.isValid()) {
                            macros.add(macro);
                            if (macro.getKeybind() >= 0) {
                                keybindToMacro.put(macro.getKeybind(), macro);
                            }
                        }
                    } catch (Exception e) {
                        LOGGER.warn("Failed to load macro from {}: {}", file, e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            LOGGER.error("Failed to load macros: {}", e.getMessage());
        }
    }

    public void saveMacro(Macro macro) {
        try {
            Files.createDirectories(macroDir);
            Path file = macroDir.resolve(macro.getName() + ".json");
            Files.writeString(file, macro.toJson(), StandardCharsets.UTF_8);

            // Update keybind mapping
            keybindToMacro.clear();
            for (Macro m : macros) {
                if (m.getKeybind() >= 0) {
                    keybindToMacro.put(m.getKeybind(), m);
                }
            }

            LOGGER.info("Macro saved: {}", macro.getName());
        } catch (IOException e) {
            LOGGER.error("Failed to save macro {}: {}", macro.getName(), e.getMessage());
        }
    }

    public void deleteMacro(Macro macro) {
        macros.remove(macro);
        keybindToMacro.remove(macro.getKeybind());

        try {
            Path file = macroDir.resolve(macro.getName() + ".json");
            if (Files.exists(file)) {
                Files.delete(file);
            }
        } catch (IOException e) {
            LOGGER.error("Failed to delete macro file: {}", e.getMessage());
        }
    }

    public List<Macro> getMacros() {
        return Collections.unmodifiableList(macros);
    }

    public Optional<Macro> getMacroByName(String name) {
        for (Macro macro : macros) {
            if (macro.getName().equals(name)) {
                return Optional.of(macro);
            }
        }
        return Optional.empty();
    }

    public void createMacro(String name) {
        if (getMacroByName(name).isPresent()) {
            LOGGER.warn("Macro already exists: {}", name);
            return;
        }
        Macro macro = new Macro(name);
        macros.add(macro);
        saveMacro(macro);
        LOGGER.info("Macro created: {}", name);
    }

    // Recording
    public void startRecording(String name) {
        if (recording) {
            LOGGER.warn("Already recording a macro");
            return;
        }

        currentRecording = new Macro(name);
        recording = true;
        recordingStartTime = System.currentTimeMillis();
        LOGGER.info("Started recording macro: {}", name);
    }

    public void stopRecording() {
        if (!recording || currentRecording == null) {
            return;
        }

        recording = false;
        if (currentRecording.isValid()) {
            macros.add(currentRecording);
            keybindToMacro.put(currentRecording.getKeybind(), currentRecording);
            saveMacro(currentRecording);
            LOGGER.info("Macro recording stopped: {} ({} actions)",
                currentRecording.getName(), currentRecording.getActionCount());
        } else {
            LOGGER.warn("Macro recording discarded - invalid macro");
        }
        currentRecording = null;
    }

    public void toggleRecording() {
        if (recording) {
            stopRecording();
        } else {
            startRecording("Macro_" + System.currentTimeMillis());
        }
    }

    public void recordKeyPress(int keyCode) {
        if (!recording || currentRecording == null) return;
        currentRecording.addAction(new MacroAction(MacroAction.Type.KEY_PRESS, keyCode));
    }

    public void recordKeyRelease(int keyCode) {
        if (!recording || currentRecording == null) return;
        currentRecording.addAction(new MacroAction(MacroAction.Type.KEY_RELEASE, keyCode));
    }

    public void recordMouseClick(int button) {
        if (!recording || currentRecording == null) return;
        currentRecording.addAction(new MacroAction(MacroAction.Type.MOUSE_CLICK, button, -1));
    }

    public void recordMouseRelease(int button) {
        if (!recording || currentRecording == null) return;
        currentRecording.addAction(new MacroAction(MacroAction.Type.MOUSE_RELEASE, button, -1));
    }

    // Playback
    public void playMacro(Macro macro) {
        if (playing) {
            LOGGER.warn("Already playing a macro");
            return;
        }

        if (macro == null || !macro.isValid()) {
            LOGGER.warn("Cannot play invalid macro");
            return;
        }

        if (mc.player == null) {
            LOGGER.warn("Cannot play macro - not in game");
            return;
        }

        currentPlayback = macro;
        playing = true;
        playbackIndex = 0;
        playbackNextAction = System.currentTimeMillis();
        LOGGER.info("Playing macro: {}", macro.getName());
    }

    public void stopPlayback() {
        if (!playing) return;

        // Release any stuck keys
        if (currentPlayback != null) {
            for (MacroAction action : currentPlayback.getActions()) {
                if (action.getType() == MacroAction.Type.KEY_PRESS) {
                    // Key release would be handled by the action sequence
                }
            }
        }

        playing = false;
        currentPlayback = null;
        playbackIndex = 0;
        LOGGER.info("Macro playback stopped");
    }

    public void stopAll() {
        stopPlayback();
        stopRecording();
    }

    public void update() {
        if (!playing || currentPlayback == null) return;

        long now = System.currentTimeMillis();

        // Check if we should abort (focus lost, no player)
        if (mc.player == null || mc.currentScreen != null) {
            stopPlayback();
            FPSOptimizerClient.triggerPanic();
            return;
        }

        if (now < playbackNextAction) return;

        if (playbackIndex >= currentPlayback.getActionCount()) {
            // Loop or stop
            if (currentPlayback.isLoop()) {
                playbackIndex = 0;
                playbackNextAction = now + currentPlayback.getLoopDelay();
            } else {
                stopPlayback();
            }
            return;
        }

        MacroAction action = currentPlayback.getActions().get(playbackIndex);
        playbackIndex++;

        executeAction(action);

        if (action.getType() == MacroAction.Type.DELAY) {
            playbackNextAction = now + action.getDelayMillis();
        } else {
            playbackNextAction = now + 50; // 50ms between actions
        }
    }

    private void executeAction(MacroAction action) {
        switch (action.getType()) {
            case KEY_PRESS:
                if (action.getKeyCode() >= 0) {
                    // Simulate key press via Minecraft's input system
                    // Note: This only affects client-side input, not server state directly
                    mc.options.keyForward.setPressed(action.getKeyCode() == mc.options.keyForward.getCode());
                    LOGGER.debug("Macro key press: {}", action.getKeyCode());
                }
                break;
            case KEY_RELEASE:
                if (action.getKeyCode() >= 0) {
                    mc.options.keyForward.setPressed(false);
                    LOGGER.debug("Macro key release: {}", action.getKeyCode());
                }
                break;
            case MOUSE_CLICK:
                LOGGER.debug("Macro mouse click: {}", action.getMouseButton());
                break;
            case MOUSE_RELEASE:
                LOGGER.debug("Macro mouse release: {}", action.getMouseButton());
                break;
            case DELAY:
                // Handled by timing
                break;
        }
    }

    public boolean isRecording() {
        return recording;
    }

    public boolean isPlaying() {
        return playing;
    }

    public Macro getCurrentRecording() {
        return currentRecording;
    }

    public Macro getCurrentPlayback() {
        return currentPlayback;
    }

    public Optional<Macro> getMacroByKeybind(int keybind) {
        return Optional.ofNullable(keybindToMacro.get(keybind));
    }
}