package dev.fpsoptimizer.macro;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a macro - a sequence of recorded or programmed actions.
 * Macros are stored in a versioned JSON format.
 * Macros cannot read credentials, bypass protections, or send unbounded inputs.
 */
public class Macro {

    public static final int FORMAT_VERSION = 2;

    @SerializedName("version")
    private int formatVersion = FORMAT_VERSION;

    @SerializedName("name")
    private String name;

    @SerializedName("keybind")
    private int keybind = -1;

    @SerializedName("actions")
    private List<MacroAction> actions = new ArrayList<>();

    @SerializedName("loop")
    private boolean loop = false;

    @SerializedName("loopDelay")
    private long loopDelay = 1000;

    @SerializedName("created")
    private long created = System.currentTimeMillis();

    @SerializedName("modified")
    private long modified = System.currentTimeMillis();

    public Macro(String name) {
        this.name = name;
        this.created = System.currentTimeMillis();
        this.modified = System.currentTimeMillis();
    }

    public int getFormatVersion() {
        return formatVersion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        this.modified = System.currentTimeMillis();
    }

    public int getKeybind() {
        return keybind;
    }

    public void setKeybind(int keybind) {
        this.keybind = keybind;
        this.modified = System.currentTimeMillis();
    }

    public List<MacroAction> getActions() {
        return actions;
    }

    public void addAction(MacroAction action) {
        if (action != null && action.isValid()) {
            actions.add(action);
            this.modified = System.currentTimeMillis();
        }
    }

    public void removeAction(int index) {
        if (index >= 0 && index < actions.size()) {
            actions.remove(index);
            this.modified = System.currentTimeMillis();
        }
    }

    public void clearActions() {
        actions.clear();
        this.modified = System.currentTimeMillis();
    }

    public boolean isLoop() {
        return loop;
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
        this.modified = System.currentTimeMillis();
    }

    public long getLoopDelay() {
        return loopDelay;
    }

    public void setLoopDelay(long loopDelay) {
        this.loopDelay = loopDelay;
        this.modified = System.currentTimeMillis();
    }

    public long getCreated() {
        return created;
    }

    public long getModified() {
        return modified;
    }

    public int getActionCount() {
        return actions.size();
    }

    /**
     * Validate the macro - check for unsafe patterns.
     * Macros cannot contain excessively long delays or action counts.
     */
    public boolean isValid() {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        if (actions.isEmpty()) {
            return false;
        }
        if (actions.size() > 1000) {
            return false; // Prevent excessively long macros
        }
        for (MacroAction action : actions) {
            if (!action.isValid()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Serialize macro to JSON string.
     */
    public String toJson() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(this);
    }

    /**
     * Deserialize macro from JSON string.
     */
    public static Macro fromJson(String json) {
        try {
            Gson gson = new GsonBuilder().create();
            Macro macro = gson.fromJson(json, Macro.class);
            if (macro != null) {
                // Ensure actions list is initialized
                if (macro.actions == null) {
                    macro.actions = new ArrayList<>();
                }
                if (macro.formatVersion == 0) {
                    macro.formatVersion = 1; // Legacy
                }
            }
            return macro;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return "Macro{name='" + name + "', actions=" + actions.size() + ", keybind=" + keybind + "}";
    }
}