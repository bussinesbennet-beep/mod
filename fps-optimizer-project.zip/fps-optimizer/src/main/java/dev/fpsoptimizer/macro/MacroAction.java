package dev.fpsoptimizer.macro;

/**
 * Represents a single action in a macro sequence.
 * Supports key presses, mouse clicks, and delays.
 */
public class MacroAction {

    public enum Type {
        KEY_PRESS,
        KEY_RELEASE,
        MOUSE_CLICK,
        MOUSE_RELEASE,
        DELAY
    }

    private final Type type;
    private final int keyCode;
    private final int mouseButton;
    private final long delayMillis;

    public MacroAction(Type type, int keyCode) {
        this.type = type;
        this.keyCode = keyCode;
        this.mouseButton = -1;
        this.delayMillis = 0;
    }

    public MacroAction(Type type, int mouseButton, int keyCode) {
        this.type = type;
        this.mouseButton = mouseButton;
        this.keyCode = keyCode;
        this.delayMillis = 0;
    }

    public MacroAction(Type type, long delayMillis) {
        this.type = type;
        this.keyCode = -1;
        this.mouseButton = -1;
        this.delayMillis = delayMillis;
    }

    public Type getType() {
        return type;
    }

    public int getKeyCode() {
        return keyCode;
    }

    public int getMouseButton() {
        return mouseButton;
    }

    public long getDelayMillis() {
        return delayMillis;
    }

    public boolean isValid() {
        switch (type) {
            case KEY_PRESS:
            case KEY_RELEASE:
                return keyCode >= 0;
            case MOUSE_CLICK:
            case MOUSE_RELEASE:
                return mouseButton >= 0;
            case DELAY:
                return delayMillis > 0;
            default:
                return false;
        }
    }

    @Override
    public String toString() {
        switch (type) {
            case KEY_PRESS: return "KEY_PRESS(" + keyCode + ")";
            case KEY_RELEASE: return "KEY_RELEASE(" + keyCode + ")";
            case MOUSE_CLICK: return "MOUSE_CLICK(" + mouseButton + ")";
            case MOUSE_RELEASE: return "MOUSE_RELEASE(" + mouseButton + ")";
            case DELAY: return "DELAY(" + delayMillis + "ms)";
            default: return "UNKNOWN";
        }
    }
}