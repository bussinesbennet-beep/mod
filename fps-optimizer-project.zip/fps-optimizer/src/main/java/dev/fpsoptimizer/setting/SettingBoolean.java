package dev.fpsoptimizer.setting;

/**
 * Boolean setting - true/false toggle.
 */
public class SettingBoolean extends Setting<Boolean> {

    public SettingBoolean(String name, boolean value, String description) {
        super(name, value, description);
    }

    @Override
    public String serialize() {
        return Boolean.toString(getValue());
    }

    @Override
    public void deserialize(String data) {
        try {
            setValue(Boolean.parseBoolean(data));
        } catch (Exception e) {
            setValue(false);
        }
    }

    @Override
    public SettingBoolean copy() {
        return new SettingBoolean(getName(), getValue(), getDescription());
    }
}