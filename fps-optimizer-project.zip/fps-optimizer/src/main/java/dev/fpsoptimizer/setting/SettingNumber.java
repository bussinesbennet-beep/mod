package dev.fpsoptimizer.setting;

/**
 * Number setting - numeric value with min/max bounds and step size.
 */
public class SettingNumber extends Setting<Double> {

    private final double min;
    private final double max;
    private final double step;

    public SettingNumber(String name, double value, double min, double max, double step, String description) {
        super(name, value, description);
        this.min = min;
        this.max = max;
        this.step = step;
        // Clamp initial value
        if (getValue() < min) setValue(min);
        if (getValue() > max) setValue(max);
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getStep() {
        return step;
    }

    public void setValue(double value) {
        if (value < min) value = min;
        if (value > max) value = max;
        super.setValue(value);
    }

    @Override
    public String serialize() {
        return Double.toString(getValue());
    }

    @Override
    public void deserialize(String data) {
        try {
            setValue(Double.parseDouble(data));
        } catch (Exception e) {
            setValue(0);
        }
    }

    @Override
    public SettingNumber copy() {
        return new SettingNumber(getName(), getValue(), min, max, step, getDescription());
    }

    public int intValue() {
        return getValue().intValue();
    }

    public float floatValue() {
        return getValue().floatValue();
    }
}