package dev.fpsoptimizer.setting;

import java.util.List;

/**
 * Enum setting - selects from a list of predefined options.
 */
public class SettingEnum<T extends Enum<T>> extends Setting<T> {

    private final List<T> options;

    public SettingEnum(String name, T value, List<T> options, String description) {
        super(name, value, description);
        this.options = options;
    }

    public List<T> getOptions() {
        return options;
    }

    public int getSelectedIndex() {
        return options.indexOf(getValue());
    }

    public void setSelectedIndex(int index) {
        if (index >= 0 && index < options.size()) {
            setValue(options.get(index));
        }
    }

    @Override
    public String serialize() {
        T value = getValue();
        return value != null ? value.name() : "";
    }

    @Override
    public void deserialize(String data) {
        try {
            for (T option : options) {
                if (option.name().equals(data)) {
                    setValue(option);
                    return;
                }
            }
            setValue(options.get(0));
        } catch (Exception e) {
            setValue(options.get(0));
        }
    }

    @Override
    public SettingEnum<T> copy() {
        return new SettingEnum<>(getName(), getValue(), options, getDescription());
    }
}