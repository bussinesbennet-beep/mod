package dev.fpsoptimizer.setting;

/**
 * Base class for all settings in FPS Optimizer.
 * Settings are typed and can be serialized/deserialized for configuration.
 *
 * @param <T> the type of value this setting holds
 */
public abstract class Setting<T> {

    private final String name;
    private final String description;
    private T value;

    public Setting(String name, T value, String description) {
        this.name = name;
        this.value = value;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    /**
     * Serialize the setting value to a string for storage.
     */
    public abstract String serialize();

    /**
     * Deserialize a setting value from a string.
     */
    public abstract void deserialize(String data);

    /**
     * Create a copy of this setting.
     */
    public abstract Setting<T> copy();
}