package dev.fpsoptimizer.setting;

/**
 * Color setting - stores an ARGB color as integer.
 */
public class SettingColor extends Setting<Integer> {

    public SettingColor(String name, int color, String description) {
        super(name, color, description);
    }

    @Override
    public String serialize() {
        return Integer.toString(getValue());
    }

    @Override
    public void deserialize(String data) {
        try {
            setValue(Integer.parseInt(data));
        } catch (Exception e) {
            setValue(0xFFFFFFFF);
        }
    }

    @Override
    public SettingColor copy() {
        return new SettingColor(getName(), getValue(), getDescription());
    }

    public int getRed() {
        return (getValue() >> 16) & 0xFF;
    }

    public int getGreen() {
        return (getValue() >> 8) & 0xFF;
    }

    public int getBlue() {
        return getValue() & 0xFF;
    }

    public int getAlpha() {
        return (getValue() >> 24) & 0xFF;
    }

    public float[] getRGBA() {
        int color = getValue();
        return new float[]{
            ((color >> 16) & 0xFF) / 255.0f,
            ((color >> 8) & 0xFF) / 255.0f,
            (color & 0xFF) / 255.0f,
            ((color >> 24) & 0xFF) / 255.0f
        };
    }
}