package dev.fpsoptimizer.keybind;

import dev.fpsoptimizer.FPSOptimizerClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Manages all keybinds for FPS Optimizer.
 * Handles global toggle, panic key, and module keybinds.
 * Processes each key input only once and handles focus changes correctly.
 */
public class KeybindManager {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.KeybindManager");

    private final MinecraftClient mc = MinecraftClient.getInstance();

    // Global keybinds
    private KeyBinding globalToggleKey;
    private KeyBinding panicKey;
    private KeyBinding clickGuiKey;
    private KeyBinding hudEditorKey;
    private KeyBinding freecamKey;
    private KeyBinding freeLookKey;
    private KeyBinding macroKey;

    // State tracking for single-press processing
    private boolean globalToggleProcessed = false;
    private boolean panicKeyProcessed = false;
    private boolean clickGuiProcessed = false;
    private boolean hudEditorProcessed = false;
    private boolean freecamProcessed = false;
    private boolean freeLookProcessed = false;
    private boolean macroProcessed = false;

    public KeybindManager() {
        registerKeybinds();
    }

    public void registerKeybinds() {
        // Global toggle - RIGHT_SHIFT by default
        globalToggleKey = new KeyBinding(
            "key.fpsoptimizer.toggle",
            InputUtil.Type.KEYSYM,
            InputUtil.KEY_RIGHT_SHIFT,
            "key.category.fpsoptimizer.main"
        );

        // Panic key - no default (configurable)
        panicKey = new KeyBinding(
            "key.fpsoptimizer.panic",
            InputUtil.Type.KEYSYM,
            InputUtil.UNKNOWN_KEY.getCode(),
            "key.category.fpsoptimizer.main"
        );

        // ClickGUI
        clickGuiKey = new KeyBinding(
            "key.fpsoptimizer.clickgui",
            InputUtil.Type.KEYSYM,
            InputUtil.KEY_O,
            "key.category.fpsoptimizer.gui"
        );

        // HUD Editor
        hudEditorKey = new KeyBinding(
            "key.fpsoptimizer.hud_editor",
            InputUtil.Type.KEYSYM,
            InputUtil.KEY_P,
            "key.category.fpsoptimizer.gui"
        );

        // Freecam
        freecamKey = new KeyBinding(
            "key.fpsoptimizer.freecam",
            InputUtil.Type.KEYSYM,
            InputUtil.KEY_F12,
            "key.category.fpsoptimizer.modules"
        );

        // Free Look
        freeLookKey = new KeyBinding(
            "key.fpsoptimizer.freelook",
            InputUtil.Type.KEYSYM,
            InputUtil.KEY_F11,
            "key.category.fpsoptimizer.modules"
        );

        // Macro
        macroKey = new KeyBinding(
            "key.fpsoptimizer.macro",
            InputUtil.Type.KEYSYM,
            InputUtil.KEY_M,
            "key.category.fpsoptimizer.modules"
        );

        // Register with ClientTickEvents for processing
        ClientTickEvents.END_CLIENT_TICK.register(client -> update());
    }

    public void update() {
        if (mc.player == null && mc.currentScreen == null) {
            // Reset processed states when not in game
            globalToggleProcessed = false;
            panicKeyProcessed = false;
            clickGuiProcessed = false;
            hudEditorProcessed = false;
            freecamProcessed = false;
            freeLookProcessed = false;
            macroProcessed = false;
            return;
        }

        // Process global toggle - only when game is not paused and no GUI is open
        if (globalToggleKey.isPressed() && !globalToggleProcessed && mc.currentScreen == null) {
            globalToggleProcessed = true;
            FPSOptimizerClient.getLogger().debug("Global toggle key pressed");
            // Toggle handled in FPSOptimizerClient
        }

        // Reset when key is released
        if (!globalToggleKey.isPressed()) {
            globalToggleProcessed = false;
        }

        // Process panic key - works even when GUI is open
        if (panicKey.isPressed() && !panicKeyProcessed) {
            panicKeyProcessed = true;
            FPSOptimizerClient.getLogger().warn("Panic key pressed");
            FPSOptimizerClient.triggerPanic();
        }

        if (!panicKey.isPressed()) {
            panicKeyProcessed = false;
        }

        // Process GUI keybinds - only when no screen is open
        if (clickGuiKey.isPressed() && !clickGuiProcessed && mc.currentScreen == null) {
            clickGuiProcessed = true;
            FPSOptimizerClient.openClickGui();
        }
        if (!clickGuiKey.isPressed()) {
            clickGuiProcessed = false;
        }

        if (hudEditorKey.isPressed() && !hudEditorProcessed && mc.currentScreen == null) {
            hudEditorProcessed = true;
            FPSOptimizerClient.openHudEditor();
        }
        if (!hudEditorKey.isPressed()) {
            hudEditorProcessed = false;
        }

        // Process module keybinds
        if (freecamKey.isPressed() && !freecamProcessed && mc.currentScreen == null) {
            freecamProcessed = true;
            toggleFreecam();
        }
        if (!freecamKey.isPressed()) {
            freecamProcessed = false;
        }

        if (freeLookKey.isPressed() && !freeLookProcessed && mc.currentScreen == null) {
            freeLookProcessed = true;
            toggleFreeLook();
        }
        if (!freeLookKey.isPressed()) {
            freeLookProcessed = false;
        }

        if (macroKey.isPressed() && !macroProcessed && mc.currentScreen == null) {
            macroProcessed = true;
            toggleMacro();
        }
        if (!macroKey.isPressed()) {
            macroProcessed = false;
        }
    }

    private void toggleFreecam() {
        var moduleManager = FPSOptimizerClient.getModuleManager();
        var freecam = moduleManager.getModuleByName("Freecam");
        if (freecam != null) {
            freecam.setEnabled(!freecam.isEnabled());
        }
    }

    private void toggleFreeLook() {
        var moduleManager = FPSOptimizerClient.getModuleManager();
        var freeLook = moduleManager.getModuleByName("Free Look");
        if (freeLook != null) {
            freeLook.setEnabled(!freeLook.isEnabled());
        }
    }

    private void toggleMacro() {
        var macroManager = dev.fpsoptimizer.macro.MacroManager.getInstance();
        macroManager.toggleRecording();
    }

    /**
     * Check if the global toggle keybind was pressed this tick.
     * Used by FPSOptimizerClient to toggle global state.
     */
    public boolean isGlobalTogglePressed() {
        return globalToggleKey.isPressed() && !globalToggleProcessed && mc.currentScreen == null;
    }

    /**
     * Check if the panic keybind was pressed this tick.
     */
    public boolean isPanicKeyPressed() {
        return panicKey.isPressed() && !panicKeyProcessed;
    }

    public KeyBinding getGlobalToggleKey() {
        return globalToggleKey;
    }

    public KeyBinding getPanicKey() {
        return panicKey;
    }

    public void clearPendingInputs() {
        globalToggleProcessed = true;
        panicKeyProcessed = true;
        clickGuiProcessed = true;
        hudEditorProcessed = true;
        freecamProcessed = true;
        freeLookProcessed = true;
        macroProcessed = true;
    }
}