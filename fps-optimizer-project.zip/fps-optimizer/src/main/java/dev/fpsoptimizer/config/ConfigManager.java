package dev.fpsoptimizer.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import dev.fpsoptimizer.FPSOptimizerClient;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/**
 * Manages configuration for FPS Optimizer.
 * Versioned configuration with safe defaults, validation, and migration.
 * No credentials are stored.
 */
public class ConfigManager {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.ConfigManager");

    private static final int CONFIG_VERSION = 3;
    private static final String CONFIG_FILE_NAME = "fps-optimizer.json";

    private final Gson gson;
    private final Path configPath;
    private ConfigData configData;

    public ConfigManager() {
        this.gson = new GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create();

        this.configPath = FabricLoader.getInstance()
            .getConfigDir()
            .resolve(CONFIG_FILE_NAME);

        this.configData = new ConfigData();
        this.configData.version = CONFIG_VERSION;
    }

    /**
     * Load configuration from disk.
     * If file doesn't exist or is corrupted, use safe defaults.
     */
    public void load() {
        try {
            if (!Files.exists(configPath)) {
                LOGGER.info("No configuration file found - creating default configuration");
                save();
                return;
            }

            String json = Files.readString(configPath, StandardCharsets.UTF_8);
            ConfigData loaded = gson.fromJson(json, ConfigData.class);

            if (loaded == null) {
                LOGGER.warn("Configuration file is empty - using defaults");
                configData = new ConfigData();
                configData.version = CONFIG_VERSION;
                return;
            }

            // Run migration if needed
            loaded = migrate(loaded);

            // Validate loaded data
            if (!validate(loaded)) {
                LOGGER.warn("Configuration validation failed - using defaults");
                configData = new ConfigData();
                configData.version = CONFIG_VERSION;
                return;
            }

            configData = loaded;
            LOGGER.info("Configuration loaded (version {})", configData.version);

        } catch (JsonSyntaxException e) {
            LOGGER.warn("Configuration file is corrupted - using defaults: {}", e.getMessage());
            configData = new ConfigData();
            configData.version = CONFIG_VERSION;
        } catch (IOException e) {
            LOGGER.error("Failed to read configuration file: {}", e.getMessage());
            configData = new ConfigData();
            configData.version = CONFIG_VERSION;
        }
    }

    /**
     * Save configuration to disk.
     * Only writes when data has changed.
     */
    public void save() {
        try {
            configData.version = CONFIG_VERSION;
            configData.lastModified = System.currentTimeMillis();

            String json = gson.toJson(configData);
            Files.createDirectories(configPath.getParent());
            Files.writeString(configPath, json, StandardCharsets.UTF_8);

            LOGGER.debug("Configuration saved");
        } catch (IOException e) {
            LOGGER.error("Failed to save configuration: {}", e.getMessage());
        }
    }

    /**
     * Migrate older configuration versions to the current version.
     */
    @SuppressWarnings("unchecked")
    private ConfigData migrate(ConfigData data) {
        int fromVersion = data.version;

        if (fromVersion >= CONFIG_VERSION) {
            return data;
        }

        LOGGER.info("Migrating configuration from version {} to {}", fromVersion, CONFIG_VERSION);

        if (fromVersion < 2) {
            // Migration v1 -> v2: rename module settings
            // (Example migration - actual field renames would go here)
        }

        if (fromVersion < 3) {
            // Migration v2 -> v3: add new fields
            if (data.moduleStates == null) {
                data.moduleStates = new java.util.HashMap<>();
            }
        }

        data.version = CONFIG_VERSION;
        return data;
    }

    /**
     * Validate configuration data for safety.
     */
    private boolean validate(ConfigData data) {
        if (data == null) return false;
        if (data.version < 1) return false;
        if (data.moduleStates == null) return false;
        if (data.keybinds == null) return false;
        return true;
    }

    public ConfigData getConfigData() {
        return configData;
    }

    public int getConfigVersion() {
        return CONFIG_VERSION;
    }
}