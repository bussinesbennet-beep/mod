package dev.fpsoptimizer.config;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration data model for FPS Optimizer.
 * Versioned and serializable to JSON.
 * No credentials are stored.
 */
public class ConfigData {

    public int version = 3;
    public long lastModified = System.currentTimeMillis();

    // Module states (enabled/disabled)
    public Map<String, Boolean> moduleStates = new HashMap<>();

    // Keybinds (key code per action)
    public Map<String, Integer> keybinds = new HashMap<>();

    // HUD element positions
    public Map<String, HudPosition> hudPositions = new HashMap<>();

    // Colors and display options
    public Map<String, Integer> colors = new HashMap<>();

    // Module parameters
    public Map<String, Object> moduleParameters = new HashMap<>();

    // Notification settings
    public boolean notificationsEnabled = true;
    public int notificationDuration = 5;

    // GUI settings
    public boolean guiOpen = false;
    public int guiScreenX = 100;
    public int guiScreenY = 100;

    public static class HudPosition {
        public int x = 0;
        public int y = 0;
        public boolean visible = true;
        public float scale = 1.0f;

        public HudPosition() {}

        public HudPosition(int x, int y, boolean visible, float scale) {
            this.x = x;
            this.y = y;
            this.visible = visible;
            this.scale = scale;
        }
    }
}