package dev.fpsoptimizer.navigation;

import dev.fpsoptimizer.FPSOptimizerClient;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Integration with Baritone pathfinding mod for Minecraft 26.2.
 * Baritone v1.19.0 for 26.2 (Fabric) is available from cabaletta/baritone.
 * This integration is optional - if Baritone is not installed, navigation
 * gracefully degrades without pathfinding.
 *
 * NOTE: Baritone uses its own internal API. This integration attempts to
 * communicate via Baritone's public API where available. If the specific
 * Baritone version doesn't expose a compatible API, the integration
 * reports itself as unavailable.
 */
public class BaritoneIntegration {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.Baritone");

    private boolean available = false;
    private Object baritoneProvider = null; // Reference to Baritone's API object
    private boolean initializationAttempted = false;

    public BaritoneIntegration() {
        attemptInitialization();
    }

    private void attemptInitialization() {
        if (initializationAttempted) {
            return;
        }
        initializationAttempted = true;

        try {
            // Try to load Baritone's main class to check availability
            Class<?> baritoneClass = Class.forName("baritone.api.BaritoneAPI");
            if (baritoneClass != null) {
                available = true;
                LOGGER.info("Baritone API detected - pathfinding integration available");
            }
        } catch (ClassNotFoundException e) {
            available = false;
            LOGGER.debug("Baritone not installed - navigation will use fallback mode");
        } catch (Throwable e) {
            available = false;
            LOGGER.warn("Error initializing Baritone integration: {}", e.getMessage());
        }
    }

    /**
     * Check if Baritone is available and compatible.
     */
    public boolean isAvailable() {
        return available;
    }

    /**
     * Start pathfinding to a target position.
     * If Baritone is not available, this is a no-op.
     */
    public void startPathfinding(BlockPos target) {
        if (!available) {
            return;
        }

        try {
            // Attempt to use Baritone's public API
            // The exact API depends on the Baritone version
            Class<?> apiClass = Class.forName("baritone.api.BaritoneAPI");
            var getInstance = apiClass.getMethod("get");
            Object api = getInstance.invoke(null);

            var getGoalProcess = apiClass.getMethod("getGoalProcess");
            Object goalProcess = getGoalProcess.invoke(api);

            var setGoal = goalProcess.getClass().getMethod("setGoal", Class.forName("baritone.api.process.Goal"));
            // Create a goal block position
            Class<?> goalClass = Class.forName("baritone.api.goal.GoalBlock");
            var goalConstructor = goalClass.getConstructor(int.class, int.class, int.class);
            Object goal = goalConstructor.newInstance(target.getX(), target.getY(), target.getZ());
            setGoal.invoke(goalProcess, goal);

            FPSOptimizerClient.getLogger().info("Baritone pathfinding started to {}", target);
        } catch (Exception e) {
            available = false;
            FPSOptimizerClient.getLogger().warn("Baritone pathfinding failed: {}", e.getMessage());
        }
    }

    /**
     * Stop any ongoing pathfinding.
     */
    public void stop() {
        if (!available) {
            return;
        }

        try {
            Class<?> apiClass = Class.forName("baritone.api.BaritoneAPI");
            var getInstance = apiClass.getMethod("get");
            Object api = getInstance.invoke(null);

            var getGoalProcess = apiClass.getMethod("getGoalProcess");
            Object goalProcess = getGoalProcess.invoke(api);

            var stop = goalProcess.getClass().getMethod("stop");
            stop.invoke(goalProcess);

            FPSOptimizerClient.getLogger().info("Baritone pathfinding stopped");
        } catch (Exception e) {
            FPSOptimizerClient.getLogger().warn("Error stopping Baritone: {}", e.getMessage());
        }
    }

    /**
     * Update Baritone state - called each tick.
     */
    public void update() {
        if (!available) {
            return;
        }
        // Baritone handles its own updates internally
    }
}