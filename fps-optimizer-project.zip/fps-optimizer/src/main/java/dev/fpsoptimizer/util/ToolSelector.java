package dev.fpsoptimizer.util;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

import java.util.*;

/**
 * Wählt automatisch das beste Werkzeug für einen Block aus.
 * Berücksichtigt Effizienz und Haltbarkeit.
 */
public class ToolSelector {

    private final BlockView world;

    public ToolSelector(BlockView world) {
        this.world = world;
    }

    /**
     * Findet den besten Slot für den angegebenen Block.
     * Gibt den Slot-Index zurück oder -1 wenn kein passendes Werkzeug gefunden wurde.
     */
    public int findBestToolSlot(net.minecraft.client.network.ClientPlayerEntity player, BlockPos pos) {
        if (player == null) return -1;

        var inventory = player.getInventory();
        var blockState = world.getBlockState(pos);
        Block block = blockState.getBlock();

        int bestSlot = -1;
        float bestEfficiency = 0.0f;

        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.isEmpty()) continue;

            Item item = stack.getItem();
            float efficiency = getToolEfficiency(item, blockState);

            if (efficiency <= 0.0f) continue;

            // Berücksichtige Haltbarkeit
            int maxDamage = stack.getMaxDamage();
            if (maxDamage > 0) {
                int damage = stack.getDamage();
                float durabilityPct = (float) (maxDamage - damage) / maxDamage * 100.0f;
                if (durabilityPct < 5.0f) continue; // Nicht benutzen wenn fast kaputt
            }

            if (efficiency > bestEfficiency) {
                bestEfficiency = efficiency;
                bestSlot = i;
            }
        }

        return bestSlot;
    }

    /**
     * Gibt die Effizienz eines Items für einen Block zurück.
     * 0.0 wenn das Item nicht geeignet ist.
     */
    private float getToolEfficiency(Item item, net.minecraft.block.BlockState state) {
        if (item instanceof ToolItem toolItem) {
            float speed = toolItem.getMiningSpeedMultiplier();
            if (speed > 1.0f) {
                return speed;
            }
        }
        return 0.0f;
    }

    /**
     * Prüft ob ein Block abbaubar ist.
     */
    public boolean isMineable(BlockPos pos) {
        if (world == null) return false;
        var state = world.getBlockState(pos);
        return !state.isAir();
    }
}