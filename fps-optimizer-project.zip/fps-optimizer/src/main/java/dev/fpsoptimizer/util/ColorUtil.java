package dev.fpsoptimizer.util;

/**
 * Color utility methods for FPS Optimizer.
 * All colors are stored as ARGB integers (0xAARRGGBB).
 */
public class ColorUtil {

    public static final int WHITE = 0xFFFFFFFF;
    public static final int BLACK = 0xFF000000;
    public static final int RED = 0xFFFF0000;
    public static final int GREEN = 0xFF00FF00;
    public static final int BLUE = 0xFF0000FF;
    public static final int YELLOW = 0xFFFFFF00;
    public static final int ORANGE = 0xFFFFA500;
    public static final int PURPLE = 0xFF800080;
    public static final int CYAN = 0xFF00FFFF;
    public static final int GRAY = 0xFF808080;
    public static final int DARK_GRAY = 0xFF404040;

    /**
     * Create an ARGB color from components.
     */
    public static int rgba(int r, int g, int b, int a) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * Create an ARGB color from RGB components with full alpha.
     */
    public static int rgb(int r, int g, int b) {
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /**
     * Get the red component (0-255).
     */
    public static int red(int color) {
        return (color >> 16) & 0xFF;
    }

    /**
     * Get the green component (0-255).
     */
    public static int green(int color) {
        return (color >> 8) & 0xFF;
    }

    /**
     * Get the blue component (0-255).
     */
    public static int blue(int color) {
        return color & 0xFF;
    }

    /**
     * Get the alpha component (0-255).
     */
    public static int alpha(int color) {
        return (color >> 24) & 0xFF;
    }

    /**
     * Interpolate between two colors.
     * @param factor 0.0 to 1.0
     */
    public static int interpolate(int color1, int color2, float factor) {
        if (factor <= 0) return color1;
        if (factor >= 1) return color2;

        int a1 = alpha(color1), r1 = red(color1), g1 = green(color1), b1 = blue(color1);
        int a2 = alpha(color2), r2 = red(color2), g2 = green(color2), b2 = blue(color2);

        int a = (int) (a1 + (a2 - a1) * factor);
        int r = (int) (r1 + (r2 - r1) * factor);
        int g = (int) (g1 + (g2 - g1) * factor);
        int b = (int) (b1 + (b2 - b1) * factor);

        return rgba(r, g, b, a);
    }

    /**
     * Multiply color brightness by a factor.
     */
    public static int brightness(int color, float factor) {
        int a = alpha(color);
        int r = Math.min(255, Math.max(0, (int) (red(color) * factor)));
        int g = Math.min(255, Math.max(0, (int) (green(color) * factor)));
        int b = Math.min(255, Math.max(0, (int) (blue(color) * factor)));
        return rgba(r, g, b, a);
    }
}