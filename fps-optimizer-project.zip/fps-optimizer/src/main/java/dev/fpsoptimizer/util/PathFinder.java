package dev.fpsoptimizer.util;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * Einfache A*-Pfadfindung für die Navigation zu Koordinaten.
 * Berechnet den kürzesten Weg zwischen zwei Punkten in der Welt.
 * Blockiert nicht den Hauptthread - wird in kleinen Schritten pro Tick ausgeführt.
 */
public class PathFinder {

    private static class Node {
        BlockPos pos;
        double gCost; // Kosten vom Start
        double hCost; // Heuristik zum Ziel
        Node parent;

        Node(BlockPos pos, double gCost, double hCost, Node parent) {
            this.pos = pos;
            this.gCost = gCost;
            this.hCost = hCost;
            this.parent = parent;
        }

        double getFCost() {
            return gCost + hCost;
        }
    }

    /**
     * Berechnet einen Pfad von start zu goal.
     * Gibt eine Liste von BlockPos zurück oder null wenn kein Pfad gefunden wurde.
     *
     * @param start Startposition
     * @param goal Zielposition
     * @param maxNodes Maximale Anzahl zu untersuchender Knoten (Performance-Limit)
     * @return Liste von Wegpunkten oder null
     */
    public static List<BlockPos> findPath(BlockPos start, BlockPos goal, int maxNodes) {
        if (start.equals(goal)) {
            List<BlockPos> path = new ArrayList<>();
            path.add(goal);
            return path;
        }

        PriorityQueue<Node> openSet = new PriorityQueue<>(Comparator.comparingDouble(Node::getFCost));
        Set<BlockPos> closedSet = new HashSet<>();
        Map<BlockPos, Node> allNodes = new HashMap<>();

        Node startNode = new Node(start, 0, heuristic(start, goal), null);
        openSet.add(startNode);
        allNodes.put(start, startNode);

        int nodesChecked = 0;

        while (!openSet.isEmpty() && nodesChecked < maxNodes) {
            Node current = openSet.poll();
            nodesChecked++;

            if (current.pos.equals(goal)) {
                return reconstructPath(current);
            }

            closedSet.add(current.pos);

            // 26 Nachbarn prüfen (3x3x3 ohne Mitte)
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;

                        BlockPos neighborPos = current.pos.add(dx, dy, dz);

                        if (closedSet.contains(neighborPos)) continue;

                        double tentativeGCost = current.gCost + distance(current.pos, neighborPos);

                        Node neighborNode = allNodes.get(neighborPos);
                        if (neighborNode == null) {
                            neighborNode = new Node(neighborPos, tentativeGCost, heuristic(neighborPos, goal), current);
                            allNodes.put(neighborPos, neighborNode);
                            openSet.add(neighborNode);
                        } else if (tentativeGCost < neighborNode.gCost) {
                            neighborNode.gCost = tentativeGCost;
                            neighborNode.parent = current;
                            // openSet neu sortieren durch Entfernen und Hinzufügen
                            openSet.remove(neighborNode);
                            openSet.add(neighborNode);
                        }
                    }
                }
            }
        }

        return null; // Kein Pfad gefunden innerhalb des Limits
    }

    private static double heuristic(BlockPos a, BlockPos b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY()) + Math.abs(a.getZ() - b.getZ());
    }

    private static double distance(BlockPos a, BlockPos b) {
        return Math.sqrt(Math.pow(a.getX() - b.getX(), 2) + Math.pow(a.getY() - b.getY(), 2) + Math.pow(a.getZ() - b.getZ(), 2));
    }

    private static List<BlockPos> reconstructPath(Node end) {
        List<BlockPos> path = new ArrayList<>();
        Node current = end;
        while (current != null) {
            path.add(current.pos);
            current = current.parent;
        }
        Collections.reverse(path);
        return path;
    }

    /**
     * Berechnet den kürzesten Weg zu einem Ziel mit Bewertung mehrerer Strecken.
     * Gibt den besten Pfad zurück oder null.
     */
    public static List<BlockPos> findBestPath(Vec3d startPos, BlockPos goal, int maxNodes) {
        BlockPos start = new BlockPos(startPos);
        List<BlockPos> path = findPath(start, goal, maxNodes);
        return path;
    }

    /**
     * Prüft ob ein Block begehbar ist (kein Vollblock).
     */
    public static boolean isWalkable(net.minecraft.block.BlockState state) {
        return !state.isOpaque() || !state.isSolidBlock(net.minecraft.block.BlockView.dummy(), state.getPos());
    }
}