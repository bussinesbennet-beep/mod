package dev.fpsoptimizer.gui;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.hud.HudElement;
import dev.fpsoptimizer.hud.HudManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * HUD Editor screen for FPS Optimizer.
 * Allows dragging HUD elements, grid snapping, and position saving.
 * Uses vanilla-styled UI consistent with ClickGUI.
 */
public class HudEditorScreen extends Screen {

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final HudManager hudManager = FPSOptimizerClient.getHudManager();

    private int screenX = 100;
    private int screenY = 100;
    private int screenWidth = 400;
    private int screenHeight = 300;

    private boolean dragging = false;
    private HudElement draggedElement = null;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;
    private int dragStartX, dragStartY;

    private boolean gridSnap = false;
    private int gridSize = 16;

    public HudEditorScreen() {
        super(Text.literal("HUD Editor"));
    }

    @Override
    protected void init() {
        super.init();

        int scaledWidth = mc.getWindow().getScaledWidth();
        int scaledHeight = mc.getWindow().getScaledHeight();
        this.screenX = Math.max(50, Math.min(screenX, scaledWidth - screenWidth - 50));
        this.screenY = Math.max(50, Math.min(screenY, scaledHeight - screenHeight - 50));

        // Close button
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Close"),
            button -> {
                hudManager.setEditorOpen(false);
                mc.setScreen(null);
                FPSOptimizerClient.getConfigManager().save();
            }
        ).position(screenX + screenWidth - 60, screenY + screenHeight - 30)
          .size(50, 20).build());

        // Grid snap toggle
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Grid: " + (gridSnap ? "ON" : "OFF")),
            button -> {
                gridSnap = !gridSnap;
                button.setMessage(Text.literal("Grid: " + (gridSnap ? "ON" : "OFF")));
            }
        ).position(screenX + 10, screenY + screenHeight - 30)
          .size(70, 20).build());

        // Save button
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Save"),
            button -> {
                FPSOptimizerClient.getConfigManager().save();
            }
        ).position(screenX + 90, screenY + screenHeight - 30)
          .size(50, 20).build());

        // Reset button
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Reset"),
            button -> {
                for (HudElement element : hudManager.getElements()) {
                    element.setPosition(10, 10);
                }
            }
        ).position(screenX + 150, screenY + screenHeight - 30)
          .size(50, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float tickDelta) {
        // Draw background
        context.fill(0, 0, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), 0x80000000);

        // Draw game behind (don't call super.render which would clear)
        // We draw our overlay on top

        // Draw editor panel
        context.fill(screenX, screenY, screenX + screenWidth, screenY + screenHeight, 0xFF404040);
        context.fill(screenX + 1, screenY + 1, screenX + screenWidth - 1, screenY + screenHeight - 1, 0xFF2A2A2A);
        context.drawBorder(screenX, screenY, screenWidth, screenHeight, 0xFF000000);

        // Draw title
        context.drawText(textRenderer, "HUD Editor", screenX + 10, screenY + 10, 0xFFFFFF, false);

        // Draw instructions
        context.drawText(textRenderer, "Drag elements to reposition them", screenX + 10, screenY + 30, 0xAAAAAA, false);

        // Draw HUD elements (preview mode)
        for (HudElement element : hudManager.getElements()) {
            drawElementPreview(context, element, mouseX, mouseY);
        }

        // Draw grid if enabled
        if (gridSnap) {
            drawGrid(context);
        }

        super.render(context, mouseX, mouseY, tickDelta);
    }

    private void drawElementPreview(DrawContext context, HudElement element, int mouseX, int mouseY) {
        if (!element.isVisible()) return;

        // Draw element bounds
        int x = element.getX();
        int y = element.getY();
        int w = element.getScaledWidth();
        int h = element.getScaledHeight();

        boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        boolean selected = (draggedElement == element);

        int bgColor = selected ? 0xFF4A90E2 : (hovered ? 0xFF4A4A4A : 0xFF3A3A3A);
        context.fill(x, y, x + w, y + h, bgColor);
        context.drawBorder(x, y, w, h, selected ? 0xFF00FF00 : 0xFF000000);

        // Draw element name
        context.drawText(textRenderer, element.getName(), x + 3, y + 3, 0xFFFFFF, false);

        // Draw coordinates
        context.drawText(textRenderer, "X:" + x + " Y:" + y, x + 3, y + h - 8, 0x888888, false);
    }

    private void drawGrid(DrawContext context) {
        int scaledWidth = mc.getWindow().getScaledWidth();
        int scaledHeight = mc.getWindow().getScaledHeight();

        for (int x = 0; x < scaledWidth; x += gridSize) {
            context.fill(x, 0, x + 1, scaledHeight, 0x20FFFFFF);
        }
        for (int y = 0; y < scaledHeight; y += gridSize) {
            context.fill(0, y, scaledWidth, y + 1, 0x20FFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }

        // Check drag on panel header
        if (button == 0 && mouseX >= screenX && mouseX <= screenX + screenWidth &&
            mouseY >= screenY && mouseY <= screenY + 20) {
            dragging = true;
            dragStartX = (int) mouseX;
            dragStartY = (int) mouseY;
            return true;
        }

        // Check if clicking on a HUD element
        if (button == 0) {
            for (HudElement element : hudManager.getElements()) {
                if (element.contains((int) mouseX, (int) mouseY)) {
                    draggedElement = element;
                    dragOffsetX = (int) mouseX - element.getX();
                    dragOffsetY = (int) mouseY - element.getY();
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging && button == 0) {
            screenX += deltaX;
            screenY += deltaY;

            int scaledWidth = mc.getWindow().getScaledWidth();
            int scaledHeight = mc.getWindow().getScaledHeight();
            screenX = Math.max(50, Math.min(screenX, scaledWidth - screenWidth - 50));
            screenY = Math.max(50, Math.min(screenY, scaledHeight - screenHeight - 50));
            return true;
        }

        if (draggedElement != null && button == 0) {
            int newX = (int) mouseX - dragOffsetX;
            int newY = (int) mouseY - dragOffsetY;

            if (gridSnap) {
                newX = Math.round(newX / (float) gridSize) * gridSize;
                newY = Math.round(newY / (float) gridSize) * gridSize;
            }

            // Clamp to screen bounds
            int scaledWidth = mc.getWindow().getScaledWidth();
            int scaledHeight = mc.getWindow().getScaledHeight();
            int sw = draggedElement.getScaledWidth();
            int sh = draggedElement.getScaledHeight();
            newX = Math.max(0, Math.min(newX, scaledWidth - sw));
            newY = Math.max(0, Math.min(newY, scaledHeight - sh));

            draggedElement.setPosition(newX, newY);
            return true;
        }

        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        draggedElement = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputUtil.KEY_ESCAPE) {
            hudManager.setEditorOpen(false);
            mc.setScreen(null);
            FPSOptimizerClient.getConfigManager().save();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}