package dev.fpsoptimizer.gui;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingColor;
import dev.fpsoptimizer.setting.SettingEnum;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * ClickGUI screen for FPS Optimizer.
 * Vanilla-styled mod menu with categories, search, and per-module settings.
 * Uses Minecraft's built-in screen widgets and rendering.
 */
public class ClickGuiScreen extends Screen {

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();

    // Screen state
    private int screenX = 100;
    private int screenY = 100;
    private int screenWidth = 400;
    private int screenHeight = 300;
    private boolean dragging = false;
    private int dragStartX, dragStartY;

    // Category tabs
    private ModuleCategory selectedCategory = ModuleCategory.HUD;
    private int categoryScroll = 0;

    // Module list
    private int moduleScroll = 0;
    private int selectedModuleIndex = -1;
    private Module selectedModule = null;

    // Search
    private TextFieldWidget searchField;
    private String searchQuery = "";

    // Settings panel
    private int settingsScroll = 0;

    // Drag bounds
    private int minX = 50;
    private int minY = 50;
    private int maxX;
    private int maxY;

    public ClickGuiScreen() {
        super(Text.literal("FPS Optimizer - ClickGUI"));
        this.maxX = mc.getWindow().getScaledWidth() - 50;
        this.maxY = mc.getWindow().getScaledHeight() - 50;
    }

    @Override
    protected void init() {
        super.init();

        // Calculate screen bounds based on scaled resolution
        int scaledWidth = mc.getWindow().getScaledWidth();
        int scaledHeight = mc.getWindow().getScaledHeight();
        this.maxX = scaledWidth - 50;
        this.maxY = scaledHeight - 50;

        // Ensure screen is within bounds
        this.screenX = Math.max(minX, Math.min(screenX, maxX - screenWidth));
        this.screenY = Math.max(minY, Math.min(screenY, maxY - screenHeight));

        // Create search field
        int searchX = screenX + 10;
        int searchY = screenY + 40;
        int searchWidth = screenWidth - 20;
        this.searchField = new TextFieldWidget(
            textRenderer,
            searchX,
            searchY,
            searchWidth,
            20,
            Text.literal("Search modules...")
        );
        searchField.setChangedListener(str -> {
            this.searchQuery = str;
            this.moduleScroll = 0;
            this.selectedModuleIndex = -1;
            this.selectedModule = null;
        });
        addDrawableChild(searchField);

        // Create category buttons
        createCategoryButtons();

        // Create close button
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Close"),
            button -> mc.setScreen(null)
        ).position(screenX + screenWidth - 60, screenY + screenHeight - 30)
          .size(50, 20).build());
    }

    private void createCategoryButtons() {
        int buttonY = screenY + 70;
        int buttonX = screenX + 10;
        int buttonWidth = 70;
        int buttonHeight = 22;

        for (int i = 0; i < ModuleCategory.values().length; i++) {
            ModuleCategory category = ModuleCategory.values()[i];
            int categoryX = buttonX + (i * (buttonWidth + 5));

            addDrawableChild(ButtonWidget.builder(
                Text.literal(category.getDisplayName()),
                button -> {
                    selectedCategory = category;
                    moduleScroll = 0;
                    selectedModuleIndex = -1;
                    selectedModule = null;
                }
            ).position(categoryX, buttonY)
              .size(buttonWidth, buttonHeight)
              .color(selectedCategory == category ? 0xFF4A90E2 : 0xFF404040)
              .build());
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float tickDelta) {
        // Draw background
        context.fill(0, 0, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), 0x80000000);

        // Draw GUI background (vanilla-style gray)
        context.fill(screenX, screenY, screenX + screenWidth, screenY + screenHeight, 0xFF404040);
        context.fill(screenX + 1, screenY + 1, screenX + screenWidth - 1, screenY + screenHeight - 1, 0xFF2A2A2A);

        // Draw border
        context.drawBorder(screenX, screenY, screenWidth, screenHeight, 0xFF000000);

        // Draw title
        context.drawText(textRenderer, "FPS Optimizer - ClickGUI", screenX + 10, screenY + 10, 0xFFFFFF, false);

        // Draw search field
        searchField.setX(screenX + 10);
        searchField.setY(screenY + 40);
        searchField.setWidth(screenWidth - 20);
        searchField.render(context, mouseX, mouseY, tickDelta);

        // Draw category buttons
        drawCategories(context, mouseX, mouseY, tickDelta);

        // Draw module list
        drawModuleList(context, mouseX, mouseY, tickDelta);

        // Draw settings panel if a module is selected
        if (selectedModule != null) {
            drawSettingsPanel(context, mouseX, mouseY, tickDelta);
        }

        super.render(context, mouseX, mouseY, tickDelta);
    }

    private void drawCategories(DrawContext context, int mouseX, int mouseY, float tickDelta) {
        int buttonY = screenY + 70;
        int buttonX = screenX + 10;
        int buttonWidth = 70;
        int buttonHeight = 22;

        for (ModuleCategory category : ModuleCategory.values()) {
            int categoryX = buttonX;
            buttonX += buttonWidth + 5;

            boolean selected = selectedCategory == category;
            int bgColor = selected ? 0xFF4A90E2 : 0xFF404040;
            int textColor = 0xFFFFFF;

            context.fill(categoryX, buttonY, categoryX + buttonWidth, buttonY + buttonHeight, bgColor);
            context.drawBorder(categoryX, buttonY, buttonWidth, buttonHeight, 0xFF000000);

            // Draw category name
            int textWidth = textRenderer.getWidth(category.getDisplayName());
            context.drawText(textRenderer, category.getDisplayName(),
                categoryX + (buttonWidth - textWidth) / 2,
                buttonY + (buttonHeight - 8) / 2,
                textColor, false);

            // Draw module count for this category
            int count = moduleManager.getModulesByCategory(category).size();
            context.drawText(textRenderer, String.valueOf(count),
                categoryX + buttonWidth - 12,
                buttonY + 3,
                0xAAAAAA, false);
        }
    }

    private void drawModuleList(DrawContext context, int mouseX, int mouseY, float tickDelta) {
        int listX = screenX + 10;
        int listY = screenY + 100;
        int listWidth = screenWidth - 20;
        int listHeight = screenHeight - 130;

        // Draw list background
        context.fill(listX, listY, listX + listWidth, listY + listHeight, 0xFF303030);
        context.drawBorder(listX, listY, listWidth, listHeight, 0xFF000000);

        // Get filtered modules
        List<Module> filteredModules = getFilteredModules();

        int itemHeight = 22;
        int visibleItems = listHeight / itemHeight;
        int start = Math.max(0, moduleScroll);
        int end = Math.min(filteredModules.size(), start + visibleItems);

        int y = listY;
        for (int i = start; i < end; i++) {
            Module module = filteredModules.get(i);
            boolean selected = (i == selectedModuleIndex);
            boolean enabled = module.isEnabled();

            int bgColor = selected ? 0xFF4A90E2 : (enabled ? 0xFF3A3A3A : 0xFF2A2A2A);
            int textColor = enabled ? 0xFFFFFF : 0x888888;

            context.fill(listX, y, listX + listWidth, y + itemHeight, bgColor);
            context.drawBorder(listX, y, listWidth, itemHeight, 0xFF000000);

            // Draw enabled indicator
            context.fill(listX + 3, y + 3, listX + 12, y + 12, enabled ? 0xFF00FF00 : 0xFF444444);

            // Draw module name
            context.drawText(textRenderer, module.getName(), listX + 18, y + 5, textColor, false);

            // Draw keybind if assigned
            // (Would show actual keybind here)

            y += itemHeight;
        }

        // Draw scrollbar if needed
        if (filteredModules.size() > visibleItems) {
            int scrollBarX = listX + listWidth - 4;
            int scrollBarHeight = (int) ((double) visibleItems / filteredModules.size() * listHeight);
            int scrollBarY = listY + (int) ((double) moduleScroll / filteredModules.size() * listHeight);
            context.fill(scrollBarX, scrollBarY, scrollBarX + 4, scrollBarY + scrollBarHeight, 0xFF666666);
        }

        if (filteredModules.isEmpty()) {
            context.drawText(textRenderer, Text.literal("No modules found"), listX + 5, listY + 5, 0x888888, false);
        }
    }

    private List<Module> getFilteredModules() {
        List<Module> result = new ArrayList<>();
        List<Module> allModules = moduleManager.getModulesByCategory(selectedCategory);

        for (Module module : allModules) {
            if (searchQuery.isEmpty() || module.getName().toLowerCase().contains(searchQuery.toLowerCase())) {
                result.add(module);
            }
        }
        return result;
    }

    private void drawSettingsPanel(DrawContext context, int mouseX, int mouseY, float tickDelta) {
        if (selectedModule == null) return;

        int panelX = screenX + 10;
        int panelY = screenY + screenHeight - 90;
        int panelWidth = screenWidth - 20;
        int panelHeight = 80;

        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF303030);
        context.drawBorder(panelX, panelY, panelWidth, panelHeight, 0xFF000000);

        context.drawText(textRenderer, "Settings: " + selectedModule.getName(), panelX + 5, panelY + 5, 0xFFFFFF, false);

        // Draw settings
        int settingY = panelY + 20;
        int settingX = panelX + 5;

        for (var setting : selectedModule.getSettings()) {
            if (setting instanceof SettingBoolean boolSetting) {
                drawBooleanSetting(context, settingX, settingY, boolSetting);
                settingY += 20;
            } else if (setting instanceof SettingNumber numSetting) {
                drawNumberSetting(context, settingX, settingY, numSetting);
                settingY += 20;
            } else if (setting instanceof SettingColor colorSetting) {
                drawColorSetting(context, settingX, settingY, colorSetting);
                settingY += 20;
            }
        }
    }

    private void drawBooleanSetting(DrawContext context, int x, int y, SettingBoolean setting) {
        context.fill(x, y, x + 12, y + 12, setting.getValue() ? 0xFF00FF00 : 0xFF444444);
        context.drawBorder(x, y, 12, 12, 0xFF000000);
        context.drawText(textRenderer, setting.getName(), x + 16, y + 2, 0xFFFFFF, false);
    }

    private void drawNumberSetting(DrawContext context, int x, int y, SettingNumber setting) {
        context.drawText(textRenderer, setting.getName() + ": " + setting.getValue(), x, y + 2, 0xFFFFFF, false);
    }

    private void drawColorSetting(DrawContext context, int x, int y, SettingColor setting) {
        int color = setting.getValue();
        context.fill(x, y, x + 12, y + 12, color);
        context.drawBorder(x, y, 12, 12, 0xFF000000);
        context.drawText(textRenderer, setting.getName(), x + 16, y + 2, 0xFFFFFF, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }

        // Check drag
        if (button == 0 && mouseX >= screenX && mouseX <= screenX + screenWidth &&
            mouseY >= screenY && mouseY <= screenY + 20) {
            dragging = true;
            dragStartX = (int) mouseX;
            dragStartY = (int) mouseY;
            return true;
        }

        // Check module list clicks
        int listX = screenX + 10;
        int listY = screenY + 100;
        int listWidth = screenWidth - 20;
        int itemHeight = 22;

        if (mouseX >= listX && mouseX <= listX + listWidth &&
            mouseY >= listY && mouseY <= listY + screenHeight - 130) {

            List<Module> filteredModules = getFilteredModules();
            int visibleItems = (screenHeight - 130) / itemHeight;
            int start = Math.max(0, moduleScroll);

            int relativeY = (int) (mouseY - listY);
            int index = start + relativeY / itemHeight;

            if (index >= 0 && index < filteredModules.size()) {
                selectedModuleIndex = index;
                selectedModule = filteredModules.get(index);
                settingsScroll = 0;
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging && button == 0) {
            screenX += deltaX;
            screenY += deltaY;

            // Clamp to screen bounds
            screenX = Math.max(minX, Math.min(screenX, maxX - screenWidth));
            screenY = Math.max(minY, Math.min(screenY, maxY - screenHeight));

            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        List<Module> filteredModules = getFilteredModules();
        int visibleItems = (screenHeight - 130) / 22;

        if (filteredModules.size() > visibleItems) {
            moduleScroll = (int) MathUtil.clamp(
                moduleScroll - (int) amount,
                0,
                Math.max(0, filteredModules.size() - visibleItems)
            );
        }
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputUtil.KEY_ESCAPE) {
            mc.setScreen(null);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        // Save GUI position to config
        FPSOptimizerClient.getConfigManager().getConfigData().guiScreenX = screenX;
        FPSOptimizerClient.getConfigManager().getConfigData().guiScreenY = screenY;
        FPSOptimizerClient.getConfigManager().save();
    }
}