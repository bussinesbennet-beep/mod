package dev.fpsoptimizer.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.RenderLayer;
import org.joml.Matrix4f;

/**
 * Render helper utilities for FPS Optimizer.
 * Provides safe rendering methods using Minecraft's built-in rendering APIs.
 * No raw OpenGL calls - all rendering goes through Blaze3D/VertexConsumer.
 */
public class RenderHelper {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    /**
     * Draw a line in world space.
     */
    public void drawLine(MatrixStack matrixStack, VertexConsumer consumer,
                         float x1, float y1, float z1,
                         float x2, float y2, float z2,
                         float r, float g, float b, float a) {
        Matrix4f matrix = matrixStack.peek().getPositionMatrix();
        consumer.vertex(matrix, x1, y1, z1).color(r, g, b, a).next();
        consumer.vertex(matrix, x2, y2, z2).color(r, g, b, a).next();
    }

    /**
     * Draw a box outline in world space.
     */
    public void drawBox(MatrixStack matrixStack, VertexConsumer consumer,
                        double minX, double minY, double minZ,
                        double maxX, double maxY, double maxZ,
                        float r, float g, float b, float a) {
        drawLine(matrixStack, consumer,
            (float) minX, (float) minY, (float) minZ,
            (float) maxX, (float) minY, (float) minZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) maxX, (float) minY, (float) minZ,
            (float) maxX, (float) maxY, (float) minZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) maxX, (float) maxY, (float) minZ,
            (float) minX, (float) maxY, (float) minZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) minX, (float) maxY, (float) minZ,
            (float) minX, (float) minY, (float) minZ,
            r, g, b, a);

        drawLine(matrixStack, consumer,
            (float) minX, (float) minY, (float) maxZ,
            (float) maxX, (float) minY, (float) maxZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) maxX, (float) minY, (float) maxZ,
            (float) maxX, (float) maxY, (float) maxZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) maxX, (float) maxY, (float) maxZ,
            (float) minX, (float) maxY, (float) maxZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) minX, (float) maxY, (float) maxZ,
            (float) minX, (float) minY, (float) maxZ,
            r, g, b, a);

        drawLine(matrixStack, consumer,
            (float) minX, (float) minY, (float) minZ,
            (float) minX, (float) minY, (float) maxZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) maxX, (float) minY, (float) minZ,
            (float) maxX, (float) minY, (float) maxZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) maxX, (float) maxY, (float) minZ,
            (float) maxX, (float) maxY, (float) maxZ,
            r, g, b, a);
        drawLine(matrixStack, consumer,
            (float) minX, (float) maxY, (float) minZ,
            (float) minX, (float) maxY, (float) maxZ,
            r, g, b, a);
    }

    /**
     * Get a vertex consumer for line rendering.
     */
    public VertexConsumer getLineConsumer() {
        return mc.getVertexConsumers().getBuffer(RenderLayer.getLines());
    }
}