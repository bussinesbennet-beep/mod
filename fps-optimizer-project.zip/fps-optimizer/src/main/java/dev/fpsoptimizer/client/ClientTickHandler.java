package dev.fpsoptimizer.client;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.macro.MacroManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

/**
 * Client tick handler for FPS Optimizer.
 * Coordinates per-tick updates across all systems.
 */
public class ClientTickHandler {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public ClientTickHandler() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onEndClientTick);
    }

    private void onEndClientTick(MinecraftClient client) {
        if (client == null) {
            return;
        }

        // Update macro manager
        MacroManager macroManager = MacroManager.getInstance();
        if (macroManager != null) {
            macroManager.update();
        }

        // Handle world change detection
        checkWorldChange();
    }

    private void checkWorldChange() {
        // World change detection would be handled by world events
        // For now, we rely on module-level reset handling
    }
}