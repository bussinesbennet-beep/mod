package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hand.Hand;

/**
 * AutoEat module - automatically eats food when hunger is low.
 * Only for singleplayer and allowed test environments.
 * Handles death, world changes, missing items, and inventory changes.
 */
public class AutoEatModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingNumber hungerThreshold = new SettingNumber("Hunger Threshold", 14.0, 0.0, 20.0, 1.0, "Eat when hunger is below this value");
    private final SettingBoolean onlyWhenSafe = new SettingBoolean("Only When Safe", true, "Only eat when not taking damage");

    private int previousSlot = -1;
    private boolean eating = false;
    private int eatStartTick = 0;
    private static final int EAT_DURATION_TICKS = 32;

    public AutoEatModule() {
        super("AutoEat", "Isst automatisch Nahrung, wenn der Hunger niedrig ist.", ModuleCategory.UTILITY);
        addSetting(hungerThreshold);
        addSetting(onlyWhenSafe);
    }

    @Override
    public void onEnable() {
        previousSlot = -1;
        eating = false;
        eatStartTick = 0;
    }

    @Override
    public void onDisable() {
        restoreSlot();
        eating = false;
    }

    @Override
    public void onReset() {
        restoreSlot();
        eating = false;
        eatStartTick = 0;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.player == null) {
            restoreSlot();
            eating = false;
            return;
        }

        // If we're in the middle of eating, wait for completion
        if (eating) {
            if (mc.player.getTicksEating() > 0 || mc.player.isUsingItem()) {
                // Still eating
                if (mc.player.getTicksEating() >= EAT_DURATION_TICKS) {
                    // Eating complete, restore slot
                    restoreSlot();
                    eating = false;
                    eatStartTick = 0;
                }
                return;
            } else {
                // Eating was interrupted
                restoreSlot();
                eating = false;
                eatStartTick = 0;
            }
        }

        // Check if we need to eat
        if (!shouldEat()) {
            restoreSlot();
            return;
        }

        // Find food item
        int foodSlot = findFoodSlot();
        if (foodSlot == -1) {
            // No food available
            return;
        }

        // Save current slot and switch to food
        previousSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = foodSlot;

        // Start eating
        ItemStack stack = mc.player.getStackInHand(Hand.MAIN_HAND);
        if (!stack.isEmpty() && isFood(stack)) {
            mc.player.setCurrentHand(Hand.MAIN_HAND);
            eating = true;
            eatStartTick = mc.player.age;
        }
    }

    @Override
    public void onPanic() {
        stop();
    }

    public void stop() {
        restoreSlot();
        eating = false;
        eatStartTick = 0;
    }

    private void restoreSlot() {
        if (previousSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = previousSlot;
            previousSlot = -1;
        }
    }

    private boolean shouldEat() {
        // Check hunger level
        ClientPlayerEntity player = mc.player;
        float hunger = player.getHungerManager().getHungerLevel();
        return hunger <= hungerThreshold.getValue();
    }

    private int findFoodSlot() {
        if (mc.player == null) {
            return -1;
        }

        var inventory = mc.player.getInventory();

        // Check hotbar first
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && isFood(stack)) {
                return i;
            }
        }

        // Check rest of inventory
        for (int i = 9; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && isFood(stack)) {
                return i;
            }
        }

        return -1;
    }

    private boolean isFood(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        Item item = stack.getItem();
        // Check if item is edible
        return item.isFood() || item == Items.COOKED_PORKCHOP || item == Items.COOKED_BEEF ||
               item == Items.COOKED_CHICKEN || item == Items.COOKED_MUTTON || item == Items.COOKED_RABBIT ||
               item == Items.COOKED_SALMON || item == Items.COOKED_COD || item == Items.BREAD ||
               item == Items.APPLE || item == Items.GOLDEN_APPLE || item == Items.ENCHANTED_GOLDEN_APPLE ||
               item == Items.COOKIE || item == Items.CAKE || item == Items.MUSHROOM_STEW ||
               item == Items.BEETROOT_SOUP || item == Items.RABBIT_STEW || item == Items.POTATO ||
               item == Items.CARROT || item == Items.SWEET_BERRIES || item == Items.GLOW_BERRIES;
    }

    public boolean isEating() {
        return eating;
    }
}