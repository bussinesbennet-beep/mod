package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import net.minecraft.client.MinecraftClient;

/**
 * Status HUD module - displays status of active modules.
 */
public class HudStatusModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showFullbright = new SettingBoolean("Fullbright", true, "Show Fullbright status");
    private final SettingBoolean showFreecam = new SettingBoolean("Freecam", true, "Show Freecam status");
    private final SettingBoolean showAutoTool = new SettingBoolean("AutoTool", true, "Show AutoTool status");
    private final SettingBoolean showAutoEat = new SettingBoolean("AutoEat", true, "Show AutoEat status");
    private final SettingBoolean showNavigation = new SettingBoolean("Navigation", true, "Show Navigation status");

    public HudStatusModule() {
        super("Status", "Zeigt den Status aktiver Module an.", ModuleCategory.HUD);
        addSetting(showFullbright);
        addSetting(showFreecam);
        addSetting(showAutoTool);
        addSetting(showAutoEat);
        addSetting(showNavigation);
    }

    @Override
    public void onEnable() {
        // No state
    }

    @Override
    public void onDisable() {
        // No cleanup
    }

    @Override
    public void onPanic() {
        // No state
    }

    public boolean isModuleActive(String moduleName) {
        return FPSOptimizerClient.getModuleManager().isModuleEnabled(moduleName);
    }

    public boolean isShowFullbright() { return showFullbright.getValue(); }
    public boolean isShowFreecam() { return showFreecam.getValue(); }
    public boolean isShowAutoTool() { return showAutoTool.getValue(); }
    public boolean isShowAutoEat() { return showAutoEat.getValue(); }
    public boolean isShowNavigation() { return showNavigation.getValue(); }
}