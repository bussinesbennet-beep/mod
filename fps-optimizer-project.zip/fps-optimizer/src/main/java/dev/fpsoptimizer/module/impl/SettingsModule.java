package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;

/**
 * Settings module - manages global mod settings.
 * This is a pseudo-module that holds global configuration options.
 */
public class SettingsModule extends Module {

    private final SettingBoolean showWelcomeMessage = new SettingBoolean("Show Welcome", true, "Show welcome message on startup");
    private final SettingBoolean debugMode = new SettingBoolean("Debug Mode", false, "Enable debug logging");
    private final SettingNumber logLevel = new SettingNumber("Log Level", 1, 0, 3, 1, "Verbosity of log output");

    public SettingsModule() {
        super("Settings", "Globale Einstellungen für FPS Optimizer.", ModuleCategory.SETTINGS);
        addSetting(showWelcomeMessage);
        addSetting(debugMode);
        addSetting(logLevel);
    }

    @Override
    public void onEnable() {
        // Settings module is always conceptual
    }

    @Override
    public void onDisable() {
        // No cleanup needed
    }

    @Override
    public void onPanic() {
        // No permanent changes
    }

    public boolean isShowWelcomeMessage() {
        return showWelcomeMessage.getValue();
    }

    public boolean isDebugMode() {
        return debugMode.getValue();
    }

    public int getLogLevel() {
        return logLevel.getValue().intValue();
    }
}