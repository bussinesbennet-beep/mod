package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import dev.fpsoptimizer.setting.SettingEnum;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * KillAura Module - greift automatisch Mobs in Reichweite an.
 * Konfigurierbare Mob-Auswahl (einzelne Mobs, alle, oder bis zu 10 spezifische).
 * Sicherer Abbruch bei Panik, Weltwechsel, Tod und Fokusverlust.
 */
public class KillAuraModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean attackAll = new SettingBoolean("Attack All", true, "Angriffe auf alle Mobs");
    private final SettingNumber range = new SettingNumber("Range", 5.0, 1.0, 15.0, 0.5, "Angriffsreichweite in Blöcken");
    private final SettingNumber attackDelay = new SettingNumber("Attack Delay", 5, 1, 20, 1, "Ticks zwischen Angriffen");
    private final SettingBoolean onlyHostile = new SettingBoolean("Only Hostile", true, "Nur feindliche Mobs angreifen");
    private final SettingBoolean ignorePlayers = new SettingBoolean("Ignore Players", true, "Spieler nicht angreifen");

    // Spezifische Mob-Auswahl (bis zu 10)
    private final SettingBoolean selectSpecific = new SettingBoolean("Select Specific Mobs", false, "Bestimmte Mobs auswählen statt aller");
    private final SettingNumber maxSelectedMobs = new SettingNumber("Max Selected Mobs", 5, 1, 10, 1, "Maximale Anzahl ausgewählter Mob-Typen");

    private int ticksSinceLastAttack = 0;
    private LivingEntity currentTarget = null;

    public KillAuraModule() {
        super("KillAura", "Greift automatisch Mobs in Reichweite an.", ModuleCategory.UTILITY);
        addSetting(attackAll);
        addSetting(range);
        addSetting(attackDelay);
        addSetting(onlyHostile);
        addSetting(ignorePlayers);
        addSetting(selectSpecific);
        addSetting(maxSelectedMobs);
    }

    @Override
    public void onEnable() {
        ticksSinceLastAttack = 0;
        currentTarget = null;
    }

    @Override
    public void onDisable() {
        currentTarget = null;
    }

    @Override
    public void onReset() {
        currentTarget = null;
        ticksSinceLastAttack = 0;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.player == null || mc.world == null) {
            currentTarget = null;
            return;
        }

        ticksSinceLastAttack++;

        if (ticksSinceLastAttack < attackDelay.getValue()) {
            return;
        }

        LivingEntity target = findBestTarget();
        if (target != null) {
            currentTarget = target;
            attackTarget(target);
            ticksSinceLastAttack = 0;
        } else {
            currentTarget = null;
        }
    }

    @Override
    public void onPanic() {
        currentTarget = null;
        ticksSinceLastAttack = 0;
    }

    @Override
    public void onRender(float tickDelta) {
        // Optional: Ziel hervorheben
    }

    private LivingEntity findBestTarget() {
        if (mc.player == null || mc.world == null) return null;

        double range = this.range.getValue();
        List<LivingEntity> candidates = new ArrayList<>();

        ClientWorld world = mc.world;

        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity == mc.player) continue;
            if (ignorePlayers.getValue() && entity instanceof PlayerEntity) continue;
            if (!living.isAlive()) continue;

            double dist = entity.distanceTo(mc.player);
            if (dist > range) continue;

            // Mob-Typ prüfen
            if (!isTargetMob(entity)) continue;

            // Nur feindliche Mobs wenn eingestellt
            if (onlyHostile.getValue() && !isHostile(entity)) continue;

            candidates.add(living);
        }

        if (candidates.isEmpty()) return null;

        // Nächstes Ziel wählen
        candidates.sort((a, b) -> Double.compare(a.distanceTo(mc.player), b.distanceTo(mc.player)));
        return candidates.get(0);
    }

    private boolean isTargetMob(Entity entity) {
        if (selectSpecific.getValue()) {
            // Wenn spezifische Auswahl aktiv, nur Mobs angreifen die in der Liste sind
            // Hier würde eine konfigurierbare Liste stehen, für jetzt: alle Mobs außer Spieler
            return entity instanceof MobEntity;
        }
        return entity instanceof LivingEntity;
    }

    private boolean isHostile(Entity entity) {
        // Einfache Prüfung auf feindliche Mobs
        return entity instanceof net.minecraft.entity.mob.HostileEntity ||
               entity.getType() == net.minecraft.entity.EntityType.ZOMBIE ||
               entity.getType() == net.minecraft.entity.EntityType.SKELETON ||
               entity.getType() == net.minecraft.entity.EntityType.CREEPER ||
               entity.getType() == net.minecraft.entity.EntityType.SPIDER ||
               entity.getType() == net.minecraft.entity.EntityType.ENDERMAN ||
               entity.getType() == net.minecraft.entity.EntityType.WITCH;
    }

    private void attackTarget(LivingEntity target) {
        if (mc.player == null || mc.interactionManager == null) return;

        // Blickrichtung zum Ziel ausrichten
        Vec3d targetPos = target.getPos();
        double dx = targetPos.getX() - mc.player.getX();
        double dy = targetPos.getY() - mc.player.getEyeY();
        double dz = targetPos.getZ() - mc.player.getZ();

        float yaw = (float) (Math.toDegrees(Math.atan2(-dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));

        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);

        // Angriff ausführen
        mc.interactionManager.attackEntity(mc.player, target);
    }

    public LivingEntity getCurrentTarget() {
        return currentTarget;
    }

    public double getRange() {
        return range.getValue();
    }
}