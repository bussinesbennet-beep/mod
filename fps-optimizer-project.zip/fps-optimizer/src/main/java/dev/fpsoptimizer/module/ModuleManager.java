package dev.fpsoptimizer.module;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.impl.*;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Manages all modules in the FPS Optimizer mod.
 * Handles registration, enabling/disabling, ticking, and rendering of modules.
 */
public class ModuleManager {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.ModuleManager");

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final List<Module> modules = new CopyOnWriteArrayList<>();
    private boolean initialized = false;

    public ModuleManager() {
        registerModules();
    }

    private void registerModules() {
        // HUD modules
        register(new FpsHudModule());
        register(new CoordsHudModule());
        register(new ArmorHudModule());
        register(new KeystrokesModule());
        register(new CpsModule());
        register(new TargetInfoModule());
        register(new StatusHudModule());

        // Visuals modules
        register(new FullbrightModule());
        register(new RadarModule());
        register(new StorageEspModule());
        register(new BlockEspModule());
        register(new EntityEspModule());
        register(new ParticleReductionModule());
        register(new FogControlModule());

        // Utility modules
        register(new AutoToolModule());
        register(new AutoEatModule());
        register(new FreecamModule());
        register(new FreeLookModule());
        register(new KillAuraModule());
        register(new OreFarmerModule());

        // Navigation modules
        register(new NavigationModule());
        register(new AutoWalkModule());

        // World Analysis modules
        register(new ChunkAnalyzerModule());

        // Performance modules
        register(new PerformanceModule());

        // Settings module (for global config)
        register(new SettingsModule());

        LOGGER.info("Registered {} modules", modules.size());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public void initialize() {
        if (initialized) {
            return;
        }
        initialized = true;
        LOGGER.info("ModuleManager initialized");
    }

    public void update() {
        if (!initialized) {
            return;
        }

        for (Module module : modules) {
            if (module.isEnabled() && module.isGlobalEnabled()) {
                module.onTick();
            }
        }
    }

    public void render(float tickDelta) {
        if (!initialized) {
            return;
        }

        for (Module module : modules) {
            if (module.isEnabled() && module.isGlobalEnabled()) {
                module.onRender(tickDelta);
            }
        }
    }

    public void enableAllModules() {
        for (Module module : modules) {
            module.setEnabled(true);
        }
    }

    public void disableAllModules() {
        for (Module module : modules) {
            module.setEnabled(false);
        }
    }

    public void stopAllAutomation() {
        for (Module module : modules) {
            if (module instanceof AutoToolModule autoTool) {
                autoTool.stop();
            }
            if (module instanceof AutoEatModule autoEat) {
                autoEat.stop();
            }
            if (module instanceof NavigationModule navigation) {
                navigation.stop();
            }
            if (module instanceof AutoWalkModule autoWalk) {
                autoWalk.stopNavigation();
            }
            if (module instanceof KillAuraModule killAura) {
                killAura.onPanic();
            }
            if (module instanceof OreFarmerModule oreFarmer) {
                oreFarmer.onPanic();
            }
            if (module instanceof MacroModule macro) {
                macro.stopAll();
            }
        }
    }

    public void resetFreecam() {
        for (Module module : modules) {
            if (module instanceof FreecamModule freecam) {
                freecam.reset();
            }
        }
    }

    public void resetFreeLook() {
        for (Module module : modules) {
            if (module instanceof FreeLookModule freeLook) {
                freeLook.reset();
            }
        }
    }

    public void onWorldChange() {
        for (Module module : modules) {
            module.onReset();
        }
        stopAllAutomation();
        resetFreecam();
        resetFreeLook();
    }

    public Module getModuleByName(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }
        return null;
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(ModuleCategory category) {
        List<Module> result = new ArrayList<>();
        for (Module module : modules) {
            if (module.getCategory() == category) {
                result.add(module);
            }
        }
        return result;
    }

    public boolean isModuleEnabled(String name) {
        Module module = getModuleByName(name);
        return module != null && module.isEnabled();
    }

    public void setModuleEnabled(String name, boolean enabled) {
        Module module = getModuleByName(name);
        if (module != null) {
            module.setEnabled(enabled);
        }
    }

    public boolean isInitialized() {
        return initialized;
    }
}