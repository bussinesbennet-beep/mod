package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.joml.Vector3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Freecam module - allows free camera movement for testing and spectating.
 * Does NOT change the actual server position of the player.
 * Safe exit via keybind, resets on world change, disconnect, and death.
 */
public class FreecamModule extends Module {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.Freecam");

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingNumber speed = new SettingNumber("Speed", 0.5, 0.1, 5.0, 0.1, "Movement speed multiplier");
    private final SettingBoolean acceleration = new SettingBoolean("Acceleration", true, "Gradually accelerate when moving");
    private final SettingBoolean hideHand = new SettingBoolean("Hide Hand", false, "Hide player hand while in freecam");
    private final SettingBoolean hidePlayer = new SettingBoolean("Hide Player Model", false, "Hide player model while in freecam");

    private boolean active = false;
    private double camX, camY, camZ;
    private float camYaw, camPitch;
    private Vector3d velocity = new Vector3d(0, 0, 0);
    private double originalPlayerX, originalPlayerY, originalPlayerZ;
    private float originalPlayerYaw, originalPlayerPitch;
    private boolean wasNoClip = false;
    private boolean wasSneaking = false;
    private boolean wasSprinting = false;

    // Keybinds for freecam movement
    private KeyBinding keyForward;
    private KeyBinding keyBack;
    private KeyBinding keyLeft;
    private KeyBinding keyRight;
    private KeyBinding keyUp;
    private KeyBinding keyDown;
    private KeyBinding keyToggle;

    public FreecamModule() {
        super("Freecam", "Ermöglicht freie Kamerabewegung zum Testen und Zuschauen.", ModuleCategory.UTILITY);
        addSetting(speed);
        addSetting(acceleration);
        addSetting(hideHand);
        addSetting(hidePlayer);
    }

    @Override
    public void onEnable() {
        if (!isInGame()) {
            setEnabled(false);
            return;
        }

        active = true;
        camX = mc.player.getX();
        camY = mc.player.getY();
        camZ = mc.player.getZ();
        camYaw = mc.player.getYaw();
        camPitch = mc.player.getPitch();

        originalPlayerX = mc.player.getX();
        originalPlayerY = mc.player.getY();
        originalPlayerZ = mc.player.getZ();
        originalPlayerYaw = mc.player.getYaw();
        originalPlayerPitch = mc.player.getPitch();

        velocity.set(0, 0, 0);

        // Save player state
        wasNoClip = mc.player.hasNoGravity();
        wasSneaking = mc.player.isSneaking();
        wasSprinting = mc.player.isSprinting();

        // Initialize keybinds
        initKeybinds();

        FPSOptimizerClient.getNotificationManager().add(
            "notification.fpsoptimizer.freecam_enabled",
            "Freecam aktiviert",
            "Freie Kamerabewegung aktiv"
        );
    }

    @Override
    public void onDisable() {
        reset();
    }

    @Override
    public void onReset() {
        if (active) {
            reset();
        }
    }

    @Override
    public void onTick() {
        if (!active || !isInGame()) {
            return;
        }

        // Prevent player from taking damage or interacting while in freecam
        mc.player.setNoGravity(true);
        mc.player.setSprinting(false);
        mc.player.setSneaking(false);
        mc.player.setSpeed(0.0f);

        // Update camera position based on input
        updateCameraMovement();

        // Apply camera position to the render camera (not the player entity)
        // This only affects rendering, not server position
        mc.gameRenderer.getCamera().setPosition(camX, camY, camZ);
        mc.gameRenderer.getCamera().setYaw(camYaw);
        mc.gameRenderer.getCamera().setPitch(camPitch);
    }

    @Override
    public void onRender(float tickDelta) {
        if (!active) {
            return;
        }
        // Render logic handled in onTick via camera manipulation
    }

    @Override
    public void onPanic() {
        reset();
    }

    private void initKeybinds() {
        keyForward = new KeyBinding("fpsoptimizer.freecam.forward", InputUtil.Type.KEYSYM, InputUtil.KEY_W, "key.fpsoptimizer.freecam");
        keyBack = new KeyBinding("fpsoptimizer.freecam.back", InputUtil.Type.KEYSYM, InputUtil.KEY_S, "key.fpsoptimizer.freecam");
        keyLeft = new KeyBinding("fpsoptimizer.freecam.left", InputUtil.Type.KEYSYM, InputUtil.KEY_A, "key.fpsoptimizer.freecam");
        keyRight = new KeyBinding("fpsoptimizer.freecam.right", InputUtil.Type.KEYSYM, InputUtil.KEY_D, "key.fpsoptimizer.freecam");
        keyUp = new KeyBinding("fpsoptimizer.freecam.up", InputUtil.Type.KEYSYM, InputUtil.KEY_SPACE, "key.fpsoptimizer.freecam");
        keyDown = new KeyBinding("fpsoptimizer.freecam.down", InputUtil.Type.KEYSYM, InputUtil.KEY_LEFT_SHIFT, "key.fpsoptimizer.freecam");
        keyToggle = new KeyBinding("fpsoptimizer.freecam.toggle", InputUtil.Type.KEYSYM, InputUtil.KEY_F12, "key.fpsoptimizer.freecam");
    }

    private void updateCameraMovement() {
        double moveSpeed = speed.getValue();
        double accelFactor = acceleration.getValue() ? 0.1 : 1.0;

        double dx = 0, dy = 0, dz = 0;

        if (keyForward.isPressed()) dz -= 1;
        if (keyBack.isPressed()) dz += 1;
        if (keyLeft.isPressed()) dx -= 1;
        if (keyRight.isPressed()) dx += 1;
        if (keyUp.isPressed()) dy += 1;
        if (keyDown.isPressed()) dy -= 1;

        // Normalize diagonal movement
        double length = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (length > 0) {
            dx /= length;
            dy /= length;
            dz /= length;
        }

        // Apply camera-relative movement
        double yawRad = Math.toRadians(camYaw);
        double forwardX = -Math.sin(yawRad);
        double forwardZ = Math.cos(yawRad);
        double strafeX = Math.cos(yawRad);
        double strafeZ = Math.sin(yawRad);

        double moveX = dx * forwardX + dz * strafeX;
        double moveZ = dx * forwardZ + dz * strafeZ;

        // Apply velocity with optional acceleration
        if (acceleration.getValue()) {
            velocity.x += moveX * moveSpeed * accelFactor;
            velocity.y += dy * moveSpeed * accelFactor;
            velocity.z += moveZ * moveSpeed * accelFactor;
            // Friction
            velocity.multiply(0.9);
        } else {
            velocity.x = moveX * moveSpeed;
            velocity.y = dy * moveSpeed;
            velocity.z = moveZ * moveSpeed;
        }

        camX += velocity.x;
        camY += velocity.y;
        camZ += velocity.z;

        // Rotate camera with mouse if enabled
        // Note: Mouse look is handled by vanilla; we just preserve current rotation
    }

    private void reset() {
        if (!active) {
            return;
        }

        active = false;
        velocity.set(0, 0, 0);

        // Restore player state
        if (mc.player != null) {
            mc.player.setNoGravity(wasNoClip);
            mc.player.setSneaking(wasSneaking);
            mc.player.setSprinting(wasSprinting);
        }

        // Restore camera to player
        if (mc.gameRenderer != null && mc.gameRenderer.getCamera() != null) {
            mc.gameRenderer.getCamera().setPosition(
                mc.player != null ? mc.player.getX() : 0,
                mc.player != null ? mc.player.getY() : 0,
                mc.player != null ? mc.player.getZ() : 0
            );
            mc.gameRenderer.getCamera().setYaw(mc.player != null ? mc.player.getYaw() : 0);
            mc.gameRenderer.getCamera().setPitch(mc.player != null ? mc.player.getPitch() : 0);
        }

        FPSOptimizerClient.getNotificationManager().add(
            "notification.fpsoptimizer.freecam_disabled",
            "Freecam deaktiviert",
            "Kamera zurückgesetzt"
        );
    }

    public boolean isActive() {
        return active;
    }

    public void reset() {
        reset();
    }
}