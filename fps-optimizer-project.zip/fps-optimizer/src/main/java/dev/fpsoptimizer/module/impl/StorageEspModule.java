package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingColor;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.RenderLayer;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Storage ESP module - highlights storage blocks in the world.
 * Only uses client-side known world information.
 */
public class StorageEspModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showChests = new SettingBoolean("Show Chests", true, "Highlight chest blocks");
    private final SettingBoolean showBarrels = new SettingBoolean("Show Barrels", true, "Highlight barrel blocks");
    private final SettingBoolean showShulkerBoxes = new SettingBoolean("Show Shulker Boxes", true, "Highlight shulker box blocks");
    private final SettingBoolean showEnderChests = new SettingBoolean("Show Ender Chests", true, "Highlight ender chest blocks");
    private final SettingNumber range = new SettingNumber("Range", 64.0, 10.0, 256.0, 5.0, "Maximum render distance");
    private final SettingColor color = new SettingColor("Color", 0xFFFFD700, "ESP box color");

    private int ticksSinceUpdate = 0;
    private List<BlockPos> storageBlocks = new ArrayList<>();

    public StorageEspModule() {
        super("Storage ESP", "Hebt Lagerblöcke in der Welt hervor.", ModuleCategory.VISUALS);
        addSetting(showChests);
        addSetting(showBarrels);
        addSetting(showShulkerBoxes);
        addSetting(showEnderChests);
        addSetting(range);
        addSetting(color);
    }

    @Override
    public void onEnable() {
        storageBlocks.clear();
        ticksSinceUpdate = 0;
    }

    @Override
    public void onDisable() {
        storageBlocks.clear();
    }

    @Override
    public void onReset() {
        storageBlocks.clear();
        ticksSinceUpdate = 0;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.world == null || mc.player == null) {
            return;
        }

        ticksSinceUpdate++;
        if (ticksSinceUpdate < 10) { // Update every 10 ticks (0.5 seconds)
            return;
        }
        ticksSinceUpdate = 0;

        updateStorageBlocks();
    }

    private void updateStorageBlocks() {
        storageBlocks.clear();

        if (mc.player == null || mc.world == null) {
            return;
        }

        BlockPos playerPos = mc.player.getBlockPos();
        int rangeBlocks = (int) (range.getValue() / 4); // Convert to chunk-ish range

        // Scan nearby blocks for storage blocks
        for (int x = -rangeBlocks; x <= rangeBlocks; x++) {
            for (int y = -rangeBlocks; y <= rangeBlocks; y++) {
                for (int z = -rangeBlocks; z <= rangeBlocks; z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    if (mc.world.isChunkLoaded(pos)) {
                        var state = mc.world.getBlockState(pos);
                        Block block = state.getBlock();

                        if (isStorageBlock(block)) {
                            storageBlocks.add(pos);
                        }
                    }
                }
            }

            // Limit the number of blocks to prevent performance issues
            if (storageBlocks.size() > 500) {
                break;
            }
        }
    }

    private boolean isStorageBlock(Block block) {
        if (!showChests.getValue() && block == Blocks.CHEST) return false;
        if (!showChests.getValue() && block == Blocks.TRAPPED_CHEST) return false;
        if (!showBarrels.getValue() && block == Blocks.BARREL) return false;
        if (!showShulkerBoxes.getValue() && block == Blocks.SHULKER_BOX) return false;
        if (!showEnderChests.getValue() && block == Blocks.ENDER_CHEST) return false;

        return block == Blocks.CHEST ||
               block == Blocks.TRAPPED_CHEST ||
               block == Blocks.BARREL ||
               block == Blocks.SHULKER_BOX ||
               block == Blocks.ENDER_CHEST;
    }

    @Override
    public void onRender(float tickDelta) {
        if (!isInGame() || mc.world == null || mc.player == null || mc.gameRenderer == null) {
            return;
        }

        double camX = mc.gameRenderer.getCamera().getX();
        double camY = mc.gameRenderer.getCamera().getY();
        double camZ = mc.gameRenderer.getCamera().getZ();

        MatrixStack matrixStack = new MatrixStack();
        VertexConsumerProvider.Immediate immediate = mc.getVertexConsumers();
        VertexConsumer vertexConsumer = immediate.getBuffer(RenderLayer.getLines());

        Matrix4f matrix = matrixStack.peek().getPositionMatrix();
        int color = color.getValue();
        float r = ((color >> 16) & 0xFF) / 255.0f;
        float g = ((color >> 8) & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        float a = 0.8f;

        for (BlockPos pos : storageBlocks) {
            double dx = pos.getX() - camX;
            double dy = pos.getY() - camY;
            double dz = pos.getZ() - camZ;

            Box box = new Box(dx, dy, dz, dx + 1, dy + 1, dz + 1);

            // Draw bounding box
            drawBox(matrixStack, vertexConsumer, box, r, g, b, a);
        }

        immediate.draw();
    }

    private void drawBox(MatrixStack matrixStack, VertexConsumer vertexConsumer, Box box, float r, float g, float b, float a) {
        Matrix4f matrix = matrixStack.peek().getPositionMatrix();

        // Draw 12 edges of the box
        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.minZ, box.maxX, box.minY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.minZ, box.maxX, box.maxY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.minZ, box.minX, box.maxY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.minZ, box.minX, box.minY, box.minZ, r, g, b, a);

        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.maxZ, box.maxX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.maxZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.maxZ, box.minX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.maxZ, box.minX, box.minY, box.maxZ, r, g, b, a);

        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.minZ, box.minX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.minZ, box.maxX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.minZ, box.minX, box.maxY, box.maxZ, r, g, b, a);
    }

    private void drawLine(Matrix4f matrix, VertexConsumer consumer, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
        consumer.vertex(matrix, x1, y1, z1).color(r, g, b, a).next();
        consumer.vertex(matrix, x2, y2, z2).color(r, g, b, a).next();
    }

    @Override
    public void onPanic() {
        storageBlocks.clear();
    }
}