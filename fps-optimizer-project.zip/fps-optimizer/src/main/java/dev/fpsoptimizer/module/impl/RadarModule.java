package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.joml.Vector2f;

import java.util.ArrayList;
import java.util.List;

/**
 * Radar module - displays a radar showing nearby players and entities.
 * Only uses client-side known information. No artificial detection of unavailable data.
 */
public class RadarModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingNumber range = new SettingNumber("Range", 100.0, 10.0, 1000.0, 10.0, "Maximum radar range in blocks");
    private final SettingBoolean fixedNorth = new SettingBoolean("Fixed North", false, "Keep radar oriented to north instead of player rotation");
    private final SettingBoolean showPlayers = new SettingBoolean("Show Players", true, "Display players on radar");
    private final SettingBoolean showEntities = new SettingBoolean("Show Entities", true, "Display other entities on radar");
    private final SettingNumber size = new SettingNumber("Size", 120.0, 40.0, 300.0, 10.0, "Radar size in pixels");
    private final SettingNumber updateRate = new SettingNumber("Update Rate", 5, 1, 60, 1, "Update rate in ticks");

    private int ticksSinceUpdate = 0;
    private List<RadarBlip> blips = new ArrayList<>();

    private static class RadarBlip {
        double x, y, z;
        String name;
        int color;
        boolean isPlayer;

        RadarBlip(double x, double y, double z, String name, int color, boolean isPlayer) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.name = name;
            this.color = color;
            this.isPlayer = isPlayer;
        }
    }

    public RadarModule() {
        super("Radar", "Zeigt ein Radar mit nahegelegenen Spielern und Entitäten an.", ModuleCategory.VISUALS);
        addSetting(range);
        addSetting(fixedNorth);
        addSetting(showPlayers);
        addSetting(showEntities);
        addSetting(size);
        addSetting(updateRate);
    }

    @Override
    public void onEnable() {
        blips.clear();
        ticksSinceUpdate = 0;
    }

    @Override
    public void onDisable() {
        blips.clear();
    }

    @Override
    public void onReset() {
        blips.clear();
        ticksSinceUpdate = 0;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.world == null) {
            return;
        }

        ticksSinceUpdate++;
        if (ticksSinceUpdate < updateRate.getValue()) {
            return;
        }
        ticksSinceUpdate = 0;

        updateBlips();
    }

    private void updateBlips() {
        blips.clear();

        if (mc.player == null || mc.world == null) {
            return;
        }

        double playerX = mc.player.getX();
        double playerY = mc.player.getY();
        double playerZ = mc.player.getZ();
        double radarRange = range.getValue();

        ClientWorld world = mc.world;

        // Add players
        if (showPlayers.getValue()) {
            for (PlayerEntity player : world.getPlayers()) {
                if (player == mc.player) continue;
                if (!player.isAlive()) continue;

                double dist = player.distanceTo(mc.player);
                if (dist > radarRange) continue;

                blips.add(new RadarBlip(
                    player.getX(), player.getY(), player.getZ(),
                    player.getName().getString(),
                    0xFF00FF00, // Green for players
                    true
                ));
            }
        }

        // Add other entities
        if (showEntities.getValue()) {
            for (Entity entity : world.getEntities()) {
                if (entity == mc.player) continue;
                if (entity instanceof PlayerEntity) continue;
                if (!entity.isAlive()) continue;

                double dist = entity.distanceTo(mc.player);
                if (dist > radarRange) continue;

                blips.add(new RadarBlip(
                    entity.getX(), entity.getY(), entity.getZ(),
                    entity.getType().getName().getString(),
                    0xFFFF0000, // Red for entities
                    false
                ));
            }
        }
    }

    @Override
    public void onPanic() {
        blips.clear();
    }

    public List<RadarBlip> getBlips() {
        return blips;
    }

    public double getRange() {
        return range.getValue();
    }

    public boolean isFixedNorth() {
        return fixedNorth.getValue();
    }

    public double getSize() {
        return size.getValue();
    }

    public Vector2f getPlayerPosition() {
        if (mc.player == null) return new Vector2f(0, 0);
        return new Vector2f((float) mc.player.getX(), (float) mc.player.getZ());
    }

    public float getPlayerYaw() {
        return mc.player != null ? mc.player.getYaw() : 0;
    }
}