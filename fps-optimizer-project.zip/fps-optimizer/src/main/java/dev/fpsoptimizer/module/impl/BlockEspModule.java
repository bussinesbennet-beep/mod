package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingColor;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.RenderLayer;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Block ESP module - highlights specific blocks in the world.
 * Configurable block list with colors and display styles.
 */
public class BlockEspModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showOres = new SettingBoolean("Show Ores", true, "Highlight ore blocks");
    private final SettingBoolean showDiamonds = new SettingBoolean("Show Diamonds", true, "Highlight diamond ore");
    private final SettingBoolean showEmeralds = new SettingBoolean("Show Emeralds", true, "Highlight emerald ore");
    private final SettingBoolean showAncientDebris = new SettingBoolean("Show Ancient Debris", true, "Highlight ancient debris");
    private final SettingNumber range = new SettingNumber("Range", 48.0, 10.0, 192.0, 5.0, "Maximum render distance");
    private final SettingColor color = new SettingColor("Color", 0xFF00FF00, "ESP box color");
    private final SettingNumber maxBlocks = new SettingNumber("Max Blocks", 200, 10, 1000, 10, "Maximum blocks to render simultaneously");

    private int ticksSinceUpdate = 0;
    private List<BlockPos> highlightedBlocks = new ArrayList<>();

    public BlockEspModule() {
        super("Block ESP", "Hebt bestimmte Blöcke in der Welt hervor.", ModuleCategory.VISUALS);
        addSetting(showOres);
        addSetting(showDiamonds);
        addSetting(showEmeralds);
        addSetting(showAncientDebris);
        addSetting(range);
        addSetting(color);
        addSetting(maxBlocks);
    }

    @Override
    public void onEnable() {
        highlightedBlocks.clear();
        ticksSinceUpdate = 0;
    }

    @Override
    public void onDisable() {
        highlightedBlocks.clear();
    }

    @Override
    public void onReset() {
        highlightedBlocks.clear();
        ticksSinceUpdate = 0;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.world == null || mc.player == null) {
            return;
        }

        ticksSinceUpdate++;
        if (ticksSinceUpdate < 15) { // Update every 15 ticks
            return;
        }
        ticksSinceUpdate = 0;

        updateBlocks();
    }

    private void updateBlocks() {
        highlightedBlocks.clear();

        if (mc.player == null || mc.world == null) {
            return;
        }

        BlockPos playerPos = mc.player.getBlockPos();
        int rangeBlocks = (int) (range.getValue() / 4);

        for (int x = -rangeBlocks; x <= rangeBlocks && highlightedBlocks.size() < maxBlocks.getValue(); x++) {
            for (int y = -rangeBlocks; y <= rangeBlocks && highlightedBlocks.size() < maxBlocks.getValue(); y++) {
                for (int z = -rangeBlocks; z <= rangeBlocks && highlightedBlocks.size() < maxBlocks.getValue(); z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    if (mc.world.isChunkLoaded(pos)) {
                        var state = mc.world.getBlockState(pos);
                        Block block = state.getBlock();

                        if (isTargetBlock(block)) {
                            highlightedBlocks.add(pos);
                        }
                    }
                }
            }
        }
    }

    private boolean isTargetBlock(Block block) {
        if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) return showDiamonds.getValue();
        if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) return showEmeralds.getValue();
        if (block == Blocks.ANCIENT_DEBRIS) return showAncientDebris.getValue();

        if (showOres.getValue()) {
            return block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE ||
                   block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE ||
                   block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE ||
                   block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE ||
                   block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE ||
                   block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE;
        }

        return false;
    }

    @Override
    public void onRender(float tickDelta) {
        if (!isInGame() || mc.world == null || mc.player == null || mc.gameRenderer == null) {
            return;
        }

        double camX = mc.gameRenderer.getCamera().getX();
        double camY = mc.gameRenderer.getCamera().getY();
        double camZ = mc.gameRenderer.getCamera().getZ();

        MatrixStack matrixStack = new MatrixStack();
        VertexConsumerProvider.Immediate immediate = mc.getVertexConsumers();
        VertexConsumer vertexConsumer = immediate.getBuffer(RenderLayer.getLines());

        Matrix4f matrix = matrixStack.peek().getPositionMatrix();
        int color = this.color.getValue();
        float r = ((color >> 16) & 0xFF) / 255.0f;
        float g = ((color >> 8) & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        float a = 0.8f;

        for (BlockPos pos : highlightedBlocks) {
            double dx = pos.getX() - camX;
            double dy = pos.getY() - camY;
            double dz = pos.getZ() - camZ;

            Box box = new Box(dx, dy, dz, dx + 1, dy + 1, dz + 1);

            drawBox(matrixStack, vertexConsumer, box, r, g, b, a);
        }

        immediate.draw();
    }

    private void drawBox(MatrixStack matrixStack, VertexConsumer vertexConsumer, Box box, float r, float g, float b, float a) {
        Matrix4f matrix = matrixStack.peek().getPositionMatrix();

        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.minZ, box.maxX, box.minY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.minZ, box.maxX, box.maxY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.minZ, box.minX, box.maxY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.minZ, box.minX, box.minY, box.minZ, r, g, b, a);

        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.maxZ, box.maxX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.maxZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.maxZ, box.minX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.maxZ, box.minX, box.minY, box.maxZ, r, g, b, a);

        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.minZ, box.minX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.minZ, box.maxX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.minZ, box.minX, box.maxY, box.maxZ, r, g, b, a);
    }

    private void drawLine(Matrix4f matrix, VertexConsumer consumer, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
        consumer.vertex(matrix, x1, y1, z1).color(r, g, b, a).next();
        consumer.vertex(matrix, x2, y2, z2).color(r, g, b, a).next();
    }

    @Override
    public void onPanic() {
        highlightedBlocks.clear();
    }
}