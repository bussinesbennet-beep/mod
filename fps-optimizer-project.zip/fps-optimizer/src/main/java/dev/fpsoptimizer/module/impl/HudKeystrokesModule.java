package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

/**
 * Keystrokes module - displays pressed keys on screen.
 * Movement keys, sprint, sneak, jump.
 * Does not block or modify keyboard input.
 */
public class HudKeystrokesModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showForward = new SettingBoolean("Forward", true, "Show forward key status");
    private final SettingBoolean showBack = new SettingBoolean("Back", true, "Show back key status");
    private final SettingBoolean showLeft = new SettingBoolean("Left", true, "Show left key status");
    private final SettingBoolean showRight = new SettingBoolean("Right", true, "Show right key status");
    private final SettingBoolean showSprint = new SettingBoolean("Sprint", true, "Show sprint key status");
    private final SettingBoolean showSneak = new SettingBoolean("Sneak", true, "Show sneak key status");
    private final SettingBoolean showJump = new SettingBoolean("Jump", true, "Show jump key status");

    public HudKeystrokesModule() {
        super("Keystrokes", "Zeigt gedrückte Tasten auf dem Bildschirm an.", ModuleCategory.HUD);
        addSetting(showForward);
        addSetting(showBack);
        addSetting(showLeft);
        addSetting(showRight);
        addSetting(showSprint);
        addSetting(showSneak);
        addSetting(showJump);
    }

    @Override
    public void onEnable() {
        // No state to initialize
    }

    @Override
    public void onDisable() {
        // No cleanup
    }

    @Override
    public void onPanic() {
        // No state to reset
    }

    private boolean isKeyPressed(KeyBinding keyBinding) {
        return keyBinding != null && keyBinding.isPressed();
    }

    public boolean isForwardPressed() {
        return isKeyPressed(mc.options != null ? mc.options.keyForward : null);
    }

    public boolean isBackPressed() {
        return isKeyPressed(mc.options != null ? mc.options.keyBack : null);
    }

    public boolean isLeftPressed() {
        return isKeyPressed(mc.options != null ? mc.options.keyLeft : null);
    }

    public boolean isRightPressed() {
        return isKeyPressed(mc.options != null ? mc.options.keyRight : null);
    }

    public boolean isSprintPressed() {
        return isKeyPressed(mc.options != null ? mc.options.keySprint : null);
    }

    public boolean isSneakPressed() {
        return isKeyPressed(mc.options != null ? mc.options.keySneak : null);
    }

    public boolean isJumpPressed() {
        return isKeyPressed(mc.options != null ? mc.options.keyJump : null);
    }

    public boolean isShowForward() { return showForward.getValue(); }
    public boolean isShowBack() { return showBack.getValue(); }
    public boolean isShowLeft() { return showLeft.getValue(); }
    public boolean isShowRight() { return showRight.getValue(); }
    public boolean isShowSprint() { return showSprint.getValue(); }
    public boolean isShowSneak() { return showSneak.getValue(); }
    public boolean isShowJump() { return showJump.getValue(); }
}