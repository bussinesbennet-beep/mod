package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * Target Info module - displays information about the targeted entity.
 * Only uses client-side known information.
 */
public class HudTargetInfoModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showName = new SettingBoolean("Show Name", true, "Display target entity name");
    private final SettingBoolean showDistance = new SettingBoolean("Show Distance", true, "Display distance to target");
    private final SettingBoolean showHealth = new SettingBoolean("Show Health", true, "Display target health");
    private final SettingBoolean showType = new SettingBoolean("Show Type", true, "Display target entity type");

    private Entity currentTarget = null;
    private double currentDistance = 0;

    public HudTargetInfoModule() {
        super("Target Info", "Zeigt Informationen zum Zielobjekt an.", ModuleCategory.HUD);
        addSetting(showName);
        addSetting(showDistance);
        addSetting(showHealth);
        addSetting(showType);
    }

    @Override
    public void onEnable() {
        currentTarget = null;
        currentDistance = 0;
    }

    @Override
    public void onDisable() {
        currentTarget = null;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.player == null) {
            currentTarget = null;
            return;
        }

        HitResult hitResult = mc.crosshairTarget;
        if (hitResult != null && hitResult.getType() == HitResult.Type.ENTITY) {
            EntityHitResult entityHit = (EntityHitResult) hitResult;
            currentTarget = entityHit.getEntity();
            currentDistance = mc.player.distanceTo(currentTarget);
        } else {
            currentTarget = null;
            currentDistance = 0;
        }
    }

    @Override
    public void onPanic() {
        currentTarget = null;
        currentDistance = 0;
    }

    public Entity getTarget() {
        return currentTarget;
    }

    public double getDistance() {
        return currentDistance;
    }

    public boolean isShowName() {
        return showName.getValue();
    }

    public boolean isShowDistance() {
        return showDistance.getValue();
    }

    public boolean isShowHealth() {
        return showHealth.getValue();
    }

    public boolean isShowType() {
        return showType.getValue();
    }

    public boolean hasTarget() {
        return currentTarget != null;
    }
}