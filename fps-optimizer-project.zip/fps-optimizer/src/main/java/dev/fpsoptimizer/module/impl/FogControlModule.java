package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;

/**
 * Fog Control module - adjusts render fog distance for performance.
 * Reduces rendering load by limiting fog distance.
 */
public class FogControlModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean enabled = new SettingBoolean("Enabled Fog Control", false, "Enable custom fog distance");
    private final SettingNumber fogDistance = new SettingNumber("Fog Distance", 0.8, 0.1, 1.0, 0.1, "Fog distance multiplier (1.0 = vanilla)");

    private float originalFogDistance = 1.0f;

    public FogControlModule() {
        super("Fog Control", "Passt die Render-Nebelentfernung für bessere Performance an.", ModuleCategory.PERFORMANCE);
        addSetting(this.enabled);
        addSetting(fogDistance);
    }

    @Override
    public void onEnable() {
        originalFogDistance = 1.0f;
    }

    @Override
    public void onDisable() {
        // Restore original fog - no permanent changes
    }

    @Override
    public void onReset() {
        // No permanent state
    }

    @Override
    public void onTick() {
        // Fog control is applied during rendering
    }

    public boolean isFogControlEnabled() {
        return enabled.getValue();
    }

    public float getFogDistanceMultiplier() {
        return fogDistance.getValue();
    }

    @Override
    public void onPanic() {
        // No permanent changes
    }
}