package dev.fpsoptimizer.module;

/**
 * Enumeration of module categories for the ClickGUI organization.
 */
public enum ModuleCategory {
    HUD("HUD", "category.fpsoptimizer.hud", 0x4a90e2),
    VISUALS("Visuals", "category.fpsoptimizer.visuals", 0x9b59b6),
    UTILITY("Utility", "category.fpsoptimizer.utility", 0x2ecc71),
    NAVIGATION("Navigation", "category.fpsoptimizer.navigation", 0xf39c12),
    PERFORMANCE("Performance", "category.fpsoptimizer.performance", 0xe74c3c),
    WORLD_ANALYSIS("World Analysis", "category.fpsoptimizer.world_analysis", 0x1abc9c),
    SETTINGS("Settings", "category.fpsoptimizer.settings", 0x34495e);

    private final String displayName;
    private final String translationKey;
    private final int color;

    ModuleCategory(String displayName, String translationKey, int color) {
        this.displayName = displayName;
        this.translationKey = translationKey;
        this.color = color;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public int getColor() {
        return color;
    }

    public float getColorRed() {
        return ((color >> 16) & 0xFF) / 255.0f;
    }

    public float getColorGreen() {
        return ((color >> 8) & 0xFF) / 255.0f;
    }

    public float getColorBlue() {
        return (color & 0xFF) / 255.0f;
    }
}