package dev.fpsoptimizer.module;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.setting.Setting;
import dev.fpsoptimizer.setting.SettingBoolean;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for all FPS Optimizer modules.
 * Modules encapsulate a single feature and can be enabled/disabled,
 * have settings, keybinds, and render/tick logic.
 */
public abstract class Module {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.Module");

    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private final ModuleCategory category;
    private final String translationKey;
    private boolean enabled;
    private boolean visibleInHud;

    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, ModuleCategory category) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.translationKey = "module.fpsoptimizer." + name.toLowerCase().replace(' ', '_');
        this.enabled = false;
        this.visibleInHud = false;
    }

    /**
     * Called when the module is enabled.
     * Subclasses should override to initialize resources.
     */
    public void onEnable() {
        LOGGER.debug("Module enabled: {}", name);
    }

    /**
     * Called when the module is disabled.
     * Subclasses should override to clean up resources.
     */
    public void onDisable() {
        LOGGER.debug("Module disabled: {}", name);
    }

    /**
     * Called every client tick while the module is enabled.
     * Subclasses should override for per-tick logic.
     */
    public void onTick() {
        // Default: no per-tick logic
    }

    /**
     * Called every render frame while the module is enabled.
     * Subclasses should override for rendering logic.
     *
     * @param tickDelta Partial tick delta for smooth rendering
     */
    public void onRender(float tickDelta) {
        // Default: no render logic
    }

    /**
     * Called when the module should stop any ongoing automation
     * (e.g. during panic key or world change).
     */
    public void onPanic() {
        // Default: no panic handling
    }

    /**
     * Called when the player dies, changes world, or disconnects.
     * Modules should reset their state here.
     */
    public void onReset() {
        // Default: no reset handling
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public ModuleCategory getCategory() {
        return category;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) {
            return;
        }
        this.enabled = enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public boolean isVisibleInHud() {
        return visibleInHud;
    }

    public void setVisibleInHud(boolean visibleInHud) {
        this.visibleInHud = visibleInHud;
    }

    public List<Setting<?>> getSettings() {
        return settings;
    }

    public <T> void addSetting(Setting<T> setting) {
        settings.add(setting);
    }

    @SuppressWarnings("unchecked")
    public <T> Setting<T> getSetting(String name) {
        for (Setting<?> setting : settings) {
            if (setting.getName().equals(name)) {
                return (Setting<T>) setting;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public <T> T getSettingValue(String name) {
        Setting<T> setting = getSetting(name);
        return setting != null ? setting.getValue() : null;
    }

    protected boolean isGlobalEnabled() {
        return FPSOptimizerClient.isGlobalEnabled();
    }

    protected boolean isInGame() {
        return mc.player != null && mc.world != null;
    }
}