package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import net.minecraft.client.MinecraftClient;

/**
 * Coordinates HUD module - displays player coordinates and rotation.
 * Optional dimension-dependent display.
 */
public class HudCoordsModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showX = new SettingBoolean("Show X", true, "Display X coordinate");
    private final SettingBoolean showY = new SettingBoolean("Show Y", true, "Display Y coordinate");
    private final SettingBoolean showZ = new SettingBoolean("Show Z", true, "Display Z coordinate");
    private final SettingBoolean showRotation = new SettingBoolean("Show Rotation", false, "Display yaw and pitch");
    private final SettingBoolean showDimension = new SettingBoolean("Show Dimension", true, "Display current dimension");

    public HudCoordsModule() {
        super("Coordinates", "Zeigt Spielerkoordinaten und Rotation an.", ModuleCategory.HUD);
        addSetting(showX);
        addSetting(showY);
        addSetting(showZ);
        addSetting(showRotation);
        addSetting(showDimension);
    }

    @Override
    public void onEnable() {
        // No state
    }

    @Override
    public void onDisable() {
        // No cleanup
    }

    @Override
    public void onPanic() {
        // No state
    }

    public double getX() {
        return mc.player != null ? mc.player.getX() : 0;
    }

    public double getY() {
        return mc.player != null ? mc.player.getY() : 0;
    }

    public double getZ() {
        return mc.player != null ? mc.player.getZ() : 0;
    }

    public float getYaw() {
        return mc.player != null ? mc.player.getYaw() : 0;
    }

    public float getPitch() {
        return mc.player != null ? mc.player.getPitch() : 0;
    }

    public String getDimension() {
        return mc.world != null ? mc.world.getRegistryKey().getValue().toString() : "unknown";
    }

    public boolean isShowX() { return showX.getValue(); }
    public boolean isShowY() { return showY.getValue(); }
    public boolean isShowZ() { return showZ.getValue(); }
    public boolean isShowRotation() { return showRotation.getValue(); }
    public boolean isShowDimension() { return showDimension.getValue(); }
}