package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;

/**
 * FPS HUD module - displays current frames per second.
 * Lightweight with optional smoothed value.
 */
public class HudFpsModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showSmoothed = new SettingBoolean("Smoothed", true, "Show smoothed FPS value");
    private final SettingNumber smoothingFactor = new SettingNumber("Smoothing", 0.1, 0.01, 1.0, 0.01, "Smoothing factor for FPS value");

    private float smoothedFps = 0.0f;
    private long lastTime = System.currentTimeMillis();
    private int frameCount = 0;
    private int currentFps = 0;

    public HudFpsModule() {
        super("FPS", "Zeigt die aktuelle Bilder pro Sekunde an.", ModuleCategory.HUD);
        addSetting(showSmoothed);
        addSetting(smoothingFactor);
    }

    @Override
    public void onEnable() {
        reset();
    }

    @Override
    public void onDisable() {
        // No cleanup
    }

    @Override
    public void onTick() {
        if (!isInGame()) {
            return;
        }

        long now = System.currentTimeMillis();
        frameCount++;

        if (now - lastTime >= 1000) {
            currentFps = frameCount;
            frameCount = 0;
            lastTime = now;

            if (showSmoothed.getValue()) {
                float factor = smoothingFactor.getValue();
                smoothedFps = smoothedFps + (currentFps - smoothedFps) * factor;
            }
        }
    }

    @Override
    public void onPanic() {
        reset();
    }

    private void reset() {
        currentFps = 0;
        smoothedFps = 0.0f;
        frameCount = 0;
        lastTime = System.currentTimeMillis();
    }

    public int getFps() {
        return currentFps;
    }

    public float getSmoothedFps() {
        return smoothedFps;
    }

    public boolean isShowSmoothed() {
        return showSmoothed.getValue();
    }
}