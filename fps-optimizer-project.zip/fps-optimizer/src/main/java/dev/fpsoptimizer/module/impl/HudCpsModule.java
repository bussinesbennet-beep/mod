package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;

/**
 * CPS module - displays clicks per second for left and right mouse buttons.
 * Configurable time window. Does not generate artificial clicks.
 */
public class HudCpsModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showLeft = new SettingBoolean("Left Click", true, "Show left mouse button CPS");
    private final SettingBoolean showRight = new SettingBoolean("Right Click", true, "Show right mouse button CPS");
    private final SettingNumber timeWindow = new SettingNumber("Time Window", 1.0, 0.1, 5.0, 0.1, "Time window in seconds for CPS calculation");

    private int leftClicks = 0;
    private int rightClicks = 0;
    private long windowStart = System.currentTimeMillis();
    private int leftCps = 0;
    private int rightCps = 0;

    public HudCpsModule() {
        super("CPS", "Zeigt Klicks pro Sekunde für linke und rechte Maustaste an.", ModuleCategory.HUD);
        addSetting(showLeft);
        addSetting(showRight);
        addSetting(timeWindow);
    }

    @Override
    public void onEnable() {
        resetCounters();
    }

    @Override
    public void onDisable() {
        resetCounters();
    }

    @Override
    public void onTick() {
        if (!isInGame()) {
            return;
        }

        long now = System.currentTimeMillis();
        long windowMs = (long) (timeWindow.getValue() * 1000);

        if (now - windowStart >= windowMs) {
            leftCps = leftClicks;
            rightCps = rightClicks;
            leftClicks = 0;
            rightClicks = 0;
            windowStart = now;
        }
    }

    @Override
    public void onPanic() {
        resetCounters();
    }

    public void recordLeftClick() {
        leftClicks++;
    }

    public void recordRightClick() {
        rightClicks++;
    }

    private void resetCounters() {
        leftClicks = 0;
        rightClicks = 0;
        leftCps = 0;
        rightCps = 0;
        windowStart = System.currentTimeMillis();
    }

    public int getLeftCps() {
        return leftCps;
    }

    public int getRightCps() {
        return rightCps;
    }

    public boolean isShowLeft() {
        return showLeft.getValue();
    }

    public boolean isShowRight() {
        return showRight.getValue();
    }

    public double getTimeWindow() {
        return timeWindow.getValue();
    }
}