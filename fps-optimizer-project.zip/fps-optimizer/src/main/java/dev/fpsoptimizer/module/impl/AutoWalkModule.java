package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import dev.fpsoptimizer.util.PathFinder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * AutoWalk Module - läuft automatisch zu angegebenen Koordinaten.
 * Berechnet den kürzesten Weg und bewertet alternative Strecken.
 * Verwendet automatisch Werkzeuge zum Freigraben von Blockaden.
 */
public class AutoWalkModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean enabled = new SettingBoolean("Auto Walk", false, "Automatisches Laufen aktivieren");
    private final SettingNumber speed = new SettingNumber("Speed", 0.5, 0.1, 2.0, 0.1, "Laufgeschwindigkeit");
    private final SettingNumber stopDistance = new SettingNumber("Stop Distance", 1.5, 0.5, 5.0, 0.1, "Abstand zum Ziel zum Stoppen (Blöcke)");
    private final SettingBoolean autoDig = new SettingBoolean("Auto Dig", true, "Automatisch im Weg stehende Blöcke abbauen");
    private final SettingNumber maxPathNodes = new SettingNumber("Max Path Nodes", 200, 50, 1000, 50, "Maximale Knoten für Pfadfindung");

    // Zielkoordinaten (einfach eintragbar)
    private final SettingNumber targetX = new SettingNumber("Target X", 0, -30000000, 30000000, 1, "Ziel X-Koordinate");
    private final SettingNumber targetY = new SettingNumber("Target Y", 64, -30000000, 30000000, 1, "Ziel Y-Koordinate");
    private final SettingNumber targetZ = new SettingNumber("Target Z", 0, -30000000, 30000000, 1, "Ziel Z-Koordinate");

    private List<BlockPos> path = null;
    private int currentPathIndex = 0;
    private boolean navigating = false;
    private int ticksSinceLastRecalc = 0;

    public AutoWalkModule() {
        super("AutoWalk", "Läuft automatisch zu angegebenen Koordinaten.", ModuleCategory.NAVIGATION);
        addSetting(enabled);
        addSetting(speed);
        addSetting(stopDistance);
        addSetting(autoDig);
        addSetting(maxPathNodes);
        addSetting(targetX);
        addSetting(targetY);
        addSetting(targetZ);
    }

    @Override
    public void onEnable() {
        if (isInGame()) {
            startNavigation();
        }
    }

    @Override
    public void onDisable() {
        stopNavigation();
    }

    @Override
    public void onReset() {
        stopNavigation();
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.player == null || mc.world == null) {
            stopNavigation();
            return;
        }

        if (!enabled.getValue() || !navigating) {
            return;
        }

        ticksSinceLastRecalc++;

        // Ziel erreichen?
        BlockPos target = new BlockPos(
            targetX.getValue().intValue(),
            targetY.getValue().intValue(),
            targetZ.getValue().intValue()
        );

        double distToTarget = mc.player.distanceToSqr(target.getX(), target.getY(), target.getZ());
        double stopDistSqr = stopDistance.getValue() * stopDistance.getValue();

        if (distToTarget <= stopDistSqr) {
            stopNavigation();
            FPSOptimizerClient.getNotificationManager().add(
                "notification.fpsoptimizer.navigation_arrived",
                "Ziel erreicht",
                "AutoWalk hat das Ziel erreicht"
            );
            return;
        }

        // Pfad neu berechnen alle 20 Ticks oder wenn kein Pfad vorhanden
        if (path == null || currentPathIndex >= path.size() || ticksSinceLastRecalc > 20) {
            recalculatePath(target);
            ticksSinceLastRecalc = 0;
        }

        // Dem Pfad folgen
        if (path != null && currentPathIndex < path.size()) {
            followPath();
        }
    }

    @Override
    public void onPanic() {
        stopNavigation();
    }

    private void startNavigation() {
        if (!isInGame()) return;
        navigating = true;
        path = null;
        currentPathIndex = 0;
        recalculatePath(new BlockPos(
            targetX.getValue().intValue(),
            targetY.getValue().intValue(),
            targetZ.getValue().intValue()
        ));
        FPSOptimizerClient.getNotificationManager().add(
            "notification.fpsoptimizer.navigation_started",
            "AutoWalk gestartet",
            "Laufe zu " + targetX.getValue() + ", " + targetY.getValue() + ", " + targetZ.getValue()
        );
    }

    public void stopNavigation() {
        navigating = false;
        path = null;
        currentPathIndex = 0;
        // Bewegung stoppen
        if (mc.player != null) {
            mc.player.setSpeed(0.0f);
            mc.player.setSprinting(false);
            mc.player.setSneaking(false);
        }
    }

    private void recalculatePath(BlockPos target) {
        if (mc.player == null || mc.world == null) return;

        Vec3d startPos = mc.player.getPos();
        path = PathFinder.findBestPath(startPos, target, maxPathNodes.getValue().intValue());
        currentPathIndex = 0;

        if (path == null) {
            FPSOptimizerClient.getLogger().warn("AutoWalk: Kein Pfad zum Ziel gefunden");
        }
    }

    private void followPath() {
        if (path == null || currentPathIndex >= path.size() || mc.player == null) return;

        BlockPos nextWaypoint = path.get(currentPathIndex);

        double dist = mc.player.distanceToSqr(nextWaypoint.getX(), nextWaypoint.getY(), nextWaypoint.getZ());

        // Wenn wir am Wegpunkt sind, zum nächsten gehen
        if (dist < 0.6) { // ~1 Block
            currentPathIndex++;
            if (currentPathIndex >= path.size()) {
                // Pfadende erreicht, aber Ziel noch nicht (z.B. durch Blockade)
                recalculatePath(new BlockPos(
                    targetX.getValue().intValue(),
                    targetY.getValue().intValue(),
                    targetZ.getValue().intValue()
                ));
            }
            return;
        }

        // Richtung zum Wegpunkt berechnen
        double dx = nextWaypoint.getX() - mc.player.getX();
        double dz = nextWaypoint.getZ() - mc.player.getZ();
        double dy = nextWaypoint.getY() - mc.player.getY();

        float targetYaw = (float) (Math.toDegrees(Math.atan2(-dz, dx)) - 90.0);
        float targetPitch = (float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));

        // Allmählich zur Zielrichtung drehen
        float currentYaw = mc.player.getYaw();
        float yawDiff = MathUtil.normalizeAngle(targetYaw - currentYaw);
        float turnSpeed = 10.0f;
        if (Math.abs(yawDiff) > turnSpeed) {
            yawDiff = yawDiff > 0 ? turnSpeed : -turnSpeed;
        }
        mc.player.setYaw(currentYaw + yawDiff);
        mc.player.setPitch(targetPitch);

        // Bewegungsrichtung berechnen (relativ zur Kamera)
        double moveYaw = Math.toRadians(mc.player.getYaw() - 90.0);
        double moveX = Math.sin(moveYaw) * speed.getValue();
        double moveZ = Math.cos(moveYaw) * speed.getValue();

        // Prüfen ob Block im Weg ist und graben wenn aktiviert
        if (autoDig.getValue()) {
            BlockPos blockInFront = new BlockPos(
                mc.player.getX() + moveX * 1.5,
                mc.player.getY(),
                mc.player.getZ() + moveZ * 1.5
            );
            if (mc.world != null && mc.world.getBlockState(blockInFront).isSolidBlock(mc.world, blockInFront)) {
                mc.interactionManager.attackBlock(blockInFront, net.minecraft.util.math.Direction.UP);
            }
        }

        // Bewegung ausführen
        mc.player.setSpeed((float) speed.getValue());
        mc.player.setSprinting(false);
    }

    public boolean isNavigating() {
        return navigating;
    }

    public BlockPos getTarget() {
        return new BlockPos(
            targetX.getValue().intValue(),
            targetY.getValue().intValue(),
            targetZ.getValue().intValue()
        );
    }

    public List<BlockPos> getPath() {
        return path;
    }

    public int getPathIndex() {
        return currentPathIndex;
    }
}