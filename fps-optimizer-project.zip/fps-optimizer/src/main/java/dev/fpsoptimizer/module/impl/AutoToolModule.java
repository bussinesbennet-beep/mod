package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ToolItem;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/**
 * AutoTool module - automatically selects the best tool for mining blocks.
 * Only for singleplayer and allowed test environments.
 * Does not trigger additional attacks or unwanted inventory actions.
 */
public class AutoToolModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean considerDurability = new SettingBoolean("Consider Durability", true, "Factor in tool durability when selecting");
    private final SettingNumber minDurability = new SettingNumber("Min Durability", 10, 0, 100, 1, "Minimum durability percentage to consider a tool usable");

    private int previousSlot = -1;
    private boolean autoToolActive = false;
    private int ticksSinceSwitch = 0;

    public AutoToolModule() {
        super("AutoTool", "Wählt automatisch das beste Werkzeug zum Abbauen von Blöcken aus.", ModuleCategory.UTILITY);
        addSetting(considerDurability);
        addSetting(minDurability);
    }

    @Override
    public void onEnable() {
        previousSlot = -1;
        autoToolActive = false;
        ticksSinceSwitch = 0;
    }

    @Override
    public void onDisable() {
        restoreSlot();
        autoToolActive = false;
    }

    @Override
    public void onReset() {
        restoreSlot();
        autoToolActive = false;
        ticksSinceSwitch = 0;
    }

    @Override
    public void onTick() {
        if (!autoToolActive || !isInGame() || mc.player == null) {
            return;
        }

        ticksSinceSwitch++;

        // Only check every few ticks to avoid excessive inventory changes
        if (ticksSinceSwitch < 5) {
            return;
        }
        ticksSinceSwitch = 0;

        // Get the block being looked at
        var crosshairTarget = mc.crosshairTarget;
        if (crosshairTarget == null || crosshairTarget.getType() != net.minecraft.util.hit.BlockHitResult.Type.BLOCK) {
            restoreSlot();
            return;
        }

        BlockPos pos = ((net.minecraft.util.hit.BlockHitResult) crosshairTarget).getBlockPos();
        var blockState = mc.world.getBlockState(pos);

        // Find the best tool
        int bestSlot = findBestTool(blockState);
        if (bestSlot == -1) {
            restoreSlot();
            return;
        }

        // Switch to the best tool if different
        if (mc.player.getInventory().selectedSlot != bestSlot) {
            previousSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = bestSlot;
            autoToolActive = true;
        }
    }

    @Override
    public void onPanic() {
        stop();
    }

    public void stop() {
        restoreSlot();
        autoToolActive = false;
        ticksSinceSwitch = 0;
    }

    private void restoreSlot() {
        if (previousSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = previousSlot;
            previousSlot = -1;
        }
    }

    private int findBestTool(net.minecraft.block.BlockState blockState) {
        if (mc.player == null) {
            return -1;
        }

        var inventory = mc.player.getInventory();
        int bestSlot = -1;
        float bestEfficiency = 0.0f;

        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.isEmpty()) {
                continue;
            }

            Item item = stack.getItem();
            float efficiency = getToolEfficiency(item, blockState);

            if (efficiency <= 0.0f) {
                continue;
            }

            // Consider durability
            if (considerDurability.getValue()) {
                int durability = stack.getMaxDamage() - stack.getDamage();
                int maxDamage = stack.getMaxDamage();
                if (maxDamage > 0) {
                    float durabilityPct = (float) durability / maxDamage * 100.0f;
                    if (durabilityPct < minDurability.getValue()) {
                        continue;
                    }
                }
            }

            if (efficiency > bestEfficiency) {
                bestEfficiency = efficiency;
                bestSlot = i;
            }
        }

        return bestSlot;
    }

    private float getToolEfficiency(Item item, net.minecraft.block.BlockState blockState) {
        if (item instanceof ToolItem toolItem) {
            // Check if the tool is effective against this block
            var toolTags = toolItem.getTags();
            if (toolTags != null) {
                for (var tag : toolTags) {
                    if (blockState.isIn(tag)) {
                        return toolItem.getMiningSpeedMultiplier();
                    }
                }
            }
        }

        // Default: hand or inefficient tool
        return 1.0f;
    }

    public boolean isAutoToolActive() {
        return autoToolActive;
    }

    public void setAutoToolActive(boolean active) {
        this.autoToolActive = active;
    }
}