package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.navigation.BaritoneIntegration;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Navigation module - pathfinding to coordinates using Baritone integration.
 * Baritone v1.19.0 for Minecraft 26.2 is available but optional.
 * If Baritone is not present, navigation gracefully degrades.
 */
public class NavigationModule extends Module {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.Navigation");

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean useBaritone = new SettingBoolean("Use Baritone", true, "Use Baritone for pathfinding (requires Baritone mod)");
    private final SettingNumber maxDistance = new SettingNumber("Max Distance", 1000.0, 10.0, 10000.0, 10.0, "Maximum navigation distance");

    private BaritoneIntegration baritoneIntegration;
    private boolean navigating = false;
    private BlockPos target = null;
    private NavigationStatus status = NavigationStatus.IDLE;

    private enum NavigationStatus {
        IDLE,
        PATHFINDING,
        MOVING,
        ARRIVED,
        FAILED
    }

    public NavigationModule() {
        super("Navigation", "Pfadfindung zu Koordinaten mittels Baritone-Integration.", ModuleCategory.NAVIGATION);
        addSetting(useBaritone);
        addSetting(maxDistance);
    }

    @Override
    public void onEnable() {
        baritoneIntegration = new BaritoneIntegration();
        status = NavigationStatus.IDLE;
        target = null;
        navigating = false;
    }

    @Override
    public void onDisable() {
        stop();
    }

    @Override
    public void onReset() {
        stop();
    }

    @Override
    public void onTick() {
        if (!navigating || target == null || !isInGame()) {
            return;
        }

        if (baritoneIntegration != null && baritoneIntegration.isAvailable()) {
            baritoneIntegration.update();
        }

        // Check if we've arrived
        if (mc.player != null && target != null) {
            double dist = mc.player.distanceToSqr(target.getX(), target.getY(), target.getZ());
            if (dist < 2.25) { // Within 1.5 blocks
                arrive();
            }
        }
    }

    @Override
    public void onPanic() {
        stop();
    }

    /**
     * Start navigation to a target position.
     */
    public void navigateTo(double x, double y, double z) {
        if (!isInGame() || mc.player == null) {
            return;
        }

        BlockPos newTarget = new BlockPos((int) x, (int) y, (int) z);

        double dist = mc.player.distanceToSqr(x, y, z);
        if (dist > maxDistance.getValue() * maxDistance.getValue()) {
            FPSOptimizerClient.getLogger().warn("Target too far for navigation: {} blocks", Math.sqrt(dist));
            status = NavigationStatus.FAILED;
            return;
        }

        target = newTarget;
        navigating = true;
        status = NavigationStatus.PATHFINDING;

        if (baritoneIntegration != null && baritoneIntegration.isAvailable()) {
            baritoneIntegration.startPathfinding(target);
            FPSOptimizerClient.getNotificationManager().add(
                "notification.fpsoptimizer.navigation_started",
                "Navigation gestartet",
                "Pfad zu " + x + ", " + y + ", " + z
            );
        } else {
            // Fallback: simple movement without Baritone
            status = NavigationStatus.MOVING;
            FPSOptimizerClient.getLogger().warn("Baritone not available - navigation limited to basic movement");
            FPSOptimizerClient.getNotificationManager().add(
                "notification.fpsoptimizer.navigation_started",
                "Navigation gestartet (modus: Basis)",
                "Baritone nicht verfügbar - einfache Bewegung"
            );
        }
    }

    public void stop() {
        if (!navigating) {
            return;
        }

        navigating = false;
        status = NavigationStatus.IDLE;

        if (baritoneIntegration != null) {
            baritoneIntegration.stop();
        }

        // Stop player movement
        if (mc.player != null) {
            mc.player.setSprinting(false);
            mc.player.setSneaking(false);
            mc.player.setSpeed(0.0f);
        }
    }

    private void arrive() {
        navigating = false;
        status = NavigationStatus.ARRIVED;
        target = null;

        FPSOptimizerClient.getNotificationManager().add(
            "notification.fpsoptimizer.navigation_arrived",
            "Ziel erreicht",
            "Navigation abgeschlossen"
        );
    }

    public boolean isNavigating() {
        return navigating;
    }

    public NavigationStatus getStatus() {
        return status;
    }

    public BlockPos getTarget() {
        return target;
    }

    public boolean isBaritoneAvailable() {
        return baritoneIntegration != null && baritoneIntegration.isAvailable();
    }

    @Override
    public void onRender(float tickDelta) {
        // No render logic needed for navigation
    }
}