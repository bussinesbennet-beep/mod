package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.EquipmentSlot;

/**
 * Armor HUD module - displays armor durability and status.
 * Shows available armor slots, durability, and low durability warnings.
 */
public class HudArmorModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showHelmet = new SettingBoolean("Helmet", true, "Show helmet durability");
    private final SettingBoolean showChestplate = new SettingBoolean("Chestplate", true, "Show chestplate durability");
    private final SettingBoolean showLeggings = new SettingBoolean("Leggings", true, "Show leggings durability");
    private final SettingBoolean showBoots = new SettingBoolean("Boots", true, "Show boots durability");
    private final SettingBoolean warnLowDurability = new SettingBoolean("Warn Low Durability", true, "Warn when armor durability is low");
    private final SettingNumber lowDurabilityThreshold = new SettingNumber("Low Threshold", 25.0, 0.0, 100.0, 5.0, "Durability percentage below which to warn");

    public HudArmorModule() {
        super("Armor", "Zeigt Rüstungsdauerhaftigkeit und -status an.", ModuleCategory.HUD);
        addSetting(showHelmet);
        addSetting(showChestplate);
        addSetting(showLeggings);
        addSetting(showBoots);
        addSetting(warnLowDurability);
        addSetting(lowDurabilityThreshold);
    }

    @Override
    public void onEnable() {
        // No state
    }

    @Override
    public void onDisable() {
        // No cleanup
    }

    @Override
    public void onPanic() {
        // No state
    }

    public float getDurability(EquipmentSlot slot) {
        if (mc.player == null) return 0;
        ItemStack stack = mc.player.getEquippedStack(slot);
        if (stack.isEmpty()) return 0;
        int maxDamage = stack.getMaxDamage();
        if (maxDamage <= 0) return 100;
        int damage = stack.getDamage();
        return (float) (maxDamage - damage) / maxDamage * 100.0f;
    }

    public boolean hasArmor(EquipmentSlot slot) {
        if (mc.player == null) return false;
        return !mc.player.getEquippedStack(slot).isEmpty();
    }

    public int getTotalArmorPoints() {
        if (mc.player == null) return 0;
        return mc.player.getArmor();
    }

    public boolean isWarnLowDurability() {
        return warnLowDurability.getValue();
    }

    public double getLowDurabilityThreshold() {
        return lowDurabilityThreshold.getValue();
    }

    public boolean isShowHelmet() { return showHelmet.getValue(); }
    public boolean isShowChestplate() { return showChestplate.getValue(); }
    public boolean isShowLeggings() { return showLeggings.getValue(); }
    public boolean isShowBoots() { return showBoots.getValue(); }
}