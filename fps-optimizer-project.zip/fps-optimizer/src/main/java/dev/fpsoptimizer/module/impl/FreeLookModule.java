package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/**
 * Free Look module - allows independent camera rotation without affecting player movement.
 * The player can look around while continuing to move in the original direction.
 * Completely separate from Freecam.
 */
public class FreeLookModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean smooth = new SettingBoolean("Smooth", true, "Smoothly transition back to original look direction");
    private final SettingNumber smoothSpeed = new SettingNumber("Smooth Speed", 0.2f, 0.05f, 1.0f, 0.05f, "Speed of smooth transition");

    private boolean active = false;
    private float originalYaw, originalPitch;
    private float currentYaw, currentPitch;
    private KeyBinding keyToggle;

    public FreeLookModule() {
        super("Free Look", "Ermöglicht unabhängige Kamera rotation ohne Einfluss auf die Spielerbewegung.", ModuleCategory.UTILITY);
        addSetting(smooth);
        addSetting(smoothSpeed);
    }

    @Override
    public void onEnable() {
        if (!isInGame()) {
            setEnabled(false);
            return;
        }

        active = true;
        originalYaw = mc.player.getYaw();
        originalPitch = mc.player.getPitch();
        currentYaw = originalYaw;
        currentPitch = originalPitch;

        keyToggle = new KeyBinding("fpsoptimizer.freelook.toggle", InputUtil.Type.KEYSYM, InputUtil.KEY_F11, "key.fpsoptimizer.freelook");
    }

    @Override
    public void onDisable() {
        reset();
    }

    @Override
    public void onReset() {
        if (active) {
            reset();
        }
    }

    @Override
    public void onTick() {
        if (!active || !isInGame()) {
            return;
        }

        // In free look mode, we override the player's rendered rotation
        // but preserve their movement direction
        // The camera rotation is handled by vanilla input; we just override the render yaw/pitch

        if (smooth.getValue()) {
            float speed = smoothSpeed.getValue();
            float targetYaw = mc.player.getYaw();
            float targetPitch = mc.player.getPitch();

            currentYaw = lerpAngle(currentYaw, targetYaw, speed);
            currentPitch = lerp(currentPitch, targetPitch, speed);

            // Apply to player's rendered rotation
            mc.player.setYaw(currentYaw);
            mc.player.setPitch(currentPitch);
        }
    }

    @Override
    public void onPanic() {
        reset();
    }

    private void reset() {
        if (!active) {
            return;
        }

        active = false;

        // Restore original rotation
        if (mc.player != null) {
            mc.player.setYaw(originalYaw);
            mc.player.setPitch(originalPitch);
        }
    }

    private float lerp(float current, float target, float speed) {
        return current + (target - current) * speed;
    }

    private float lerpAngle(float current, float target, float speed) {
        float diff = target - current;
        while (diff > 180) diff -= 360;
        while (diff < -180) diff += 360;
        return current + diff * speed;
    }

    public boolean isActive() {
        return active;
    }

    public void reset() {
        reset();
    }
}