package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleType;

/**
 * Particle Reduction module - reduces particle count to improve FPS.
 * Measurable optimization with documented trade-offs.
 */
public class ParticleReductionModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingNumber reductionPercentage = new SettingNumber("Reduction", 50.0, 0.0, 90.0, 5.0, "Percentage of particles to reduce");
    private final SettingNumber minInterval = new SettingNumber("Min Interval", 2, 1, 20, 1, "Minimum ticks between particle spawns");

    private int ticksSinceLastParticle = 0;
    private int particlesSuppressed = 0;
    private int particlesTotal = 0;

    public ParticleReductionModule() {
        super("Particle Reduction", "Reduziert die Partikelanzahl zur FPS-Verbesserung.", ModuleCategory.PERFORMANCE);
        addSetting(reductionPercentage);
        addSetting(minInterval);
    }

    @Override
    public void onEnable() {
        particlesSuppressed = 0;
        particlesTotal = 0;
        ticksSinceLastParticle = 0;
    }

    @Override
    public void onDisable() {
        // No permanent changes to revert
    }

    @Override
    public void onReset() {
        particlesSuppressed = 0;
        particlesTotal = 0;
    }

    @Override
    public void onTick() {
        if (!isInGame()) {
            return;
        }

        ticksSinceLastParticle++;

        // This module works by intercepting particle spawning
        // The actual reduction happens in the render hook
        // For now, we track stats and provide a configurable reduction
    }

    /**
     * Called by the render hook to determine if a particle should be suppressed.
     * @return true if the particle should be suppressed
     */
    public boolean shouldSuppressParticle() {
        if (!isEnabled()) {
            return false;
        }

        particlesTotal++;

        if (ticksSinceLastParticle < minInterval.getValue()) {
            particlesSuppressed++;
            return true;
        }

        // Probabilistic reduction based on percentage
        double chance = reductionPercentage.getValue() / 100.0;
        if (Math.random() < chance) {
            particlesSuppressed++;
            ticksSinceLastParticle = 0;
            return true;
        }

        return false;
    }

    public int getParticlesSuppressed() {
        return particlesSuppressed;
    }

    public int getParticlesTotal() {
        return particlesTotal;
    }

    public double getSuppressionRate() {
        if (particlesTotal == 0) return 0.0;
        return (double) particlesSuppressed / particlesTotal * 100.0;
    }

    @Override
    public void onPanic() {
        particlesSuppressed = 0;
        particlesTotal = 0;
    }
}