package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import dev.fpsoptimizer.performance.PerformanceManager;
import net.minecraft.client.MinecraftClient;

/**
 * Performance module - optimizes rendering and memory usage.
 * All optimizations are measurable and safe. No JVM interference.
 */
public class PerformanceModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean entityCulling = new SettingBoolean("Entity Culling", true, "Don't render entities outside view frustum");
    private final SettingBoolean chunkCulling = new SettingBoolean("Chunk Culling", true, "Skip rendering of occluded chunks");
    private final SettingBoolean fastMath = new SettingBoolean("Fast Math", false, "Use faster approximations for non-critical math");
    private final SettingNumber renderDistance = new SettingNumber("Render Distance", 8, 2, 32, 1, "Chunk render distance");

    private long lastMemoryClean = 0;
    private static final long MEMORY_CLEAN_INTERVAL = 60_000; // 60 seconds

    public PerformanceModule() {
        super("Performance", "Optimiert Rendering und Speichernutzung.", ModuleCategory.PERFORMANCE);
        addSetting(entityCulling);
        addSetting(chunkCulling);
        addSetting(fastMath);
        addSetting(renderDistance);
    }

    @Override
    public void onEnable() {
        lastMemoryClean = System.currentTimeMillis();
    }

    @Override
    public void onDisable() {
        // No permanent changes
    }

    @Override
    public void onReset() {
        lastMemoryClean = System.currentTimeMillis();
    }

    @Override
    public void onTick() {
        if (!isInGame()) {
            return;
        }

        // Periodic memory cleanup suggestion
        long now = System.currentTimeMillis();
        if (now - lastMemoryClean > MEMORY_CLEAN_INTERVAL) {
            lastMemoryClean = now;
            // Just log - we don't force GC as that can cause stutters
            FPSOptimizerClient.getLogger().debug("Performance: periodic memory check at tick {}", mc.player.age);
        }
    }

    @Override
    public void onPanic() {
        // No permanent changes to revert
    }

    public boolean isEntityCulling() {
        return entityCulling.getValue();
    }

    public boolean isChunkCulling() {
        return chunkCulling.getValue();
    }

    public boolean isFastMath() {
        return fastMath.getValue();
    }

    public int getRenderDistance() {
        return renderDistance.getValue().intValue();
    }

    public long getLastMemoryClean() {
        return lastMemoryClean;
    }
}