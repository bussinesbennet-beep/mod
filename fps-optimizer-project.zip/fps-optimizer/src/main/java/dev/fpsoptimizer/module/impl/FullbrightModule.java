package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.GameOptions;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;

/**
 * Fullbright module - makes the world brighter by adjusting lightmap values.
 * Only works in singleplayer and allowed test environments.
 * Reversible client-side implementation - no permanent changes to game settings.
 */
public class FullbrightModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean smoothLighting = new SettingBoolean("Smooth Lighting", true, "Keep smooth lighting interpolation");
    private final SettingNumber brightness = new SettingNumber("Brightness", 1.0f, 0.0f, 2.0f, 0.1f, "Lightmap brightness multiplier");

    private float originalGamma = 1.0f;
    private boolean wasEnabled = false;

    public FullbrightModule() {
        super("Fullbright", "Macht die Welt heller durch Anpassung der Lichtmap-Werte.", ModuleCategory.VISUALS);
        addSetting(smoothLighting);
        addSetting(brightness);
    }

    @Override
    public void onEnable() {
        wasEnabled = true;
        originalGamma = mc.options.gamma;
        // Apply brightness via gamma adjustment - reversible
        applyBrightness();
    }

    @Override
    public void onDisable() {
        // Restore original gamma
        mc.options.gamma = originalGamma;
        wasEnabled = false;
    }

    @Override
    public void onReset() {
        if (isEnabled()) {
            mc.options.gamma = originalGamma;
        }
        wasEnabled = false;
    }

    @Override
    public void onTick() {
        if (!wasEnabled || !isInGame()) {
            return;
        }
        applyBrightness();
    }

    private void applyBrightness() {
        float targetGamma = brightness.getValue();
        // Smoothly interpolate gamma to avoid sudden jumps
        float currentGamma = mc.options.gamma;
        mc.options.gamma = currentGamma + (targetGamma - currentGamma) * 0.1f;

        // Clamp to reasonable range
        if (mc.options.gamma < 0.1f) mc.options.gamma = 0.1f;
        if (mc.options.gamma > 5.0f) mc.options.gamma = 5.0f;
    }

    @Override
    public void onPanic() {
        onDisable();
    }
}