package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import org.joml.Vector2i;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Chunk Analyzer module - analyzes loaded chunks and block distributions.
 * Only uses client-side known world information. Limited analysis per tick.
 * No claim of reading unloaded chunks or server-side hidden information.
 */
public class ChunkAnalyzerModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showChunkBounds = new SettingBoolean("Show Chunk Bounds", false, "Display chunk boundary lines");
    private final SettingBoolean showBlockStats = new SettingBoolean("Show Block Stats", true, "Display local block distribution statistics");
    private final SettingNumber analysisRange = new SettingNumber("Range", 4, 1, 16, 1, "Analysis range in chunks");

    private boolean analyzing = false;
    private int ticksSinceAnalysis = 0;
    private int analysisProgress = 0;
    private int analysisTotal = 0;
    private Map<String, Integer> blockStats = new HashMap<>();
    private List<ChunkPos> loadedChunks = new ArrayList<>();
    private long lastAnalysisTime = 0;

    public ChunkAnalyzerModule() {
        super("Chunk Analyzer", "Analysiert geladene Chunks und Blockverteilungen.", ModuleCategory.WORLD_ANALYSIS);
        addSetting(showChunkBounds);
        addSetting(showBlockStats);
        addSetting(analysisRange);
    }

    @Override
    public void onEnable() {
        blockStats.clear();
        loadedChunks.clear();
        analysisProgress = 0;
        analysisTotal = 0;
        analyzing = false;
    }

    @Override
    public void onDisable() {
        blockStats.clear();
        loadedChunks.clear();
    }

    @Override
    public void onReset() {
        blockStats.clear();
        loadedChunks.clear();
        analysisProgress = 0;
        analysisTotal = 0;
        analyzing = false;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.world == null || mc.player == null) {
            return;
        }

        ticksSinceAnalysis++;

        // Limit analysis to small steps per tick to avoid blocking
        if (ticksSinceAnalysis < 5) {
            return;
        }
        ticksSinceAnalysis = 0;

        performAnalysisStep();
    }

    private void performAnalysisStep() {
        ClientWorld world = mc.world;

        // Get loaded chunks around player
        loadedChunks.clear();
        BlockPos playerPos = mc.player.getBlockPos();
        ChunkPos playerChunk = new ChunkPos(playerPos);
        int range = (int) analysisRange.getValue();

        long startTime = System.nanoTime();
        int chunksAnalyzed = 0;

        for (int x = -range; x <= range; x++) {
            for (int z = -range; z <= range; z++) {
                ChunkPos chunkPos = new ChunkPos(playerChunk.x + x, playerChunk.z + z);

                // Check if chunk is loaded
                if (world.getChunkManager().getWorldChunk(chunkPos.x, chunkPos.z) != null) {
                    loadedChunks.add(chunkPos);
                    chunksAnalyzed++;

                    // Only analyze a few chunks per tick to avoid blocking
                    if (chunksAnalyzed > 2) {
                        return;
                    }

                    // Time limit per analysis step (~1ms)
                    if (System.nanoTime() - startTime > 1_000_000L) {
                        return;
                    }
                }
            }
        }
    }

    public void analyzeBlockDistribution() {
        if (!isInGame() || mc.world == null || mc.player == null) {
            return;
        }

        blockStats.clear();
        BlockPos playerPos = mc.player.getBlockPos();
        int range = (int) analysisRange.getValue() * 16; // Convert chunks to blocks

        analyzing = true;
        analysisProgress = 0;
        analysisTotal = 0;

        for (int x = -range; x <= range; x += 4) {
            for (int y = -range; y <= range; y += 4) {
                for (int z = -range; z <= range; z += 4) {
                    BlockPos pos = playerPos.add(x, y, z);
                    if (mc.world.isChunkLoaded(pos)) {
                        var state = mc.world.getBlockState(pos);
                        String blockName = state.getBlock().getName().getString();
                        blockStats.merge(blockName, 1, Integer::sum);
                        analysisTotal++;
                    }
                    analysisProgress++;
                }
            }
        }

        analyzing = false;
        FPSOptimizerClient.getNotificationManager().add(
            "notification.fpsoptimizer.config_saved",
            "Chunk Analysis Complete",
            "Analyzed " + analysisTotal + " blocks"
        );
    }

    public boolean isAnalyzing() {
        return analyzing;
    }

    public int getAnalysisProgress() {
        return analysisProgress;
    }

    public int getAnalysisTotal() {
        return analysisTotal;
    }

    public Map<String, Integer> getBlockStats() {
        return blockStats;
    }

    public List<ChunkPos> getLoadedChunks() {
        return loadedChunks;
    }

    public boolean isShowChunkBounds() {
        return showChunkBounds.getValue();
    }

    public boolean isShowBlockStats() {
        return showBlockStats.getValue();
    }

    public double getAnalysisRange() {
        return analysisRange.getValue();
    }

    @Override
    public void onPanic() {
        blockStats.clear();
        loadedChunks.clear();
        analyzing = false;
    }
}