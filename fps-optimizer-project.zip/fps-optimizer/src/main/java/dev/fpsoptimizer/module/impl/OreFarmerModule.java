package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingNumber;
import dev.fpsoptimizer.setting.SettingEnum;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * OreFarmer Module - baut automatisch ausgewählte Ores ab.
 * Bis zu 10 spezifische Ore-Typen können ausgewählt werden.
 * Verwendet automatisch das beste Werkzeug.
 */
public class OreFarmerModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean enabledOres = new SettingBoolean("Enable Ore Farming", false, "Ore-Farming aktivieren");
    private final SettingNumber range = new SettingNumber("Range", 8.0, 1.0, 32.0, 1.0, "Abbau-Reichweite in Blöcken");
    private final SettingNumber delay = new SettingNumber("Mine Delay", 3, 1, 20, 1, "Ticks zwischen Abbauvorgängen");
    private final SettingBoolean autoTool = new SettingBoolean("Auto Tool", true, "Automatisch bestes Werkzeug wählen");
    private final SettingNumber maxOres = new SettingNumber("Max Ores", 5, 1, 10, 1, "Maximale Anzahl gleichzeitig verfolgter Ores");

    // Individuelle Ore-Auswahl (bis zu 10)
    private final SettingBoolean mineCoal = new SettingBoolean("Coal Ore", true, "Kohle-Erz abbauen");
    private final SettingBoolean mineIron = new SettingBoolean("Iron Ore", true, "Eisen-Erz abbauen");
    private final SettingBoolean mineGold = new SettingBoolean("Gold Ore", true, "Gold-Erz abbauen");
    private final SettingBoolean mineDiamond = new SettingBoolean("Diamond Ore", true, "Diamant-Erz abbauen");
    private final SettingBoolean mineEmerald = new SettingBoolean("Emerald Ore", true, "Smaragd-Erz abbauen");
    private final SettingBoolean mineRedstone = new SettingBoolean("Redstone Ore", true, "Redstone-Erz abbauen");
    private final SettingBoolean mineLapis = new SettingBoolean("Lapis Ore", true, "Lapislazuli-Erz abbauen");
    private final SettingBoolean mineCopper = new SettingBoolean("Copper Ore", true, "Kupfer-Erz abbauen");
    private final SettingBoolean mineAncientDebris = new SettingBoolean("Ancient Debris", false, "Altes Schutt abbauen");
    private final SettingBoolean mineDeepslateVariants = new SettingBoolean("Deepslate Variants", true, "Deepslate-Erzvarianten abbauen");

    private int ticksSinceLastMine = 0;
    private BlockPos currentTarget = null;

    public OreFarmerModule() {
        super("OreFarmer", "Baut automatisch ausgewählte Ores ab.", ModuleCategory.UTILITY);
        addSetting(enabledOres);
        addSetting(range);
        addSetting(delay);
        addSetting(autoTool);
        addSetting(maxOres);
        addSetting(mineCoal);
        addSetting(mineIron);
        addSetting(mineGold);
        addSetting(mineDiamond);
        addSetting(mineEmerald);
        addSetting(mineRedstone);
        addSetting(mineLapis);
        addSetting(mineCopper);
        addSetting(mineAncientDebris);
        addSetting(mineDeepslateVariants);
    }

    @Override
    public void onEnable() {
        ticksSinceLastMine = 0;
        currentTarget = null;
    }

    @Override
    public void onDisable() {
        currentTarget = null;
    }

    @Override
    public void onReset() {
        currentTarget = null;
        ticksSinceLastMine = 0;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.player == null || mc.world == null || mc.interactionManager == null) {
            currentTarget = null;
            return;
        }

        if (!enabledOres.getValue()) {
            currentTarget = null;
            return;
        }

        ticksSinceLastMine++;

        if (ticksSinceLastMine < delay.getValue()) {
            return;
        }

        BlockPos target = findBestOreTarget();
        if (target != null) {
            currentTarget = target;
            mineBlock(target);
            ticksSinceLastMine = 0;
        } else {
            currentTarget = null;
        }
    }

    @Override
    public void onPanic() {
        currentTarget = null;
        ticksSinceLastMine = 0;
    }

    private BlockPos findBestOreTarget() {
        if (mc.player == null || mc.world == null) return null;

        double range = this.range.getValue();
        BlockPos playerPos = mc.player.getBlockPos();
        List<BlockPos> candidates = new ArrayList<>();

        int rangeBlocks = (int) Math.ceil(range);

        for (int x = -rangeBlocks; x <= rangeBlocks; x++) {
            for (int y = -rangeBlocks; y <= rangeBlocks; y++) {
                for (int z = -rangeBlocks; z <= rangeBlocks; z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    if (mc.world.isChunkLoaded(pos) && isTargetOre(pos)) {
                        candidates.add(pos);
                    }
                    if (candidates.size() > maxOres.getValue() * 4) break;
                }
                if (candidates.size() > maxOres.getValue() * 4) break;
            }
            if (candidates.size() > maxOres.getValue() * 4) break;
        }

        if (candidates.isEmpty()) return null;

        // Nächstes Ore wählen
        candidates.sort((a, b) -> Double.compare(
            a.getSquaredDistance(playerPos.getX(), playerPos.getY(), playerPos.getZ()),
            b.getSquaredDistance(playerPos.getX(), playerPos.getY(), playerPos.getZ())
        ));

        return candidates.get(0);
    }

    private boolean isTargetOre(BlockPos pos) {
        var state = mc.world.getBlockState(pos);
        Block block = state.getBlock();

        if (block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE) return mineCoal.getValue();
        if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) return mineIron.getValue();
        if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE) return mineGold.getValue();
        if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) return mineDiamond.getValue();
        if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) return mineEmerald.getValue();
        if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) return mineRedstone.getValue();
        if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) return mineLapis.getValue();
        if (block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE) return mineCopper.getValue();
        if (block == Blocks.ANCIENT_DEBRIS) return mineAncientDebris.getValue();

        if (mineDeepslateVariants.getValue()) {
            // Deepslate-Varianten werden bereits oben einzeln geprüft
        }

        return false;
    }

    private void mineBlock(BlockPos pos) {
        if (mc.player == null || mc.interactionManager == null) return;

        // Blickrichtung zum Block ausrichten
        Vec3d posVec = Vec3d.ofCenter(pos);
        double dx = posVec.getX() - mc.player.getX();
        double dy = posVec.getY() - mc.player.getEyeY();
        double dz = posVec.getZ() - mc.player.getZ();

        float yaw = (float) (Math.toDegrees(Math.atan2(-dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));

        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);

        // Werkzeug auswählen wenn aktiviert
        if (autoTool.getValue()) {
            selectBestTool(pos);
        }

        // Abbau starten
        mc.interactionManager.attackBlock(pos, net.minecraft.util.math.Direction.UP);
    }

    private void selectBestTool(BlockPos pos) {
        if (mc.player == null) return;

        var inventory = mc.player.getInventory();
        var blockState = mc.world.getBlockState(pos);

        int bestSlot = -1;
        float bestEfficiency = 0.0f;

        for (int i = 0; i < inventory.size(); i++) {
            var stack = inventory.getStack(i);
            if (stack.isEmpty()) continue;

            var item = stack.getItem();
            float efficiency = getToolEfficiency(item, blockState);

            if (efficiency <= 0.0f) continue;

            if (efficiency > bestEfficiency) {
                bestEfficiency = efficiency;
                bestSlot = i;
            }
        }

        if (bestSlot != -1 && inventory.selectedSlot != bestSlot) {
            inventory.selectedSlot = bestSlot;
        }
    }

    private float getToolEfficiency(net.minecraft.item.Item item, net.minecraft.block.BlockState state) {
        if (item instanceof net.minecraft.item.ToolItem toolItem) {
            return toolItem.getMiningSpeedMultiplier();
        }
        return 0.0f;
    }

    public BlockPos getCurrentTarget() {
        return currentTarget;
    }

    public double getRange() {
        return range.getValue();
    }
}