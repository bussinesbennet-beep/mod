package dev.fpsoptimizer.module.impl;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleCategory;
import dev.fpsoptimizer.setting.SettingBoolean;
import dev.fpsoptimizer.setting.SettingColor;
import dev.fpsoptimizer.setting.SettingNumber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.RenderLayer;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Entity ESP module - highlights entities with bounding boxes and names.
 * Configurable entity types with names and colors.
 */
public class EntityEspModule extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private final SettingBoolean showPlayers = new SettingBoolean("Show Players", true, "Highlight player entities");
    private final SettingBoolean showMobs = new SettingBoolean("Show Mobs", true, "Highlight mob entities");
    private final SettingBoolean showAnimals = new SettingBoolean("Show Animals", true, "Highlight animal entities");
    private final SettingBoolean showNames = new SettingBoolean("Show Names", true, "Display entity names");
    private final SettingBoolean showBoxes = new SettingBoolean("Show Boxes", true, "Display entity bounding boxes");
    private final SettingNumber range = new SettingNumber("Range", 64.0, 10.0, 256.0, 5.0, "Maximum render distance");
    private final SettingColor playerColor = new SettingColor("Player Color", 0xFF00FF00, "Color for player ESP");
    private final SettingColor mobColor = new SettingColor("Mob Color", 0xFFFF0000, "Color for mob ESP");
    private final SettingColor animalColor = new SettingColor("Animal Color", 0xFF0000FF, "Color for animal ESP");
    private final SettingNumber maxEntities = new SettingNumber("Max Entities", 100, 10, 500, 10, "Maximum entities to render");

    private int ticksSinceUpdate = 0;
    private List<EspEntity> entities = new ArrayList<>();

    private static class EspEntity {
        Entity entity;
        int color;
        double distance;

        EspEntity(Entity entity, int color, double distance) {
            this.entity = entity;
            this.color = color;
            this.distance = distance;
        }
    }

    public EntityEspModule() {
        super("Entity ESP", "Hebt Entitäten mit Begrenzungsboxen und Namen hervor.", ModuleCategory.VISUALS);
        addSetting(showPlayers);
        addSetting(showMobs);
        addSetting(showAnimals);
        addSetting(showNames);
        addSetting(showBoxes);
        addSetting(range);
        addSetting(playerColor);
        addSetting(mobColor);
        addSetting(animalColor);
        addSetting(maxEntities);
    }

    @Override
    public void onEnable() {
        entities.clear();
        ticksSinceUpdate = 0;
    }

    @Override
    public void onDisable() {
        entities.clear();
    }

    @Override
    public void onReset() {
        entities.clear();
        ticksSinceUpdate = 0;
    }

    @Override
    public void onTick() {
        if (!isInGame() || mc.world == null || mc.player == null) {
            return;
        }

        ticksSinceUpdate++;
        if (ticksSinceUpdate < 10) {
            return;
        }
        ticksSinceUpdate = 0;

        updateEntities();
    }

    private void updateEntities() {
        entities.clear();

        if (mc.player == null || mc.world == null) {
            return;
        }

        ClientWorld world = mc.world;
        double range = this.range.getValue();

        for (Entity entity : world.getEntities()) {
            if (entity == mc.player) continue;
            if (!entity.isAlive()) continue;

            double dist = entity.distanceTo(mc.player);
            if (dist > range) continue;

            int color;
            if (entity instanceof PlayerEntity) {
                if (!showPlayers.getValue()) continue;
                color = playerColor.getValue();
            } else if (entity.isType(net.minecraft.entity.EntityType.PLAYER)) {
                if (!showPlayers.getValue()) continue;
                color = playerColor.getValue();
            } else if (isAnimal(entity)) {
                if (!showAnimals.getValue()) continue;
                color = animalColor.getValue();
            } else if (isMob(entity)) {
                if (!showMobs.getValue()) continue;
                color = mobColor.getValue();
            } else {
                continue;
            }

            if (entities.size() < maxEntities.getValue()) {
                entities.add(new EspEntity(entity, color, dist));
            }
        }

        // Sort by distance (closest first)
        entities.sort((a, b) -> Double.compare(a.distance, b.distance));
    }

    private boolean isAnimal(Entity entity) {
        return entity.getType() == net.minecraft.entity.EntityType.COW ||
               entity.getType() == net.minecraft.entity.EntityType.PIG ||
               entity.getType() == net.minecraft.entity.EntityType.SHEEP ||
               entity.getType() == net.minecraft.entity.EntityType.CHICKEN ||
               entity.getType() == net.minecraft.entity.EntityType.RABBIT ||
               entity.getType() == net.minecraft.entity.EntityType.HORSE ||
               entity.getType() == net.minecraft.entity.EntityType.WOLF ||
               entity.getType() == net.minecraft.entity.EntityType.CAT;
    }

    private boolean isMob(Entity entity) {
        return entity.getType() == net.minecraft.entity.EntityType.ZOMBIE ||
               entity.getType() == net.minecraft.entity.EntityType.SKELETON ||
               entity.getType() == net.minecraft.entity.EntityType.CREEPER ||
               entity.getType() == net.minecraft.entity.EntityType.SPIDER ||
               entity.getType() == net.minecraft.entity.EntityType.ENDERMAN ||
               entity.getType() == net.minecraft.entity.EntityType.WITCH ||
               entity.getType() == net.minecraft.entity.EntityType.BLAZE ||
               entity.getType() == net.minecraft.entity.EntityType.GHAST;
    }

    @Override
    public void onRender(float tickDelta) {
        if (!isInGame() || mc.world == null || mc.player == null || mc.gameRenderer == null) {
            return;
        }

        double camX = mc.gameRenderer.getCamera().getX();
        double camY = mc.gameRenderer.getCamera().getY();
        double camZ = mc.gameRenderer.getCamera().getZ();

        MatrixStack matrixStack = new MatrixStack();
        VertexConsumerProvider.Immediate immediate = mc.getVertexConsumers();
        VertexConsumer vertexConsumer = immediate.getBuffer(RenderLayer.getLines());

        Matrix4f matrix = matrixStack.peek().getPositionMatrix();

        for (EspEntity espEntity : entities) {
            Entity entity = espEntity.entity;
            if (entity == null || !entity.isAlive()) continue;

            int color = espEntity.color;
            float r = ((color >> 16) & 0xFF) / 255.0f;
            float g = ((color >> 8) & 0xFF) / 255.0f;
            float b = (color & 0xFF) / 255.0f;
            float a = 0.6f;

            // Draw bounding box
            if (showBoxes.getValue()) {
                Box box = entity.getBoundingBox().offset(-camX, -camY, -camZ);
                drawBox(matrixStack, vertexConsumer, box, r, g, b, a);
            }

            // Draw name
            if (showNames.getValue()) {
                // Name rendering would go here - simplified for now
            }
        }

        immediate.draw();
    }

    private void drawBox(MatrixStack matrixStack, VertexConsumer vertexConsumer, Box box, float r, float g, float b, float a) {
        Matrix4f matrix = matrixStack.peek().getPositionMatrix();

        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.minZ, box.maxX, box.minY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.minZ, box.maxX, box.maxY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.minZ, box.minX, box.maxY, box.minZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.minZ, box.minX, box.minY, box.minZ, r, g, b, a);

        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.maxZ, box.maxX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.maxZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.maxZ, box.minX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.maxZ, box.minX, box.minY, box.maxZ, r, g, b, a);

        drawLine(matrix, vertexConsumer, box.minX, box.minY, box.minZ, box.minX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.minY, box.minZ, box.maxX, box.minY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.maxX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(matrix, vertexConsumer, box.minX, box.maxY, box.minZ, box.minX, box.maxY, box.maxZ, r, g, b, a);
    }

    private void drawLine(Matrix4f matrix, VertexConsumer consumer, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
        consumer.vertex(matrix, x1, y1, z1).color(r, g, b, a).next();
        consumer.vertex(matrix, x2, y2, z2).color(r, g, b, a).next();
    }

    @Override
    public void onPanic() {
        entities.clear();
    }
}