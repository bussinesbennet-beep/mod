package dev.fpsoptimizer.hud.element;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.module.impl.HudCpsModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawContext;

/**
 * CPS HUD element - displays clicks per second.
 */
public class CpsHudElement extends HudElement {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public CpsHudElement(String id, String name, int x, int y) {
        super(id, name, x, y);
        setWidth(80);
        setHeight(20);
    }

    @Override
    public void render(MatrixStack matrixStack, float tickDelta) {
        if (!isVisible() || mc.player == null) {
            return;
        }

        HudCpsModule cpsModule = getCpsModule();
        if (cpsModule == null) {
            return;
        }

        DrawContext context = new DrawContext(mc.getVertexConsumers());

        int y = getY();

        if (cpsModule.isShowLeft()) {
            context.drawText(mc.textRenderer, "L: " + cpsModule.getLeftCps(), getX(), y, 0x00FF00, false);
            y += 10;
        }
        if (cpsModule.isShowRight()) {
            context.drawText(mc.textRenderer, "R: " + cpsModule.getRightCps(), getX(), y, 0xFF0000, false);
        }
    }

    private HudCpsModule getCpsModule() {
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        var module = moduleManager.getModuleByName("CPS");
        if (module instanceof HudCpsModule) {
            return (HudCpsModule) module;
        }
        return null;
    }
}