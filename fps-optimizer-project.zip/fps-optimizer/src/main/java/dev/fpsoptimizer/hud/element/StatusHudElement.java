package dev.fpsoptimizer.hud.element;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.Module;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.module.impl.HudStatusModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawContext;

/**
 * Status HUD element - displays status of active modules.
 */
public class StatusHudElement extends HudElement {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public StatusHudElement(String id, String name, int x, int y) {
        super(id, name, x, y);
        setWidth(100);
        setHeight(100);
    }

    @Override
    public void render(MatrixStack matrixStack, float tickDelta) {
        if (!isVisible() || mc.player == null) {
            return;
        }

        HudStatusModule statusModule = getStatusModule();
        if (statusModule == null) {
            return;
        }

        DrawContext context = new DrawContext(mc.getVertexConsumers());
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        int y = getY();

        context.drawText(mc.textRenderer, "Active Modules:", getX(), y, 0xFFFFFFFF, false);
        y += 10;

        for (Module module : moduleManager.getModules()) {
            if (!module.isEnabled()) continue;

            switch (module.getName()) {
                case "Fullbright":
                    if (!statusModule.isShowFullbright()) continue;
                    break;
                case "Freecam":
                    if (!statusModule.isShowFreecam()) continue;
                    break;
                case "AutoTool":
                    if (!statusModule.isShowAutoTool()) continue;
                    break;
                case "AutoEat":
                    if (!statusModule.isShowAutoEat()) continue;
                    break;
                case "Navigation":
                    if (!statusModule.isShowNavigation()) continue;
                    break;
                default:
                    continue;
            }

            int color = module.isEnabled() ? 0x00FF00 : 0xFF0000;
            context.drawText(mc.textRenderer, module.getName(), getX(), y, color, false);
            y += 10;
        }
    }

    private HudStatusModule getStatusModule() {
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        var module = moduleManager.getModuleByName("Status");
        if (module instanceof HudStatusModule) {
            return (HudStatusModule) module;
        }
        return null;
    }
}