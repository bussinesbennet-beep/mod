package dev.fpsoptimizer.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Base class for HUD elements.
 * HUD elements display information on screen and can be positioned,
 * scaled, and shown/hidden by the user.
 */
public abstract class HudElement {

    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private String id;
    private String name;
    private int x;
    private int y;
    private boolean visible;
    private float scale;
    private int width;
    private int height;

    public HudElement(String id, String name, int x, int y) {
        this.id = id;
        this.name = name;
        this.x = x;
        this.y = y;
        this.visible = true;
        this.scale = 1.0f;
        this.width = 100;
        this.height = 20;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public float getScale() {
        return scale;
    }

    public void setScale(float scale) {
        this.scale = Math.max(0.5f, Math.min(2.0f, scale));
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * Check if a point is within this element's bounds.
     */
    public boolean contains(int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width &&
               mouseY >= y && mouseY <= y + height;
    }

    /**
     * Render the HUD element.
     */
    public abstract void render(MatrixStack matrixStack, float tickDelta);

    /**
     * Update the element's state (called each tick).
     */
    public void update() {
        // Default: no update logic
    }

    /**
     * Get the rendered width (taking scale into account).
     */
    public int getScaledWidth() {
        return (int) (width * scale);
    }

    /**
     * Get the rendered height (taking scale into account).
     */
    public int getScaledHeight() {
        return (int) (height * scale);
    }
}