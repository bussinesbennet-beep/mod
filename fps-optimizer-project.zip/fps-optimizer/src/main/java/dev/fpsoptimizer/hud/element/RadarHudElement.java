package dev.fpsoptimizer.hud.element;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.module.impl.RadarModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawContext;

/**
 * Radar HUD element - displays a radar showing nearby players and entities.
 */
public class RadarHudElement extends HudElement {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public RadarHudElement(String id, String name, int x, int y) {
        super(id, name, x, y);
        setWidth(140);
        setHeight(140);
    }

    @Override
    public void render(MatrixStack matrixStack, float tickDelta) {
        if (!isVisible() || mc.player == null) {
            return;
        }

        RadarModule radarModule = getRadarModule();
        if (radarModule == null) {
            return;
        }

        DrawContext context = new DrawContext(mc.getVertexConsumers());

        int centerX = getX() + getWidth() / 2;
        int centerY = getY() + getHeight() / 2;
        int radius = Math.min(getWidth(), getHeight()) / 2 - 5;

        // Draw radar background
        context.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), 0x80000000);
        context.drawText(mc.textRenderer, "Radar", getX() + 5, getY() + 5, 0xFFFFFF, false);

        // Draw range circle outline
        drawCircle(context, centerX, centerY, radius, 0x404040);

        // Draw player position (center)
        context.fill(centerX - 2, centerY - 2, centerX + 2, centerY + 2, 0x00FF00);

        // Get player facing direction
        float yaw = mc.player.getYaw();
        if (radarModule.isFixedNorth()) {
            yaw = 0; // Fixed north
        }

        // Draw blips
        for (RadarModule.RadarBlip blip : radarModule.getBlips()) {
            double dx = blip.x - mc.player.getX();
            double dz = blip.z - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);

            if (dist > radarModule.getRange()) continue;

            // Calculate angle relative to player
            double angle = Math.toDegrees(Math.atan2(-dx, dz)) - yaw;
            angle = MathUtil.normalizeAngle((float) angle);

            // Convert to screen position
            double rad = Math.toRadians(angle);
            double rangeFactor = dist / radarModule.getRange();
            int blipX = (int) (centerX + Math.sin(rad) * rangeFactor * radius);
            int blipY = (int) (centerY - Math.cos(rad) * rangeFactor * radius);

            // Draw blip
            int color = blip.isPlayer ? 0x00FF00 : 0xFF0000;
            context.fill(blipX - 2, blipY - 2, blipX + 2, blipY + 2, color);
        }
    }

    private void drawCircle(DrawContext context, int centerX, int centerY, int radius, int color) {
        int segments = 32;
        for (int i = 0; i < segments; i++) {
            double angle1 = 2 * Math.PI * i / segments;
            double angle2 = 2 * Math.PI * (i + 1) / segments;
            int x1 = (int) (centerX + Math.cos(angle1) * radius);
            int y1 = (int) (centerY + Math.sin(angle1) * radius);
            int x2 = (int) (centerX + Math.cos(angle2) * radius);
            int y2 = (int) (centerY + Math.sin(angle2) * radius);
            drawLine(context, x1, y1, x2, y2, color);
        }
    }

    private void drawLine(DrawContext context, int x1, int y1, int x2, int y2, int color) {
        // Simple line drawing using fill steps
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;

        int x = x1, y = y1;
        while (true) {
            context.fill(x, y, x + 1, y + 1, color);
            if (x == x2 && y == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x += sx; }
            if (e2 < dx) { err += dx; y += sy; }
        }
    }

    private RadarModule getRadarModule() {
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        var module = moduleManager.getModuleByName("Radar");
        if (module instanceof RadarModule) {
            return (RadarModule) module;
        }
        return null;
    }
}