package dev.fpsoptimizer.hud.element;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.module.impl.HudArmorModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;

/**
 * Armor HUD element - displays armor durability and status.
 */
public class ArmorHudElement extends HudElement {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public ArmorHudElement(String id, String name, int x, int y) {
        super(id, name, x, y);
        setWidth(80);
        setHeight(10);
    }

    @Override
    public void render(MatrixStack matrixStack, float tickDelta) {
        if (!isVisible() || mc.player == null) {
            return;
        }

        HudArmorModule armorModule = getArmorModule();
        if (armorModule == null) {
            return;
        }

        DrawContext context = new DrawContext(mc.getVertexConsumers());

        StringBuilder text = new StringBuilder("Armor: ");

        if (armorModule.isShowHelmet() && armorModule.hasArmor(EquipmentSlot.HEAD)) {
            text.append("H:").append(Math.round(armorModule.getDurability(EquipmentSlot.HEAD))).append("% ");
        }
        if (armorModule.isShowChestplate() && armorModule.hasArmor(EquipmentSlot.CHEST)) {
            text.append("C:").append(Math.round(armorModule.getDurability(EquipmentSlot.CHEST))).append("% ");
        }
        if (armorModule.isShowLeggings() && armorModule.hasArmor(EquipmentSlot.LEGS)) {
            text.append("L:").append(Math.round(armorModule.getDurability(EquipmentSlot.LEGS))).append("% ");
        }
        if (armorModule.isShowBoots() && armorModule.hasArmor(EquipmentSlot.FEET)) {
            text.append("B:").append(Math.round(armorModule.getDurability(EquipmentSlot.FEET))).append("% ");
        }

        int armorPoints = armorModule.getTotalArmorPoints();
        text.append("(").append(armorPoints).append(")");

        context.drawText(mc.textRenderer, text.toString(), getX(), getY(), 0xFFFFFF, false);

        // Warn if low durability
        if (armorModule.isWarnLowDurability()) {
            boolean low = false;
            if (armorModule.isShowHelmet() && armorModule.hasArmor(EquipmentSlot.HEAD) &&
                armorModule.getDurability(EquipmentSlot.HEAD) < armorModule.getLowDurabilityThreshold()) {
                low = true;
            }
            if (armorModule.isShowChestplate() && armorModule.hasArmor(EquipmentSlot.CHEST) &&
                armorModule.getDurability(EquipmentSlot.CHEST) < armorModule.getLowDurabilityThreshold()) {
                low = true;
            }
            if (armorModule.isShowLeggings() && armorModule.hasArmor(EquipmentSlot.LEGS) &&
                armorModule.getDurability(EquipmentSlot.LEGS) < armorModule.getLowDurabilityThreshold()) {
                low = true;
            }
            if (armorModule.isShowBoots() && armorModule.hasArmor(EquipmentSlot.FEET) &&
                armorModule.getDurability(EquipmentSlot.FEET) < armorModule.getLowDurabilityThreshold()) {
                low = true;
            }

            if (low) {
                context.drawText(mc.textRenderer, "LOW DURABILITY", getX(), getY() + 10, 0xFFFF0000, false);
            }
        }
    }

    private HudArmorModule getArmorModule() {
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        var module = moduleManager.getModuleByName("Armor");
        if (module instanceof HudArmorModule) {
            return (HudArmorModule) module;
        }
        return null;
    }
}