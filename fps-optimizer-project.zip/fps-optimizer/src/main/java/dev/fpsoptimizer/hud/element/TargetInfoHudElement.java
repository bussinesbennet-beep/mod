package dev.fpsoptimizer.hud.element;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.module.impl.HudTargetInfoModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;

/**
 * Target Info HUD element - displays information about the targeted entity.
 */
public class TargetInfoHudElement extends HudElement {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public TargetInfoHudElement(String id, String name, int x, int y) {
        super(id, name, x, y);
        setWidth(120);
        setHeight(30);
    }

    @Override
    public void render(MatrixStack matrixStack, float tickDelta) {
        if (!isVisible() || mc.player == null) {
            return;
        }

        HudTargetInfoModule targetModule = getTargetModule();
        if (targetModule == null || !targetModule.hasTarget()) {
            return;
        }

        DrawContext context = new DrawContext(mc.getVertexConsumers());
        Entity target = targetModule.getTarget();
        int y = getY();

        if (targetModule.isShowName()) {
            context.drawText(mc.textRenderer, "Target: " + target.getName().getString(), getX(), y, 0xFFFFFF, false);
            y += 10;
        }
        if (targetModule.isShowDistance()) {
            context.drawText(mc.textRenderer, "Dist: " + String.format("%.1f", targetModule.getDistance()), getX(), y, 0xFFFFFF, false);
            y += 10;
        }
        if (targetModule.isShowHealth()) {
            float health = target.getHealth();
            context.drawText(mc.textRenderer, "HP: " + Math.round(health), getX(), y, health > 5 ? 0x00FF00 : 0xFF0000, false);
            y += 10;
        }
        if (targetModule.isShowType()) {
            context.drawText(mc.textRenderer, "Type: " + target.getType().getName().getString(), getX(), y, 0xAAAAAA, false);
        }
    }

    private HudTargetInfoModule getTargetModule() {
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        var module = moduleManager.getModuleByName("Target Info");
        if (module instanceof HudTargetInfoModule) {
            return (HudTargetInfoModule) module;
        }
        return null;
    }
}