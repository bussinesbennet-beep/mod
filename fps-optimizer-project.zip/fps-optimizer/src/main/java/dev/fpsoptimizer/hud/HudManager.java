package dev.fpsoptimizer.hud;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.hud.element.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Manages HUD elements for FPS Optimizer.
 * Handles rendering, positioning, and updating of all HUD elements.
 */
public class HudManager {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.HudManager");

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final List<HudElement> elements = new ArrayList<>();

    private boolean editorOpen = false;

    public HudManager() {
        registerDefaultElements();
    }

    private void registerDefaultElements() {
        // Register HUD elements
        elements.add(new FpsHudElement("fps", "FPS", 10, 10));
        elements.add(new CoordsHudElement("coords", "Coordinates", 10, 40));
        elements.add(new ArmorHudElement("armor", "Armor", 10, 70));
        elements.add(new KeystrokesHudElement("keystrokes", "Keystrokes", 10, 110));
        elements.add(new CpsHudElement("cps", "CPS", 10, 150));
        elements.add(new TargetInfoHudElement("target", "Target Info", 10, 190));
        elements.add(new StatusHudElement("status", "Status", 10, 230));
        elements.add(new RadarHudElement("radar", "Radar", mc.getWindow().getScaledWidth() - 150, 10));

        LOGGER.info("Registered {} HUD elements", elements.size());
    }

    public void update() {
        for (HudElement element : elements) {
            if (element.isVisible()) {
                element.update();
            }
        }
    }

    public void render(MatrixStack matrixStack, float tickDelta) {
        if (mc.player == null) {
            return;
        }

        for (HudElement element : elements) {
            if (element.isVisible()) {
                element.render(matrixStack, tickDelta);
            }
        }
    }

    public List<HudElement> getElements() {
        return elements;
    }

    public HudElement getElementById(String id) {
        for (HudElement element : elements) {
            if (element.getId().equals(id)) {
                return element;
            }
        }
        return null;
    }

    public void addElement(HudElement element) {
        elements.add(element);
    }

    public void removeElement(HudElement element) {
        elements.remove(element);
    }

    public boolean isEditorOpen() {
        return editorOpen;
    }

    public void setEditorOpen(boolean editorOpen) {
        this.editorOpen = editorOpen;
    }

    /**
     * Get scaled screen dimensions for HUD positioning.
     */
    public int getScaledWidth() {
        return mc.getWindow().getScaledWidth();
    }

    public int getScaledHeight() {
        return mc.getWindow().getScaledHeight();
    }

    /**
     * Clamp a position to screen bounds.
     */
    public void clampToScreen(HudElement element) {
        int scaledWidth = getScaledWidth();
        int scaledHeight = getScaledHeight();
        int scaledWidthElem = element.getScaledWidth();
        int scaledHeightElem = element.getScaledHeight();

        int x = Math.max(0, Math.min(element.getX(), scaledWidth - scaledWidthElem));
        int y = Math.max(0, Math.min(element.getY(), scaledHeight - scaledHeightElem));
        element.setPosition(x, y);
    }
}