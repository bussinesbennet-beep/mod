package dev.fpsoptimizer.hud.element;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.module.impl.HudFpsModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawContext;

/**
 * FPS HUD element - displays current frames per second.
 */
public class FpsHudElement extends HudElement {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public FpsHudElement(String id, String name, int x, int y) {
        super(id, name, x, y);
        setWidth(60);
        setHeight(10);
    }

    @Override
    public void render(MatrixStack matrixStack, float tickDelta) {
        if (!isVisible() || mc.player == null) {
            return;
        }

        HudFpsModule fpsModule = getFpsModule();
        if (fpsModule == null) {
            return;
        }

        int fps = fpsModule.getFps();
        float smoothedFps = fpsModule.getSmoothedFps();

        String text = "FPS: " + fps + (fpsModule.isShowSmoothed() ? " (" + Math.round(smoothedFps) + ")" : "");

        DrawContext context = new DrawContext(mc.getVertexConsumers());
        context.drawText(mc.textRenderer, text, getX(), getY(), 0xFFFFFF, false);
    }

    private HudFpsModule getFpsModule() {
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        var module = moduleManager.getModuleByName("FPS");
        if (module instanceof HudFpsModule) {
            return (HudFpsModule) module;
        }
        return null;
    }

    @Override
    public void update() {
        // FPS is updated in the module's tick
    }
}