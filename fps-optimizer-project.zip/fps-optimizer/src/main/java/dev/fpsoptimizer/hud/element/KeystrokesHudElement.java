package dev.fpsoptimizer.hud.element;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.module.impl.HudKeystrokesModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawContext;

/**
 * Keystrokes HUD element - displays pressed keys on screen.
 */
public class KeystrokesHudElement extends HudElement {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public KeystrokesHudElement(String id, String name, int x, int y) {
        super(id, name, x, y);
        setWidth(100);
        setHeight(20);
    }

    @Override
    public void render(MatrixStack matrixStack, float tickDelta) {
        if (!isVisible() || mc.player == null) {
            return;
        }

        HudKeystrokesModule keysModule = getKeysModule();
        if (keysModule == null) {
            return;
        }

        DrawContext context = new DrawContext(mc.getVertexConsumers());

        int y = getY();
        int color = 0xFFFFFF;

        if (keysModule.isShowForward() && keysModule.isForwardPressed()) {
            context.drawText(mc.textRenderer, "W", getX(), y, color, false);
            y += 10;
        }
        if (keysModule.isShowBack() && keysModule.isBackPressed()) {
            context.drawText(mc.textRenderer, "S", getX(), y, color, false);
            y += 10;
        }
        if (keysModule.isShowLeft() && keysModule.isLeftPressed()) {
            context.drawText(mc.textRenderer, "A", getX(), y, color, false);
            y += 10;
        }
        if (keysModule.isShowRight() && keysModule.isRightPressed()) {
            context.drawText(mc.textRenderer, "D", getX(), y, color, false);
            y += 10;
        }
        if (keysModule.isShowSprint() && keysModule.isSprintPressed()) {
            context.drawText(mc.textRenderer, "Sprint", getX(), y, color, false);
            y += 10;
        }
        if (keysModule.isShowSneak() && keysModule.isSneakPressed()) {
            context.drawText(mc.textRenderer, "Sneak", getX(), y, color, false);
            y += 10;
        }
        if (keysModule.isShowJump() && keysModule.isJumpPressed()) {
            context.drawText(mc.textRenderer, "Jump", getX(), y, color, false);
        }
    }

    private HudKeystrokesModule getKeysModule() {
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        var module = moduleManager.getModuleByName("Keystrokes");
        if (module instanceof HudKeystrokesModule) {
            return (HudKeystrokesModule) module;
        }
        return null;
    }
}