package dev.fpsoptimizer.hud.element;

import dev.fpsoptimizer.FPSOptimizerClient;
import dev.fpsoptimizer.module.ModuleManager;
import dev.fpsoptimizer.module.impl.HudCoordsModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawContext;

/**
 * Coordinates HUD element - displays player coordinates and rotation.
 */
public class CoordsHudElement extends HudElement {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public CoordsHudElement(String id, String name, int x, int y) {
        super(id, name, x, y);
        setWidth(120);
        setHeight(10);
    }

    @Override
    public void render(MatrixStack matrixStack, float tickDelta) {
        if (!isVisible() || mc.player == null) {
            return;
        }

        HudCoordsModule coordsModule = getCoordsModule();
        if (coordsModule == null) {
            return;
        }

        StringBuilder text = new StringBuilder("XYZ: ");

        if (coordsModule.isShowX()) {
            text.append(String.format("X: %.1f ", coordsModule.getX()));
        }
        if (coordsModule.isShowY()) {
            text.append(String.format("Y: %.1f ", coordsModule.getY()));
        }
        if (coordsModule.isShowZ()) {
            text.append(String.format("Z: %.1f ", coordsModule.getZ()));
        }

        if (coordsModule.isShowRotation()) {
            text.append(String.format("Yaw: %.1f Pitch: %.1f ", coordsModule.getYaw(), coordsModule.getPitch()));
        }

        if (coordsModule.isShowDimension()) {
            text.append("[").append(coordsModule.getDimension()).append("]");
        }

        DrawContext context = new DrawContext(mc.getVertexConsumers());
        context.drawText(mc.textRenderer, text.toString(), getX(), getY(), 0xFFFFFF, false);
    }

    private HudCoordsModule getCoordsModule() {
        ModuleManager moduleManager = FPSOptimizerClient.getModuleManager();
        var module = moduleManager.getModuleByName("Coordinates");
        if (module instanceof HudCoordsModule) {
            return (HudCoordsModule) module;
        }
        return null;
    }
}