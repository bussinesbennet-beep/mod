package dev.fpsoptimizer.notification;

import dev.fpsoptimizer.FPSOptimizerClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Central notification manager for FPS Optimizer.
 * Displays toast-style notifications in the upper right corner.
 * Notifications are not recreated every render frame.
 */
public class NotificationManager {

    private static final Logger LOGGER = LoggerFactory.getLogger("FPSOptimizer.NotificationManager");

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final List<Notification> notifications = new CopyOnWriteArrayList<>();

    private int maxNotifications = 5;
    private int notificationWidth = 200;
    private int notificationHeight = 50;
    private int durationSeconds = 5;

    public NotificationManager() {
        // Default settings
    }

    /**
     * Add a new notification with translation keys.
     */
    public void add(String titleKey, String title, String subtitle) {
        add(new Notification(
            titleKey,
            title,
            subtitle,
            null,
            durationSeconds
        ));
    }

    /**
     * Add a notification with custom duration.
     */
    public void add(String titleKey, String title, String subtitle, int durationSeconds) {
        add(new Notification(titleKey, title, subtitle, null, durationSeconds));
    }

    /**
     * Add a notification object directly.
     */
    public void add(Notification notification) {
        // Don't add duplicate notifications with the same ID in quick succession
        for (Notification existing : notifications) {
            if (existing.getId().equals(notification.getId()) && existing.getAge() < 1000) {
                return; // Skip duplicate
            }
        }

        notifications.add(notification);
        LOGGER.debug("Notification added: {}", notification.getTitle());
    }

    /**
     * Update notifications - remove expired ones.
     * Called each tick.
     */
    public void update() {
        notifications.removeIf(Notification::isExpired);
    }

    /**
     * Get all active notifications.
     */
    public List<Notification> getNotifications() {
        return notifications;
    }

    public int getMaxNotifications() {
        return maxNotifications;
    }

    public void setMaxNotifications(int maxNotifications) {
        this.maxNotifications = maxNotifications;
    }

    public int getNotificationWidth() {
        return notificationWidth;
    }

    public int getNotificationHeight() {
        return notificationHeight;
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    public void setDurationSeconds(int durationSeconds) {
        this.durationSeconds = durationSeconds;
    }

    public void clear() {
        notifications.clear();
    }
}