package dev.fpsoptimizer.notification;

/**
 * Represents a single toast notification.
 * Contains title, subtitle, icon, and timing information.
 */
public class Notification {

    private final String id;
    private final String title;
    private final String subtitle;
    private final String icon;
    private final long startTime;
    private final int durationSeconds;

    private long fadeInStart = 0;
    private long fadeOutStart = 0;
    private boolean fadingOut = false;

    public Notification(String id, String title, String subtitle, String icon, int durationSeconds) {
        this.id = id;
        this.title = title;
        this.subtitle = subtitle;
        this.icon = icon;
        this.startTime = System.currentTimeMillis();
        this.durationSeconds = durationSeconds;
    }

    public Notification(String id, String title, String subtitle, int durationSeconds) {
        this(id, title, subtitle, null, durationSeconds);
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getIcon() {
        return icon;
    }

    public long getStartTime() {
        return startTime;
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    public long getAge() {
        return System.currentTimeMillis() - startTime;
    }

    public boolean isExpired() {
        return getAge() > (long) durationSeconds * 1000;
    }

    public void startFadeOut() {
        fadingOut = true;
        fadeOutStart = System.currentTimeMillis();
    }

    public boolean isFadingOut() {
        return fadingOut;
    }

    public float getAlpha() {
        long age = getAge();

        // Fade in over 200ms
        if (age < 200) {
            return age / 200.0f;
        }

        // Fade out over 200ms at the end
        long fadeOutStartTime = startTime + (long) durationSeconds * 1000 - 200;
        if (age >= fadeOutStartTime) {
            long fadeOutAge = age - fadeOutStartTime;
            return Math.max(0, 1.0f - fadeOutAge / 200.0f);
        }

        return 1.0f;
    }

    public int getYOffset(int index, int notificationHeight) {
        // Each notification is stacked with a small gap
        return index * (notificationHeight + 5);
    }
}