package dev.fpsoptimizer.module;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Module base class and module states.
 */
public class ModuleTest {

    @Test
    public void testModuleCreation() {
        TestModule module = new TestModule("Test", "A test module", ModuleCategory.HUD);
        assertEquals("Test", module.getName());
        assertEquals("A test module", module.getDescription());
        assertEquals(ModuleCategory.HUD, module.getCategory());
        assertFalse(module.isEnabled());
        assertFalse(module.isVisibleInHud());
    }

    @Test
    public void testModuleEnableDisable() {
        TestModule module = new TestModule("Test", "A test module", ModuleCategory.HUD);
        
        assertFalse(module.isEnabled());
        module.setEnabled(true);
        assertTrue(module.isEnabled());
        module.setEnabled(false);
        assertFalse(module.isEnabled());
    }

    @Test
    public void testModuleSetting() {
        TestModule module = new TestModule("Test", "A test module", ModuleCategory.HUD);
        
        module.addSetting(new dev.fpsoptimizer.setting.SettingBoolean("test_bool", true, "A boolean setting"));
        assertEquals(1, module.getSettings().size());
        
        var setting = module.getSetting("test_bool");
        assertNotNull(setting);
        assertTrue(setting.getValue());
        
        setting.setValue(false);
        assertFalse(setting.getValue());
    }

    @Test
    public void testModuleTranslationKey() {
        TestModule module = new TestModule("Fullbright", "Makes world brighter", ModuleCategory.VISUALS);
        assertEquals("module.fpsoptimizer.fullbright", module.getTranslationKey());
    }

    @Test
    public void testModuleCategoryColors() {
        assertNotNull(ModuleCategory.HUD.getColor());
        assertNotNull(ModuleCategory.VISUALS.getColor());
        assertNotNull(ModuleCategory.UTILITY.getColor());
        assertNotNull(ModuleCategory.NAVIGATION.getColor());
        assertNotNull(ModuleCategory.PERFORMANCE.getColor());
        assertNotNull(ModuleCategory.WORLD_ANALYSIS.getColor());
        assertNotNull(ModuleCategory.SETTINGS.getColor());

        // Verify color components are in valid range
        assertTrue(ModuleCategory.HUD.getColorRed() >= 0 && ModuleCategory.HUD.getColorRed() <= 1);
        assertTrue(ModuleCategory.HUD.getColorGreen() >= 0 && ModuleCategory.HUD.getColorGreen() <= 1);
        assertTrue(ModuleCategory.HUD.getColorBlue() >= 0 && ModuleCategory.HUD.getColorBlue() <= 1);
    }

    private static class TestModule extends Module {
        public TestModule(String name, String description, ModuleCategory category) {
            super(name, description, category);
        }
    }
}