package dev.fpsoptimizer.setting;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Setting classes.
 */
public class SettingTest {

    @Test
    public void testSettingBoolean() {
        SettingBoolean setting = new SettingBoolean("test", true, "A boolean setting");
        assertTrue(setting.getValue());
        assertEquals("true", setting.serialize());

        setting.setValue(false);
        assertFalse(setting.getValue());
        assertEquals("false", setting.serialize());

        setting.deserialize("true");
        assertTrue(setting.getValue());

        setting.deserialize("invalid");
        assertFalse(setting.getValue()); // Default fallback
    }

    @Test
    public void testSettingNumber() {
        SettingNumber setting = new SettingNumber("test", 5.0, 0.0, 10.0, 1.0, "A number setting");
        assertEquals(5.0, setting.getValue());
        assertEquals("5.0", setting.serialize());

        // Test clamping
        setting.setValue(-1.0);
        assertEquals(0.0, setting.getValue());

        setting.setValue(100.0);
        assertEquals(10.0, setting.getValue());

        setting.deserialize("7.5");
        assertEquals(7.5, setting.getValue());

        setting.deserialize("invalid");
        assertEquals(0.0, setting.getValue()); // Default fallback
    }

    @Test
    public void testSettingNumberIntValue() {
        SettingNumber setting = new SettingNumber("test", 10.0, 0.0, 100.0, 1.0, "A number setting");
        assertEquals(10, setting.intValue());
        assertEquals(10.0f, setting.floatValue(), 0.001);
    }

    @Test
    public void testSettingColor() {
        SettingColor setting = new SettingColor("test", 0xFF804000, "A color setting");
        assertEquals(0xFF804000, setting.getValue());
        assertEquals("4278255616", setting.serialize());

        assertEquals(128, setting.getRed());
        assertEquals(64, setting.getGreen());
        assertEquals(0, setting.getBlue());
        assertEquals(255, setting.getAlpha());

        float[] rgba = setting.getRGBA();
        assertEquals(0.5f, rgba[0], 0.001);
        assertEquals(0.25f, rgba[1], 0.001);
        assertEquals(0.0f, rgba[2], 0.001);
        assertEquals(1.0f, rgba[3], 0.001);
    }

    @Test
    public void testSettingCopy() {
        SettingBoolean original = new SettingBoolean("test", true, "description");
        SettingBoolean copy = original.copy();
        
        assertNotSame(original, copy);
        assertEquals(original.getName(), copy.getName());
        assertEquals(original.getValue(), copy.getValue());
        assertEquals(original.getDescription(), copy.getDescription());
    }
}