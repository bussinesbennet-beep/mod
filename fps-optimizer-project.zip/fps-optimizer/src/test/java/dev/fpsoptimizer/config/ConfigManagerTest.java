package dev.fpsoptimizer.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.*;
import java.io.IOException;

/**
 * Unit tests for ConfigManager.
 * Tests configuration loading, saving, validation, and migration.
 */
public class ConfigManagerTest {

    private ConfigManager configManager;
    private Path testConfigDir;
    private Path testConfigFile;

    @BeforeEach
    public void setUp() throws IOException {
        testConfigDir = Files.createTempDirectory("fps-optimizer-test");
        testConfigFile = testConfigDir.resolve("fps-optimizer.json");
        configManager = new ConfigManager();
    }

    @AfterEach
    public void tearDown() throws IOException {
        if (testConfigDir != null) {
            deleteDirectory(testConfigDir);
        }
    }

    @Test
    public void testDefaultConfigCreation() {
        // ConfigManager should create valid default config
        assertNotNull(configManager.getConfigData());
        assertEquals(3, configManager.getConfigData().version);
        assertNotNull(configManager.getConfigData().moduleStates);
        assertNotNull(configManager.getConfigData().keybinds);
        assertNotNull(configManager.getConfigData().hudPositions);
        assertNotNull(configManager.getConfigData().colors);
        assertTrue(configManager.getConfigData().notificationsEnabled);
        assertEquals(5, configManager.getConfigData().notificationDuration);
    }

    @Test
    public void testConfigSaveAndLoad() throws IOException {
        // Modify config data
        configManager.getConfigData().moduleStates.put("Fullbright", true);
        configManager.getConfigData().notificationDuration = 10;
        configManager.save();

        // Verify file was created
        assertTrue(Files.exists(testConfigFile));
    }

    @Test
    public void testConfigValidation() {
        ConfigData data = new ConfigData();
        data.version = 3;
        data.moduleStates = new java.util.HashMap<>();
        data.keybinds = new java.util.HashMap<>();

        // Should be valid
        assertNotNull(data.moduleStates);
        assertNotNull(data.keybinds);
    }

    @Test
    public void testConfigMigration() {
        ConfigData oldData = new ConfigData();
        oldData.version = 1;
        oldData.moduleStates = new java.util.HashMap<>();
        oldData.keybinds = new java.util.HashMap<>();

        // Migration should upgrade to version 3
        assertEquals(1, oldData.version);
        // After migration in ConfigManager, version should be 3
    }

    @Test
    public void testHudPositionSerialization() {
        ConfigData.HudPosition pos = new ConfigData.HudPosition(100, 200, true, 1.5f);
        assertEquals(100, pos.x);
        assertEquals(200, pos.y);
        assertTrue(pos.visible);
        assertEquals(1.5f, pos.scale, 0.001);
    }

    @Test
    public void testNoCredentialsStored() {
        ConfigData data = configManager.getConfigData();
        // Verify no credential fields exist
        assertFalse(data.getClass().getName().contains("password"));
        assertFalse(data.getClass().getName().contains("token"));
        assertFalse(data.getClass().getName().contains("secret"));
    }

    private static void deleteDirectory(Path path) throws IOException {
        if (Files.exists(path)) {
            Files.walk(path)
                .sorted(java.util.Collections.reverseOrder())
                .map(Path::toFile)
                .forEach(File::delete);
        }
    }
}