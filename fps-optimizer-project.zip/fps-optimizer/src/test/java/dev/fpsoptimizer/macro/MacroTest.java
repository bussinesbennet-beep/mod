package dev.fpsoptimizer.macro;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Macro validation and MacroManager logic.
 */
public class MacroTest {

    @Test
    public void testMacroCreation() {
        Macro macro = new Macro("TestMacro");
        assertEquals("TestMacro", macro.getName());
        assertEquals(-1, macro.getKeybind());
        assertEquals(0, macro.getActionCount());
        assertFalse(macro.isLoop());
        assertTrue(macro.getCreated() > 0);
    }

    @Test
    public void testMacroValidation() {
        Macro macro = new Macro("TestMacro");
        
        // Empty macro should be invalid
        assertFalse(macro.isValid());
        
        // Add valid actions
        macro.addAction(new MacroAction(MacroAction.Type.KEY_PRESS, 16)); // KEY_W
        macro.addAction(new MacroAction(MacroAction.Type.KEY_RELEASE, 16));
        macro.addAction(new MacroAction(MacroAction.Type.DELAY, 100));
        
        assertTrue(macro.isValid());
        assertEquals(3, macro.getActionCount());
    }

    @Test
    public void testMacroInvalidActions() {
        Macro macro = new Macro("TestMacro");
        
        // Invalid action: DELAY with 0 milliseconds
        macro.addAction(new MacroAction(MacroAction.Type.DELAY, 0));
        assertFalse(macro.isValid());
        
        macro.clearActions();
        
        // Invalid action: KEY_PRESS with negative key code
        macro.addAction(new MacroAction(MacroAction.Type.KEY_PRESS, -1));
        assertFalse(macro.isValid());
    }

    @Test
    public void testMacroSerialization() {
        Macro macro = new Macro("TestMacro");
        macro.addAction(new MacroAction(MacroAction.Type.KEY_PRESS, 16));
        macro.addAction(new MacroAction(MacroAction.Type.KEY_RELEASE, 16));
        macro.setKeybind(32);
        macro.setLoop(true);
        macro.setLoopDelay(500);

        String json = macro.toJson();
        assertNotNull(json);
        assertTrue(json.contains("TestMacro"));
        assertTrue(json.contains("KEY_PRESS"));

        Macro deserialized = Macro.fromJson(json);
        assertNotNull(deserialized);
        assertEquals("TestMacro", deserialized.getName());
        assertEquals(32, deserialized.getKeybind());
        assertTrue(deserialized.isLoop());
        assertEquals(500, deserialized.getLoopDelay());
        assertEquals(2, deserialized.getActionCount());
    }

    @Test
    public void testMacroInvalidJson() {
        Macro invalid = Macro.fromJson("not valid json");
        assertNull(invalid);
    }

    @Test
    public void testMacroActionToString() {
        MacroAction press = new MacroAction(MacroAction.Type.KEY_PRESS, 16);
        assertTrue(press.toString().contains("KEY_PRESS"));

        MacroAction delay = new MacroAction(MacroAction.Type.DELAY, 100);
        assertTrue(delay.toString().contains("DELAY"));
        assertTrue(delay.toString().contains("100ms"));
    }

    @Test
    public void testMacroNameValidation() {
        Macro macro = new Macro("");
        assertFalse(macro.isValid());

        macro = new Macro("   ");
        assertFalse(macro.isValid());

        macro = new Macro("ValidName");
        macro.addAction(new MacroAction(MacroAction.Type.KEY_PRESS, 16));
        assertTrue(macro.isValid());
    }

    @Test
    public void testMacroMaxActions() {
        Macro macro = new Macro("LargeMacro");
        for (int i = 0; i < 1001; i++) {
            macro.addAction(new MacroAction(MacroAction.Type.KEY_PRESS, 16));
        }
        assertFalse(macro.isValid());
    }
}